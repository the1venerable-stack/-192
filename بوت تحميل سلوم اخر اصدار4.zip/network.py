#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
طبقة الشبكة والأداء:
- محرك DNS-over-HTTPS (DoH) مع كاش للنطاقات الفاشلة لمنع التأخير المتكرر.
- جلسة HTTP مجمّعة (Connection Pooling) بدون إغراق الكونسول بتحذيرات urllib3.
- مجمعات خيوط منظمة (ThreadPoolExecutor) للتحميل والمهام السريعة.
"""

import re
import sys
import time
import socket
import logging
import threading
from concurrent.futures import ThreadPoolExecutor

import requests
import urllib3
from requests.adapters import HTTPAdapter

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
# كتم تحذيرات urllib3 المتكررة عند فشل نطاق بديل
logging.getLogger("urllib3").setLevel(logging.ERROR)
logging.getLogger("requests").setLevel(logging.ERROR)

logger = logging.getLogger("DownloaderBot")


class _SilentYtdlpLogger:
    """كائن تسجيل صامت لمكتبة yt-dlp لمنع إغراق الكونسول بتحذيرات غير ضرورية."""
    def debug(self, msg):
        pass

    def info(self, msg):
        pass

    def warning(self, msg):
        pass

    def error(self, msg):
        logger.debug(f"[yt-dlp] {msg}")


SILENT_YDL_LOGGER = _SilentYtdlpLogger()

# =============================================================================
# مجمّعات الخيوط (تحسين الأداء ومنع استنزاف الرام في الاستضافة)
# =============================================================================
DOWNLOAD_EXECUTOR = ThreadPoolExecutor(max_workers=6, thread_name_prefix="dl_worker")
FAST_EXECUTOR = ThreadPoolExecutor(max_workers=10, thread_name_prefix="io_worker")

# =============================================================================
# جلسة HTTP مشتركة مع Connection Pooling
# =============================================================================
DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)


def create_pooled_session(pool_size=32):
    session = requests.Session()
    adapter = HTTPAdapter(
        pool_connections=pool_size,
        pool_maxsize=pool_size,
        max_retries=0,
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update({
        "User-Agent": DEFAULT_UA,
        "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
    })
    return session


http_session = create_pooled_session()

# =============================================================================
# محرك DNS-over-HTTPS (DoH) الذكي مع كاش للنطاقات المتعطلة
# =============================================================================
_dns_cache = {}
_dns_fail_cache = {}
_dns_lock = threading.Lock()
_orig_getaddrinfo = socket.getaddrinfo
_doh_session = create_pooled_session(pool_size=8)


def resolve_hostname_via_doh(hostname):
    if not hostname or re.match(r"^\d+\.\d+\.\d+\.\d+$", str(hostname)):
        return hostname

    now = time.time()
    with _dns_lock:
        if hostname in _dns_cache:
            ip_val, exp = _dns_cache[hostname]
            if now < exp:
                return ip_val
        if hostname in _dns_fail_cache and now < _dns_fail_cache[hostname]:
            return None

    doh_endpoints = (
        ("https://1.1.1.1/dns-query", {"name": hostname, "type": "A"}),
        ("https://8.8.8.8/resolve", {"name": hostname, "type": "A"}),
    )
    headers = {"Accept": "application/dns-json", "User-Agent": "Mozilla/5.0"}

    for endpoint, params in doh_endpoints:
        try:
            resp = _doh_session.get(endpoint, params=params, headers=headers, timeout=(2, 3), verify=False)
            if resp.status_code == 200:
                data = resp.json()
                for ans in data.get("Answer", []):
                    if ans.get("type") == 1 and ans.get("data"):
                        resolved_ip = ans["data"].strip()
                        with _dns_lock:
                            _dns_cache[hostname] = (resolved_ip, time.time() + 3600)
                        return resolved_ip
        except Exception:
            continue

    with _dns_lock:
        _dns_fail_cache[hostname] = time.time() + 300
    return None


def smart_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    try:
        return _orig_getaddrinfo(host, port, family, type, proto, flags)
    except socket.gaierror:
        resolved_ip = resolve_hostname_via_doh(host)
        if resolved_ip and resolved_ip != host:
            target_family = socket.AF_INET if family == socket.AF_INET6 else family
            return _orig_getaddrinfo(resolved_ip, port, target_family, type, proto, flags)
        raise


def install_doh_resolver():
    socket.getaddrinfo = smart_getaddrinfo
