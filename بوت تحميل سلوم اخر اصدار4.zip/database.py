#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
إدارة قاعدة البيانات (SQLite بوضع WAL لتحسين الأداء والسرعة) والكاش المؤقت للطلبات.
"""

import os
import time
import uuid
import hashlib
import sqlite3
import threading
from datetime import datetime

from config import (
    DB_PATH,
    OWNER_ID,
    COOKIES_FILE_PATH,
    DEFAULT_WELCOME_TEXT,
    DEFAULT_FORCE_SUB_TEXT,
    CUSTOMIZABLE_UI_KEYS,
)

db_lock = threading.Lock()
_req_lock = threading.Lock()
_ephemeral_requests = {}

# كاش القنوات التي لا يملك البوت فيها صلاحية مشرف لتجنب تكرار خطأ member list is inaccessible
_inaccessible_channels_cache = {}
_inaccessible_lock = threading.Lock()


def get_db_connection():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=15)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db_lock:
        conn = get_db_connection()
        cursor = conn.cursor()

        # تفعيل وضع WAL لتسريع القراءة والكتابة المتزامنة
        cursor.execute("PRAGMA journal_mode=WAL;")
        cursor.execute("PRAGMA synchronous=NORMAL;")
        cursor.execute("PRAGMA temp_store=MEMORY;")
        cursor.execute("PRAGMA cache_size=-8000;")

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                joined_at TEXT,
                is_banned INTEGER DEFAULT 0
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                user_id INTEGER PRIMARY KEY,
                added_by INTEGER,
                added_at TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS force_channels (
                chat_id TEXT PRIMARY KEY,
                title TEXT,
                invite_link TEXT,
                added_at TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS premium_assets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_scope TEXT,
                asset_type TEXT,
                file_id TEXT,
                custom_emoji_id TEXT,
                emoji_char TEXT,
                added_at TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS media_cache (
                cache_key TEXT PRIMARY KEY,
                file_type TEXT,
                file_id TEXT,
                title TEXT,
                description TEXT DEFAULT '',
                author TEXT,
                created_at INTEGER
            )
        """)

        try:
            cursor.execute("ALTER TABLE media_cache ADD COLUMN description TEXT DEFAULT ''")
        except Exception:
            pass

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS custom_ui (
                ui_key TEXT PRIMARY KEY,
                btn_label TEXT,
                inner_content TEXT,
                sticker_id TEXT DEFAULT '',
                custom_emoji_id TEXT DEFAULT '',
                custom_emoji_char TEXT DEFAULT ''
            )
        """)

        default_settings = {
            "welcome_text": DEFAULT_WELCOME_TEXT,
            "welcome_entities": "[]",
            "welcome_sticker_id": "",
            "force_sub_enabled": "1",
            "force_sub_text": DEFAULT_FORCE_SUB_TEXT,
            "bot_enabled": "1",
            "premium_placement": "off",
            "premium_start_emoji_id": "",
            "premium_start_emoji_char": "",
            "premium_sections_emoji_id": "",
            "premium_sections_emoji_char": "",
            "color_theme": "mixed",
        }
        for k, v in default_settings.items():
            cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

        for u_key, u_info in CUSTOMIZABLE_UI_KEYS.items():
            cursor.execute(
                """
                INSERT OR IGNORE INTO custom_ui (ui_key, btn_label, inner_content, sticker_id, custom_emoji_id, custom_emoji_char)
                VALUES (?, ?, ?, '', '', '')
                """,
                (u_key, u_info["default_label"], u_info["default_content"]),
            )

        # تنظيف النصوص القديمة المحفوظة في قاعدة البيانات إن كانت تحتوي عبارات الضغط/الجودة القديمة
        try:
            row_help = cursor.execute("SELECT inner_content FROM custom_ui WHERE ui_key = 'btn_help_guide'").fetchone()
            if row_help and row_help["inner_content"] and any(w in row_help["inner_content"] for w in ("مضغوط", "جودة قويه", "جوده قويه")):
                cursor.execute(
                    "UPDATE custom_ui SET inner_content = ? WHERE ui_key = 'btn_help_guide'",
                    (CUSTOMIZABLE_UI_KEYS["btn_help_guide"]["default_content"],),
                )
        except Exception:
            pass

        cursor.execute(
            "INSERT OR IGNORE INTO admins (user_id, added_by, added_at) VALUES (?, ?, ?)",
            (OWNER_ID, OWNER_ID, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        )

        try:
            cursor.execute(
                "DELETE FROM media_cache WHERE lower(author) IN ('vxinstagram', 'ddinstagram', 'instafix', 'kkinstagram')"
            )
        except Exception:
            pass

        conn.commit()
        conn.close()


def has_cookies_file():
    return os.path.exists(COOKIES_FILE_PATH) and os.path.getsize(COOKIES_FILE_PATH) > 20


def get_setting(key, default=""):
    with db_lock:
        conn = get_db_connection()
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        conn.close()
        return row["value"] if row else default


def set_setting(key, value):
    with db_lock:
        conn = get_db_connection()
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
        conn.commit()
        conn.close()


def get_ui_config(ui_key):
    defaults = CUSTOMIZABLE_UI_KEYS.get(ui_key, {
        "title": ui_key,
        "default_label": ui_key,
        "default_content": "",
        "has_content": False,
    })
    with db_lock:
        conn = get_db_connection()
        row = conn.execute("SELECT * FROM custom_ui WHERE ui_key = ?", (ui_key,)).fetchone()
        conn.close()
        if row:
            return {
                "ui_key": ui_key,
                "title": defaults.get("title", ui_key),
                "btn_label": row["btn_label"] if row["btn_label"] else defaults["default_label"],
                "inner_content": row["inner_content"] if row["inner_content"] is not None else defaults["default_content"],
                "sticker_id": row["sticker_id"] or "",
                "custom_emoji_id": row["custom_emoji_id"] or "",
                "custom_emoji_char": row["custom_emoji_char"] or "",
                "has_content": defaults.get("has_content", False),
            }
        return {
            "ui_key": ui_key,
            "title": defaults.get("title", ui_key),
            "btn_label": defaults["default_label"],
            "inner_content": defaults["default_content"],
            "sticker_id": "",
            "custom_emoji_id": "",
            "custom_emoji_char": "",
            "has_content": defaults.get("has_content", False),
        }


def update_ui_config(ui_key, btn_label=None, inner_content=None, sticker_id=None, custom_emoji_id=None, custom_emoji_char=None):
    curr = get_ui_config(ui_key)
    new_label = curr["btn_label"] if btn_label is None else btn_label
    new_content = curr["inner_content"] if inner_content is None else inner_content
    new_sticker = curr["sticker_id"] if sticker_id is None else sticker_id
    new_ce_id = curr["custom_emoji_id"] if custom_emoji_id is None else custom_emoji_id
    new_ce_char = curr["custom_emoji_char"] if custom_emoji_char is None else custom_emoji_char

    with db_lock:
        conn = get_db_connection()
        conn.execute(
            """
            INSERT OR REPLACE INTO custom_ui (ui_key, btn_label, inner_content, sticker_id, custom_emoji_id, custom_emoji_char)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (ui_key, new_label, new_content, new_sticker, new_ce_id, new_ce_char),
        )
        conn.commit()
        conn.close()


def reset_all_ui_configs():
    with db_lock:
        conn = get_db_connection()
        for u_key, u_info in CUSTOMIZABLE_UI_KEYS.items():
            conn.execute(
                """
                INSERT OR REPLACE INTO custom_ui (ui_key, btn_label, inner_content, sticker_id, custom_emoji_id, custom_emoji_char)
                VALUES (?, ?, ?, '', '', '')
                """,
                (u_key, u_info["default_label"], u_info["default_content"]),
            )
        conn.commit()
        conn.close()


def register_user(user):
    if not user or user.is_bot:
        return
    with db_lock:
        conn = get_db_connection()
        existing = conn.execute("SELECT user_id FROM users WHERE user_id = ?", (user.id,)).fetchone()
        if not existing:
            conn.execute(
                "INSERT INTO users (user_id, username, first_name, joined_at) VALUES (?, ?, ?, ?)",
                (user.id, user.username or "", user.first_name or "مستخدم", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            )
        else:
            conn.execute(
                "UPDATE users SET username = ?, first_name = ? WHERE user_id = ?",
                (user.username or "", user.first_name or "مستخدم", user.id),
            )
        conn.commit()
        conn.close()


def is_admin(user_id):
    if user_id == OWNER_ID:
        return True
    with db_lock:
        conn = get_db_connection()
        row = conn.execute("SELECT user_id FROM admins WHERE user_id = ?", (user_id,)).fetchone()
        conn.close()
        return row is not None


def is_user_banned(user_id):
    if is_admin(user_id):
        return False
    with db_lock:
        conn = get_db_connection()
        row = conn.execute("SELECT is_banned FROM users WHERE user_id = ?", (user_id,)).fetchone()
        conn.close()
        return bool(row and row["is_banned"] == 1)


def get_force_channels():
    with db_lock:
        conn = get_db_connection()
        rows = conn.execute("SELECT * FROM force_channels").fetchall()
        conn.close()
        return [dict(r) for r in rows]


def save_url_request(user_id, chat_id, url, is_search=0, meta=None):
    req_id = uuid.uuid4().hex[:10]
    now = int(time.time())
    with _req_lock:
        expired = [k for k, v in _ephemeral_requests.items() if now - v.get("created_at", 0) > 7200]
        for k in expired:
            _ephemeral_requests.pop(k, None)
        _ephemeral_requests[req_id] = {
            "req_id": req_id,
            "user_id": user_id,
            "chat_id": chat_id,
            "url": url,
            "is_search": int(is_search),
            "meta": dict(meta or {}),
            "created_at": now,
        }
    return req_id


def update_url_request_meta(req_id, meta):
    with _req_lock:
        if req_id in _ephemeral_requests:
            _ephemeral_requests[req_id]["meta"] = dict(meta or {})


def get_url_request(req_id):
    with _req_lock:
        item = _ephemeral_requests.get(req_id)
        return dict(item) if item else None


def make_cache_key(normalized_url, mode):
    raw = f"v10_hd|{(normalized_url or '').strip()}|{mode}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


def get_cached_media(normalized_url, mode):
    key = make_cache_key(normalized_url, mode)
    with db_lock:
        conn = get_db_connection()
        row = conn.execute("SELECT * FROM media_cache WHERE cache_key = ?", (key,)).fetchone()
        conn.close()
        return dict(row) if row else None


def save_cached_media(normalized_url, mode, file_type, file_id, title="", description="", author=""):
    if not file_id:
        return
    key = make_cache_key(normalized_url, mode)
    with db_lock:
        conn = get_db_connection()
        conn.execute(
            "INSERT OR REPLACE INTO media_cache (cache_key, file_type, file_id, title, description, author, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                key,
                file_type,
                file_id,
                str(title or "")[:200],
                str(description or "")[:2500],
                str(author or "")[:80],
                int(time.time()),
            ),
        )
        conn.commit()
        conn.close()


def clear_all_media_cache():
    with db_lock:
        conn = get_db_connection()
        conn.execute("DELETE FROM media_cache")
        conn.commit()
        conn.close()


def mark_channel_inaccessible(chat_id, duration=3600):
    with _inaccessible_lock:
        _inaccessible_channels_cache[str(chat_id)] = time.time() + duration


def clear_inaccessible_channel(chat_id=None):
    with _inaccessible_lock:
        if chat_id is None:
            _inaccessible_channels_cache.clear()
        else:
            _inaccessible_channels_cache.pop(str(chat_id), None)


def is_channel_temporarily_skipped(chat_id):
    with _inaccessible_lock:
        return time.time() < _inaccessible_channels_cache.get(str(chat_id), 0)
