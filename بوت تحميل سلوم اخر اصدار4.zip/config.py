#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
الإعدادات الأساسية والثوابت الافتراضية للبوت.
"""

import os
import tempfile

# =============================================================================
# إعدادات البوت الأساسية (يمكن تعديلها هنا أو عبر متغيرات البيئة في الاستضافة)
# =============================================================================
BOT_TOKEN = os.environ.get("BOT_TOKEN", "9129047122:AAHu1mExHuNTF6ZsTuy4X31z1L-G30SoHmo")
OWNER_ID = int(os.environ.get("OWNER_ID", "1523781080"))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "downloader_bot_pro.db")
DOWNLOAD_DIR = os.path.join(tempfile.gettempdir(), "tg_smart_downloader")
COOKIES_FILE_PATH = os.path.join(BASE_DIR, "cookies.txt")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# حد الرفع الأقصى عبر Telegram Bot API (بايت)
TELEGRAM_MAX_UPLOAD_MB = 49.0

# =============================================================================
# النصوص الافتراضية للبوت (بسيطة وطبيعية بدون كلمات مضغوط / قوية / أصلية)
# =============================================================================
DEFAULT_WELCOME_TEXT = """هلا ومرحبا

انا هنا عشان اضبطك واحمل لك اي منشور تبيه (انستغرام، تيك توك، يوتيوب، تويتر، سناب وغيرها) بدون علامة مائية مع إرسال وصف المنشور كاملاً
ارسل الرابط ولا تشيل هم، وازيدك من الشعر بيت؟ يمديك تمنشني بأي مكان وتحط رابط المنشور ويتحمل وينرسل بنفس المكان

بإستخدامك لـ @البوت انت توافق على الشروط والاحكام"""

DEFAULT_FORCE_SUB_TEXT = (
    "عذرا عزيزي {name}\n"
    "اشترك في قنوات البوت اولا ثم اضغط (تحقق من الاشتراك):"
)

DEFAULT_HELP_GUIDE_TEXT = (
    "<b>المنصات المدعومة والمميزات:</b>\n"
    "<blockquote>"
    "• <b>انستغرام:</b> تحميل الريلز، المنشورات، والألبومات المتعددة مع الوصف.\n"
    "• <b>المنصات الشاملة:</b> تيك توك، يوتيوب، تويتر/X، سناب شات، فيسبوك، بنترست، ساوند كلاود، ثريدز، تيليجرام، وجوجل.\n"
    "• <b>إرسال الوصف التلقائي:</b> يرسل البوت وصف الفيديو أو المنشور الأصلي مع كل عملية تحميل.\n"
    "• <b>بحث وروابط يوتيوب:</b> أرسل (<code>ب اسم الفيديو</code>) أو رابط يوتيوب وسيرسل لك البوت الفيديو مع الوصف وتحته زر لتحويله لرسالة صوتية.\n"
    "• <b>في المجموعات:</b> منشن <code>@{bot}</code> مع الرابط للتحميل بنفس المكان."
    "</blockquote>"
)

DEFAULT_SEARCH_HINT_TEXT = (
    "<b>البحث في يوتيوب:</b>\n"
    "<blockquote>"
    "للبحث في يوتيوب، أرسل حرف <b>ب</b> متبوعاً باسم الفيديو (مثال: <code>ب سورة الكهف</code>) أو أرسل اسم الفيديو مباشرة في الخاص.\n"
    "بمجرد اختيار الفيديو من النتائج أو إرسال رابط يوتيوب، سيرسله البوت لك على شكل <b>فيديو مع الوصف</b> وتحته خيار <b>تحويل إلى رسالة صوتية</b>."
    "</blockquote>"
)

PLACEMENT_LABELS = {
    "both": "البداية + الأقسام",
    "start_only": "البداية فقط",
    "sections_only": "الأقسام فقط",
    "off": "معطل (بدون إيموجي عام)"
}

THEME_LABELS = {
    "mixed": "ملون ذكي",
    "primary": "أزرق رسمي",
    "success": "أخضر زمردي",
    "danger": "أحمر ملكي",
    "default": "كلاسيكي"
}

CUSTOMIZABLE_UI_KEYS = {
    "btn_help_guide": {
        "title": "زر وقسم: المنصات والمميزات (في البداية)",
        "default_label": "المنصات والمميزات",
        "default_content": DEFAULT_HELP_GUIDE_TEXT,
        "has_content": True
    },
    "btn_smart_search": {
        "title": "زر وقسم: البحث في يوتيوب (في البداية)",
        "default_label": "البحث في يوتيوب",
        "default_content": DEFAULT_SEARCH_HINT_TEXT,
        "has_content": True
    },
    "btn_add_group": {
        "title": "زر: أضفني لمجموعتك",
        "default_label": "أضفني لمجموعتك",
        "default_content": "",
        "has_content": False
    },
    "btn_admin_panel": {
        "title": "زر: لوحة التحكم (في البداية)",
        "default_label": "لوحة التحكم (/admin)",
        "default_content": "",
        "has_content": False
    },
    "btn_yt_to_voice": {
        "title": "زر تحت الفيديو: تحويل إلى رسالة صوتية",
        "default_label": "تحويل إلى رسالة صوتية",
        "default_content": "الصوت المستخرج من الفيديو",
        "has_content": True
    },
    "btn_to_mp3": {
        "title": "زر تحت الفيديو: تحويل إلى MP3",
        "default_label": "تحويل إلى MP3",
        "default_content": "",
        "has_content": False
    },
    "btn_verify_sub": {
        "title": "زر الاشتراك الإجباري: تحقق من الاشتراك",
        "default_label": "تم الاشتراك - تحقق",
        "default_content": DEFAULT_FORCE_SUB_TEXT,
        "has_content": True
    },
    "btn_cancel": {
        "title": "زر: إلغاء / إغلاق",
        "default_label": "إلغاء",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_bot": {
        "title": "زر الأدمن: تشغيل/إيقاف البوت",
        "default_label": "البوت",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_fsub": {
        "title": "زر الأدمن: تفعيل/تعطيل الاشتراك",
        "default_label": "الاشتراك",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_ui_custom": {
        "title": "زر الأدمن: الأزرار والأقسام",
        "default_label": "الأزرار والأقسام",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_premium": {
        "title": "زر الأدمن: الملصقات والمميز",
        "default_label": "الملصقات والمميز",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_colors": {
        "title": "زر الأدمن: الألوان",
        "default_label": "الألوان",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_welcome": {
        "title": "زر الأدمن: الترحيب",
        "default_label": "الترحيب",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_channels": {
        "title": "زر الأدمن: القنوات",
        "default_label": "القنوات",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_users": {
        "title": "زر الأدمن: المشتركين",
        "default_label": "المشتركين",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_broadcast": {
        "title": "زر الأدمن: الإذاعة",
        "default_label": "الإذاعة",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_cookies": {
        "title": "زر الأدمن: كوكيز",
        "default_label": "كوكيز",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_ban": {
        "title": "زر الأدمن: الحظر",
        "default_label": "الحظر",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_admins": {
        "title": "زر الأدمن: المشرفين",
        "default_label": "المشرفين",
        "default_content": "",
        "has_content": False
    },
    "adm_btn_clear_cache": {
        "title": "زر الأدمن: مسح الكاش",
        "default_label": "مسح الكاش",
        "default_content": "",
        "has_content": False
    }
}
