#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
معالجات الأوامر الأساسية (/start و /admin).
"""

from database import register_user, is_user_banned, is_admin, get_setting
from bot_instance import bot, admin_states, safe_send_message, send_force_sub_prompt
from ui import send_welcome_screen, get_admin_dashboard_text, build_admin_main_keyboard


def register_command_handlers():
    @bot.message_handler(commands=["start"])
    def handle_start_command(message):
        user = message.from_user
        register_user(user)

        if is_user_banned(user.id):
            safe_send_message(message.chat.id, "عذراً، لقد تم حظرك من استخدام البوت.", reply_to_message_id=message.message_id)
            return

        if get_setting("bot_enabled", "1") != "1" and not is_admin(user.id):
            safe_send_message(message.chat.id, "البوت في وضع الصيانة حالياً، يرجى المحاولة لاحقاً.", reply_to_message_id=message.message_id)
            return

        if not send_force_sub_prompt(message.chat.id, user, reply_to_message_id=message.message_id):
            return

        send_welcome_screen(message.chat.id, user, reply_to_message_id=message.message_id)

    @bot.message_handler(commands=["admin", "panel"])
    def handle_admin_command(message):
        user = message.from_user
        register_user(user)

        if not is_admin(user.id):
            safe_send_message(message.chat.id, "هذا الأمر مخصص لإدارة البوت فقط.", reply_to_message_id=message.message_id)
            return

        admin_states.pop(user.id, None)
        safe_send_message(
            message.chat.id,
            get_admin_dashboard_text(),
            reply_markup=build_admin_main_keyboard(),
            parse_mode="HTML",
            reply_to_message_id=message.message_id,
        )
