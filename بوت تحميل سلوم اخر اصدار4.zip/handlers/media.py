#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
معالجات التحميل المباشر، البحث في يوتيوب، المجموعات، الوضع الضمني، وتحويل الصوت.
- عند إرسال أي رابط، يحمّل البوت الفيديو مباشرة بأعلى جودة بدون أي كلمات مثل (مضغوط / قوية / أصلية).
"""

import os
import re
import html
import tempfile
from telebot import types

from config import DOWNLOAD_DIR, DEFAULT_HELP_GUIDE_TEXT, DEFAULT_SEARCH_HINT_TEXT
from network import DOWNLOAD_EXECUTOR, FAST_EXECUTOR, logger
from database import (
    register_user,
    is_user_banned,
    is_admin,
    get_setting,
    get_ui_config,
    save_url_request,
    get_url_request,
    get_cached_media,
    save_cached_media,
)
from bot_instance import (
    bot,
    get_bot_username,
    format_premium_badge,
    make_btn,
    send_ui_optional_sticker,
    strip_advanced_button_fields,
    safe_answer_callback,
    safe_send_message,
    safe_edit_message,
    check_user_subscription,
    send_force_sub_prompt,
)
from ui import send_welcome_screen, format_media_caption_with_description
from media_utils import get_video_stream_info, cleanup_file_and_memory, purge_stale_temp_files
from downloaders import (
    extract_all_urls,
    extract_first_url,
    normalize_cache_url,
    detect_platform_info,
    download_media_pipeline,
)
from downloaders.instagram import clean_instagram_author
from downloaders.youtube import extract_youtube_search_query, search_youtube_top5
from handlers.admin import handle_admin_callback


def execute_download_and_send(chat_id, url_or_query, mode="video", status_msg_id=None, reply_to_msg_id=None, req_id=None, is_search=False, voice_only_button=False):
    try:
        _execute_download_and_send_inner(chat_id, url_or_query, mode, status_msg_id, reply_to_msg_id, req_id, is_search, voice_only_button)
    except Exception as e:
        logger.error(f"Unhandled download worker error: {e}")
        if status_msg_id:
            safe_edit_message(chat_id, status_msg_id, f"<b>تعذر التحميل حالياً:</b>\n<code>{html.escape(str(e)[:160])}</code>", parse_mode="HTML")


def _execute_download_and_send_inner(chat_id, url_or_query, mode="video", status_msg_id=None, reply_to_msg_id=None, req_id=None, is_search=False, voice_only_button=False):
    bot_uname = get_bot_username()
    safe_uname = html.escape(bot_uname)
    badge = format_premium_badge("sections", "")
    p_info = detect_platform_info(url_or_query) if not is_search else {"name": "يوتيوب", "key": "youtube"}
    norm_url = normalize_cache_url(url_or_query) if not is_search else url_or_query

    extra_markup = None
    if req_id:
        extra_markup = types.InlineKeyboardMarkup(row_width=2)
        if voice_only_button or p_info.get("key") == "youtube":
            extra_markup.row(make_btn(callback_data=f"dl|voice|{req_id}", style="success", scope="sections", ui_key="btn_yt_to_voice"))
        else:
            extra_markup.row(
                make_btn(callback_data=f"dl|voice|{req_id}", style="success", scope="sections", ui_key="btn_yt_to_voice"),
                make_btn(callback_data=f"dl|mp3|{req_id}", style="primary", scope="sections", ui_key="btn_to_mp3"),
            )

    req_saved_meta = {}
    if req_id:
        req_obj = get_url_request(req_id)
        if req_obj and isinstance(req_obj.get("meta"), dict):
            req_saved_meta = req_obj["meta"]

    # 1. فحص الكاش السريع أولاً
    if not is_search and mode in ("video", "voice", "mp3"):
        cached = get_cached_media(norm_url, mode)
        if cached and cached.get("file_id"):
            try:
                c_title = cached.get("title") or req_saved_meta.get("title") or "منشور محمل"
                c_desc = cached.get("description") or req_saved_meta.get("description") or c_title
                raw_c_author = cached.get("author") or req_saved_meta.get("author") or ""
                if p_info.get("key") == "instagram":
                    raw_c_author = clean_instagram_author(raw_c_author)
                author_disp = f"@{raw_c_author.lstrip('@')}" if (raw_c_author and p_info.get("key") == "instagram") else raw_c_author

                c_cap, clean_cap, overflow_desc = format_media_caption_with_description(
                    badge=badge, title=c_title, description=c_desc,
                    platform_name=p_info["name"], author_display=author_disp, bot_uname=bot_uname,
                )

                sent_cached_msg = None
                if cached["file_type"] == "video":
                    try:
                        sent_cached_msg = bot.send_video(
                            chat_id, cached["file_id"], caption=c_cap, parse_mode="HTML",
                            supports_streaming=True, reply_to_message_id=reply_to_msg_id, reply_markup=extra_markup,
                        )
                    except Exception:
                        sent_cached_msg = bot.send_video(
                            chat_id, cached["file_id"], caption=clean_cap, parse_mode="HTML",
                            supports_streaming=True, reply_to_message_id=reply_to_msg_id,
                            reply_markup=strip_advanced_button_fields(extra_markup) if extra_markup else None,
                        )
                elif cached["file_type"] == "voice":
                    send_ui_optional_sticker(chat_id, "btn_yt_to_voice")
                    sent_cached_msg = bot.send_voice(chat_id, cached["file_id"], caption=clean_cap, parse_mode="HTML", reply_to_message_id=reply_to_msg_id)
                elif cached["file_type"] == "audio":
                    sent_cached_msg = bot.send_audio(chat_id, cached["file_id"], caption=clean_cap, parse_mode="HTML", reply_to_message_id=reply_to_msg_id)

                if overflow_desc and sent_cached_msg:
                    safe_send_message(
                        chat_id,
                        f"<b>الوصف الكامل للمنشور:</b>\n<blockquote>{html.escape(overflow_desc[:3500])}</blockquote>",
                        parse_mode="HTML",
                        reply_to_message_id=sent_cached_msg.message_id,
                    )

                if status_msg_id:
                    try:
                        bot.delete_message(chat_id, status_msg_id)
                    except Exception:
                        pass
                return
            except Exception as e:
                logger.debug(f"Cache miss, re-downloading: {e}")

    # 2. التحميل الفعلي بأعلى جودة
    work_dir = tempfile.mkdtemp(prefix="dl_task_", dir=DOWNLOAD_DIR)
    try:
        if status_msg_id:
            action_label = (
                "جاري التحميل..."
                if mode == "video"
                else ("جاري استخراج الصوت..." if mode == "voice" else "جاري استخراج MP3...")
            )
            safe_edit_message(chat_id, status_msg_id, f"{badge}<b>{action_label}</b>", parse_mode="HTML")

        res = download_media_pipeline(url_or_query, mode, work_dir, is_search=is_search)

        if not res["status"]:
            err_text = f"<b>تعذر التحميل:</b>\n<blockquote>{html.escape(res.get('error', 'حدث خطأ أثناء التحميل.'))}</blockquote>"
            if status_msg_id:
                safe_edit_message(chat_id, status_msg_id, err_text, parse_mode="HTML")
            else:
                safe_send_message(chat_id, err_text, parse_mode="HTML", reply_to_message_id=reply_to_msg_id)
            return

        final_title = res.get("title") or req_saved_meta.get("title") or "منشور محمل"
        final_desc = res.get("description") or req_saved_meta.get("description") or final_title
        raw_author = str(res.get("author") or req_saved_meta.get("author") or "").strip()
        if p_info.get("key") == "instagram":
            raw_author = clean_instagram_author(raw_author)
        author_display = f"@{raw_author.lstrip('@')}" if (raw_author and p_info.get("key") == "instagram") else raw_author

        caption, clean_caption, overflow_desc = format_media_caption_with_description(
            badge=badge, title=final_title, description=final_desc,
            platform_name=p_info["name"], author_display=author_display, bot_uname=bot_uname,
        )

        last_sent_media_msg = None

        # أ) إرسال الفيديو مع تمرير width و height و duration الحقيقية للحفاظ على الدقة الكاملة
        if res["video_path"] and os.path.exists(res["video_path"]):
            bot.send_chat_action(chat_id, "upload_video")
            v_meta = get_video_stream_info(res["video_path"])
            send_kwargs = {"supports_streaming": True, "parse_mode": "HTML", "reply_to_message_id": reply_to_msg_id}
            if v_meta.get("width", 0) > 0 and v_meta.get("height", 0) > 0:
                send_kwargs["width"] = v_meta["width"]
                send_kwargs["height"] = v_meta["height"]
            if v_meta.get("duration", 0) > 0:
                send_kwargs["duration"] = int(v_meta["duration"])

            sent_vid_msg = None
            try:
                with open(res["video_path"], "rb") as vf:
                    sent_vid_msg = bot.send_video(chat_id, vf, caption=caption, reply_markup=extra_markup, **send_kwargs)
            except Exception:
                with open(res["video_path"], "rb") as vf:
                    sent_vid_msg = bot.send_video(
                        chat_id, vf, caption=clean_caption,
                        reply_markup=strip_advanced_button_fields(extra_markup) if extra_markup else None,
                        **send_kwargs,
                    )
            if sent_vid_msg:
                last_sent_media_msg = sent_vid_msg
            if sent_vid_msg and getattr(sent_vid_msg, "video", None) and not is_search:
                save_cached_media(norm_url, "video", "video", sent_vid_msg.video.file_id, final_title, final_desc, raw_author)
            cleanup_file_and_memory(res["video_path"])

        for extra_v in res.get("extra_videos", [])[:4]:
            if os.path.exists(extra_v):
                try:
                    ev_meta = get_video_stream_info(extra_v)
                    ek = {"supports_streaming": True}
                    if ev_meta.get("width", 0) > 0 and ev_meta.get("height", 0) > 0:
                        ek["width"] = ev_meta["width"]
                        ek["height"] = ev_meta["height"]
                    if ev_meta.get("duration", 0) > 0:
                        ek["duration"] = int(ev_meta["duration"])
                    with open(extra_v, "rb") as evf:
                        bot.send_video(chat_id, evf, caption=f"@{safe_uname}", **ek)
                except Exception:
                    pass
                finally:
                    cleanup_file_and_memory(extra_v)

        # ب) إرسال الصور (لغير يوتيوب)
        valid_images = [img_p for img_p in res["images"][:10] if os.path.exists(img_p)] if p_info.get("key") != "youtube" else []
        if valid_images:
            bot.send_chat_action(chat_id, "upload_photo")
            if len(valid_images) > 1:
                media_group, opened_files = [], []
                try:
                    for idx, img_p in enumerate(valid_images):
                        f_obj = open(img_p, "rb")
                        opened_files.append(f_obj)
                        if idx == 0:
                            media_group.append(types.InputMediaPhoto(f_obj, caption=clean_caption, parse_mode="HTML"))
                        else:
                            media_group.append(types.InputMediaPhoto(f_obj))
                    sent_mg = bot.send_media_group(chat_id, media_group, reply_to_message_id=reply_to_msg_id)
                    if sent_mg and isinstance(sent_mg, list):
                        last_sent_media_msg = sent_mg[0]
                except Exception:
                    for idx, img_p in enumerate(valid_images[:6]):
                        with open(img_p, "rb") as imf:
                            sent_p = bot.send_photo(
                                chat_id, imf,
                                caption=clean_caption if idx == 0 else f"({idx + 1}) — @{safe_uname}",
                                parse_mode="HTML", reply_to_message_id=reply_to_msg_id,
                            )
                            if idx == 0 and sent_p:
                                last_sent_media_msg = sent_p
                finally:
                    for fo in opened_files:
                        try:
                            fo.close()
                        except Exception:
                            pass
                    cleanup_file_and_memory(*valid_images)
            else:
                try:
                    with open(valid_images[0], "rb") as imf:
                        sent_p = bot.send_photo(
                            chat_id, imf, caption=clean_caption, parse_mode="HTML",
                            reply_to_message_id=reply_to_msg_id,
                            reply_markup=strip_advanced_button_fields(extra_markup) if extra_markup else None,
                        )
                        if sent_p:
                            last_sent_media_msg = sent_p
                finally:
                    cleanup_file_and_memory(valid_images[0])

        # ج) إرسال الرسالة الصوتية
        if res["voice_path"] and os.path.exists(res["voice_path"]):
            send_ui_optional_sticker(chat_id, "btn_yt_to_voice")
            bot.send_chat_action(chat_id, "record_voice")
            voice_cfg = get_ui_config("btn_yt_to_voice")
            custom_v_note = (voice_cfg.get("inner_content") or "الصوت المستخرج من الفيديو").strip()
            voice_caption = f"<b>{html.escape(custom_v_note)}</b> — @{safe_uname}" if valid_images else clean_caption
            try:
                with open(res["voice_path"], "rb") as voice_f:
                    sent_voice = bot.send_voice(chat_id, voice_f, caption=voice_caption, parse_mode="HTML", reply_to_message_id=reply_to_msg_id)
                if sent_voice and not last_sent_media_msg:
                    last_sent_media_msg = sent_voice
                if sent_voice and getattr(sent_voice, "voice", None) and not is_search and mode == "voice":
                    save_cached_media(norm_url, "voice", "voice", sent_voice.voice.file_id, final_title, final_desc, raw_author)
            finally:
                cleanup_file_and_memory(res["voice_path"])

        # د) إرسال ملف MP3
        if res["audio_path"] and os.path.exists(res["audio_path"]):
            bot.send_chat_action(chat_id, "upload_audio")
            try:
                with open(res["audio_path"], "rb") as aud_f:
                    sent_aud = bot.send_audio(
                        chat_id, aud_f, caption=clean_caption,
                        title=str(final_title)[:60], performer=str(raw_author or bot_uname)[:40],
                        parse_mode="HTML", reply_to_message_id=reply_to_msg_id,
                    )
                if sent_aud and not last_sent_media_msg:
                    last_sent_media_msg = sent_aud
                if sent_aud and getattr(sent_aud, "audio", None) and not is_search and mode == "mp3":
                    save_cached_media(norm_url, "mp3", "audio", sent_aud.audio.file_id, final_title, final_desc, raw_author)
            finally:
                cleanup_file_and_memory(res["audio_path"])

        if overflow_desc and last_sent_media_msg:
            safe_send_message(
                chat_id,
                f"<b>الوصف الكامل للمنشور:</b>\n<blockquote>{html.escape(overflow_desc[:3500])}</blockquote>",
                parse_mode="HTML",
                reply_to_message_id=last_sent_media_msg.message_id,
            )

        if status_msg_id:
            try:
                bot.delete_message(chat_id, status_msg_id)
            except Exception:
                pass

    except Exception as e:
        logger.error(f"خطأ أثناء إرسال الوسائط: {e}")
        if status_msg_id:
            safe_edit_message(chat_id, status_msg_id, f"<b>حدث خطأ أثناء الرفع:</b>\n<code>{html.escape(str(e)[:180])}</code>", parse_mode="HTML")
    finally:
        cleanup_file_and_memory(work_dir)
        purge_stale_temp_files()


def send_youtube_top5_search_card(chat_id, user, query_text, reply_to_msg_id=None):
    badge = format_premium_badge("sections", "", ui_key="btn_smart_search")
    wait_msg = safe_send_message(
        chat_id,
        f"{badge}<b>جاري البحث في يوتيوب عن:</b> <code>{html.escape(query_text[:60])}</code>...",
        parse_mode="HTML",
        reply_to_message_id=reply_to_msg_id,
    )

    def run_yt_search():
        results = search_youtube_top5(query_text)
        if not results:
            err_txt = (
                f"<b>لم يتم العثور على نتائج في يوتيوب لـ:</b> <code>{html.escape(query_text[:60])}</code>\n"
                "<blockquote>حاول كتابة اسم الفيديو بشكل أوضح (مثال: <code>ب سورة الملك</code>).</blockquote>"
            )
            if wait_msg:
                safe_edit_message(chat_id, wait_msg.message_id, err_txt, parse_mode="HTML")
            else:
                safe_send_message(chat_id, err_txt, parse_mode="HTML", reply_to_message_id=reply_to_msg_id)
            return

        req_id = save_url_request(user.id, chat_id, query_text, is_search=1, meta={"yt_results": results, "query": query_text})
        lines = [
            f"{badge}<b>نتائج بحث يوتيوب (أفضل {len(results)} فيديوهات):</b>",
            f"البحث: <code>{html.escape(query_text[:70])}</code>",
            "<blockquote>",
        ]
        markup = types.InlineKeyboardMarkup(row_width=1)

        for idx, item in enumerate(results, start=1):
            lines.append(f"<b>{idx}.</b> {html.escape(item['title'][:68])}\n   <code>{html.escape(item['channel'][:25])}</code> | <code>{html.escape(item['duration'])}</code>")
            btn_title = item["title"][:36] + ("..." if len(item["title"]) > 36 else "")
            markup.add(
                make_btn(
                    f"{idx} - {btn_title} ({item['duration']})",
                    callback_data=f"ytsel|{req_id}|{idx - 1}",
                    style="primary" if idx > 1 else "success",
                    scope="sections",
                )
            )

        lines.append("</blockquote>")
        lines.append("<b>اضغط على الفيديو المطلوب للتحميل:</b>")
        markup.add(make_btn(callback_data=f"dl|cancel|{req_id}", style="danger", scope="sections", ui_key="btn_cancel"))

        final_text = "\n".join(lines)
        if wait_msg:
            safe_edit_message(chat_id, wait_msg.message_id, final_text, reply_markup=markup, parse_mode="HTML")
        else:
            safe_send_message(chat_id, final_text, reply_markup=markup, parse_mode="HTML", reply_to_message_id=reply_to_msg_id)

    FAST_EXECUTOR.submit(run_yt_search)


def start_direct_link_download(chat_id, user, target_url, reply_to_msg_id):
    """
    تحميل مباشر وطبيعي لأي رابط بدون أي أسئلة أو كلمات مثل (مضغوط / قوية / أصلية).
    """
    badge = format_premium_badge("sections", "")
    p_info = detect_platform_info(target_url)
    req_id = save_url_request(user.id, chat_id, target_url, is_search=0)

    wait_msg = safe_send_message(
        chat_id,
        f"{badge}<b>جاري التحميل...</b>",
        parse_mode="HTML",
        reply_to_message_id=reply_to_msg_id,
    )
    DOWNLOAD_EXECUTOR.submit(
        execute_download_and_send,
        chat_id,
        target_url,
        "video",
        wait_msg.message_id if wait_msg else None,
        reply_to_msg_id,
        req_id,
        False,
        p_info["key"] == "youtube",
    )


def register_media_and_callback_handlers():
    @bot.message_handler(content_types=["text", "photo", "video", "document"])
    def handle_incoming_messages(message):
        user = message.from_user
        if not user:
            return
        register_user(user)

        chat_type = message.chat.type
        bot_uname = get_bot_username()
        text_content = (message.text or message.caption or "").strip()

        if not text_content:
            return

        # أ) في المجموعات
        if chat_type in ("group", "supergroup"):
            parsed_q, has_b_prefix = extract_youtube_search_query(text_content)
            is_mentioned = f"@{bot_uname.lower()}" in text_content.lower()

            if has_b_prefix and parsed_q and not extract_first_url(parsed_q):
                if is_user_banned(user.id):
                    return
                if not send_force_sub_prompt(message.chat.id, user, reply_to_message_id=message.message_id):
                    return
                send_youtube_top5_search_card(message.chat.id, user, parsed_q, reply_to_msg_id=message.message_id)
                return

            if not is_mentioned:
                return

            target_url = extract_first_url(text_content)
            if not target_url and message.reply_to_message:
                reply_text = message.reply_to_message.text or message.reply_to_message.caption or ""
                target_url = extract_first_url(reply_text)

            if not target_url:
                clean_query = re.sub(rf"@{re.escape(bot_uname)}", "", text_content, flags=re.IGNORECASE).strip()
                clean_query, _ = extract_youtube_search_query(clean_query)
                if clean_query and len(clean_query) >= 2:
                    if is_user_banned(user.id):
                        return
                    if not send_force_sub_prompt(message.chat.id, user, reply_to_message_id=message.message_id):
                        return
                    send_youtube_top5_search_card(message.chat.id, user, clean_query, reply_to_msg_id=message.message_id)
                    return

                safe_send_message(
                    message.chat.id,
                    f"ضع الرابط مع المنشن أو ابحث في يوتيوب بكتابة (<code>ب اسم الفيديو</code>):\n<code>@{html.escape(bot_uname)} https://...</code>",
                    reply_to_message_id=message.message_id,
                )
                return

            if is_user_banned(user.id):
                return
            if not send_force_sub_prompt(message.chat.id, user, reply_to_message_id=message.message_id):
                return

            start_direct_link_download(message.chat.id, user, target_url, message.message_id)
            return

        # ب) في المحادثة الخاصة
        if chat_type == "private":
            if is_user_banned(user.id):
                safe_send_message(message.chat.id, "عذراً، أنت محظور من استخدام البوت.", reply_to_message_id=message.message_id)
                return

            if get_setting("bot_enabled", "1") != "1" and not is_admin(user.id):
                safe_send_message(message.chat.id, "البوت في وضع الصيانة حالياً.", reply_to_message_id=message.message_id)
                return

            if not send_force_sub_prompt(message.chat.id, user, reply_to_message_id=message.message_id):
                return

            all_urls = extract_all_urls(text_content)
            if all_urls:
                for u in all_urls[:3]:
                    start_direct_link_download(message.chat.id, user, u, message.message_id)
                return

            if message.content_type == "text" and not text_content.startswith("/"):
                parsed_q, has_b_prefix = extract_youtube_search_query(text_content)
                if parsed_q and (has_b_prefix or len(parsed_q) >= 2):
                    send_youtube_top5_search_card(message.chat.id, user, parsed_q, reply_to_msg_id=message.message_id)

    @bot.callback_query_handler(func=lambda call: True)
    def handle_all_callbacks(call):
        user = call.from_user
        data = call.data or ""
        register_user(user)
        badge = format_premium_badge("sections", "")

        if data.startswith("adm_") or data == "admin_home":
            handle_admin_callback(call)
            return

        if data == "verify_subscription":
            if check_user_subscription(user.id):
                safe_answer_callback(call.id, "اشترك في جميع القنوات أولاً ثم اضغط تحقق.", show_alert=True)
                return
            safe_answer_callback(call.id, "تم التحقق بنجاح")
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
            except Exception:
                pass
            send_welcome_screen(call.message.chat.id, user)
            return

        if data == "user_help_guide":
            safe_answer_callback(call.id)
            send_ui_optional_sticker(call.message.chat.id, "btn_help_guide")
            cfg = get_ui_config("btn_help_guide")
            b_badge = format_premium_badge("sections", "", ui_key="btn_help_guide")
            raw_content = cfg.get("inner_content") or DEFAULT_HELP_GUIDE_TEXT
            guide_text = b_badge + raw_content.replace("{bot}", html.escape(get_bot_username())).replace("@البوت", f"@{html.escape(get_bot_username())}")
            safe_send_message(call.message.chat.id, guide_text, parse_mode="HTML")
            return

        if data == "user_smart_search_hint":
            safe_answer_callback(call.id)
            send_ui_optional_sticker(call.message.chat.id, "btn_smart_search")
            cfg = get_ui_config("btn_smart_search")
            b_badge = format_premium_badge("sections", "", ui_key="btn_smart_search")
            hint_text = b_badge + (cfg.get("inner_content") or DEFAULT_SEARCH_HINT_TEXT)
            safe_send_message(call.message.chat.id, hint_text, parse_mode="HTML")
            return

        if data.startswith("ytsel|"):
            parts = data.split("|")
            if len(parts) < 3:
                return
            _, search_req_id, sel_idx_str = parts[0], parts[1], parts[2]
            if not send_force_sub_prompt(call.message.chat.id, user):
                safe_answer_callback(call.id, "اشترك في القنوات أولاً.", show_alert=True)
                return

            req_data = get_url_request(search_req_id)
            if not req_data:
                safe_answer_callback(call.id, "انتهت صلاحية البحث، ابحث مجدداً.", show_alert=True)
                return

            yt_results = (req_data.get("meta") or {}).get("yt_results") or []
            sel_idx = int(sel_idx_str) if sel_idx_str.isdigit() else 0
            if sel_idx < 0 or sel_idx >= len(yt_results):
                safe_answer_callback(call.id, "اختيار غير صالح.", show_alert=True)
                return

            chosen_video = yt_results[sel_idx]
            chosen_url = chosen_video["url"]
            chosen_meta = {
                "platform": "يوتيوب",
                "key": "youtube",
                "title": chosen_video.get("title", "فيديو يوتيوب"),
                "description": "",
                "author": chosen_video.get("channel", "YouTube"),
            }
            new_req_id = save_url_request(user.id, call.message.chat.id, chosen_url, is_search=0, meta=chosen_meta)
            safe_answer_callback(call.id, "جاري التحميل...")
            DOWNLOAD_EXECUTOR.submit(
                execute_download_and_send,
                call.message.chat.id, chosen_url, "video", call.message.message_id, None, new_req_id, False, True,
            )
            return

        if data.startswith("dl|"):
            parts = data.split("|")
            if len(parts) < 3:
                return
            mode = parts[1]
            req_id = parts[-1]

            if mode == "cancel":
                safe_answer_callback(call.id, "تم الإلغاء.")
                try:
                    bot.delete_message(call.message.chat.id, call.message.message_id)
                except Exception:
                    pass
                return

            if not send_force_sub_prompt(call.message.chat.id, user):
                safe_answer_callback(call.id, "اشترك في القنوات أولاً.", show_alert=True)
                return

            req_data = get_url_request(req_id)
            if not req_data:
                safe_answer_callback(call.id, "انتهت صلاحية الطلب، أرسل الرابط مجدداً.", show_alert=True)
                return

            safe_answer_callback(call.id, "جاري التحميل...")
            status_msg_id = call.message.message_id if call.message.text else None
            if not status_msg_id:
                wait_label = "جاري استخراج MP3..." if mode == "mp3" else "جاري تحويل الفيديو إلى رسالة صوتية..."
                wait_m = safe_send_message(call.message.chat.id, f"{badge}<b>{wait_label}</b>", reply_to_message_id=call.message.message_id)
                status_msg_id = wait_m.message_id if wait_m else None

            is_search_flag = bool(req_data.get("is_search", 0))
            is_yt_link = "youtube.com" in req_data["url"].lower() or "youtu.be" in req_data["url"].lower()
            DOWNLOAD_EXECUTOR.submit(
                execute_download_and_send,
                call.message.chat.id,
                req_data["url"],
                mode,
                status_msg_id,
                call.message.message_id if not call.message.text else None,
                req_id,
                is_search_flag,
                is_yt_link,
            )
            return

    @bot.inline_handler(func=lambda query: True)
    def handle_inline_queries(inline_query):
        query_text = (inline_query.query or "").strip()
        bot_uname = get_bot_username()
        url = extract_first_url(query_text)
        results = []

        if not url and not query_text:
            results.append(
                types.InlineQueryResultArticle(
                    id="help_inline",
                    title="ضع الرابط أو ابحث في يوتيوب (مثال: ب سورة الكهف)",
                    description=f"مثال: @{bot_uname} https://www.instagram.com/reel/...",
                    input_message_content=types.InputTextMessageContent(
                        message_text=f"للتحميل أو البحث في يوتيوب، أرسل الرابط أو (ب + اسم الفيديو) إلى @{bot_uname}"
                    ),
                )
            )
        elif url:
            p_info = detect_platform_info(url)
            req_id = save_url_request(inline_query.from_user.id, inline_query.from_user.id, url, is_search=0)
            inline_kb = types.InlineKeyboardMarkup(row_width=2)
            inline_kb.row(
                make_btn("تحميل الفيديو", callback_data=f"dl|video|{req_id}", style="success", scope="sections"),
                make_btn(callback_data=f"dl|voice|{req_id}", style="primary", scope="sections", ui_key="btn_yt_to_voice"),
            )
            results.append(
                types.InlineQueryResultArticle(
                    id=f"dl_{req_id}",
                    title=f"{p_info['badge']} — اضغط للتحميل",
                    description=f"المنشور: {url[:60]}",
                    input_message_content=types.InputTextMessageContent(
                        message_text=f"<b>{html.escape(p_info['badge'])}</b>\n<blockquote><code>{html.escape(url[:90])}</code></blockquote>",
                        parse_mode="HTML",
                    ),
                    reply_markup=inline_kb,
                )
            )
        else:
            clean_q, _ = extract_youtube_search_query(query_text)
            yt_items = search_youtube_top5(clean_q or query_text)
            for idx, item in enumerate(yt_items[:5], start=1):
                req_id = save_url_request(inline_query.from_user.id, inline_query.from_user.id, item["url"], is_search=0, meta=item)
                yt_inline_kb = types.InlineKeyboardMarkup(row_width=2)
                yt_inline_kb.row(
                    make_btn("تحميل الفيديو", callback_data=f"dl|video|{req_id}", style="success", scope="sections"),
                    make_btn(callback_data=f"dl|voice|{req_id}", style="primary", scope="sections", ui_key="btn_yt_to_voice"),
                )
                results.append(
                    types.InlineQueryResultArticle(
                        id=f"yt_{req_id}_{idx}",
                        title=f"{idx} - {item['title']}",
                        description=f"{item['channel']} | {item['duration']}",
                        input_message_content=types.InputTextMessageContent(
                            message_text=(
                                f"<b>يوتيوب</b>\n"
                                f"<blockquote><b>العنوان:</b> {html.escape(item['title'])}\n"
                                f"<code>{html.escape(item['channel'])}</code> | <code>{html.escape(item['duration'])}</code></blockquote>"
                            ),
                            parse_mode="HTML",
                        ),
                        reply_markup=yt_inline_kb,
                    )
                )

        try:
            bot.answer_inline_query(inline_query.id, results, cache_time=5)
        except Exception as e:
            logger.debug(f"Inline query note: {e}")
