#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
معالجات لوحة تحكم الأدمن (/admin):
- إدخالات الأدمن النصية والملصقات وملفات الكوكيز والإذاعة والقنوات.
- جميع أزرار Callback الخاصة بلوحة التحكم.
"""

import os
import html
import json
import time
from datetime import datetime
from telebot import types

from config import (
    OWNER_ID,
    COOKIES_FILE_PATH,
    DEFAULT_WELCOME_TEXT,
    CUSTOMIZABLE_UI_KEYS,
    PLACEMENT_LABELS,
    THEME_LABELS,
)
from network import FAST_EXECUTOR
from database import (
    db_lock,
    get_db_connection,
    get_setting,
    set_setting,
    get_ui_config,
    update_ui_config,
    reset_all_ui_configs,
    is_admin,
    has_cookies_file,
    get_force_channels,
    clear_all_media_cache,
    clear_inaccessible_channel,
)
from bot_instance import (
    bot,
    admin_states,
    get_bot_id,
    utf16_slice,
    format_premium_badge,
    make_btn,
    SmartInlineButton,
    safe_answer_callback,
    safe_send_message,
    safe_edit_message,
)
from ui import (
    convert_text_and_entities_to_html,
    send_welcome_screen,
    build_admin_main_keyboard,
    get_admin_dashboard_text,
    build_ui_customization_list_keyboard,
    build_single_ui_key_editor,
)


def handle_admin_callback(call):
    user = call.from_user
    data = call.data or ""
    badge = format_premium_badge("sections", "")

    if not is_admin(user.id):
        safe_answer_callback(call.id, "للمشرفين فقط.", show_alert=True)
        return

    admin_states.pop(user.id, None)

    if data == "admin_home":
        safe_answer_callback(call.id)
        safe_edit_message(call.message.chat.id, call.message.message_id, get_admin_dashboard_text(), reply_markup=build_admin_main_keyboard())
        return

    if data == "adm_ui_custom_menu":
        safe_answer_callback(call.id)
        text = (
            f"{badge}<b>تخصيص جميع الأزرار والأقسام والملصقات:</b>\n"
            "<blockquote>"
            "• تعديل اسم أي زر.\n"
            "• تعديل النص والرسالة التي تظهر بداخل الزر أو القسم.\n"
            "• إضافة ملصق (Sticker) أو إيموجي مميز مع الزر أو تركه بدون."
            "</blockquote>\n"
            "<b>اختر الزر أو القسم الذي تريد تعديله:</b>"
        )
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=build_ui_customization_list_keyboard())
        return

    if data.startswith("adm_uikey|"):
        safe_answer_callback(call.id)
        ui_key = data.split("|", 1)[1]
        text, markup = build_single_ui_key_editor(ui_key)
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data.startswith("adm_uiedit_lbl|"):
        safe_answer_callback(call.id)
        ui_key = data.split("|", 1)[1]
        cfg = get_ui_config(ui_key)
        admin_states[user.id] = {"action": "ui_edit_label", "ui_key": ui_key}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data=f"adm_uikey|{ui_key}", style="danger", scope="sections"))
        safe_edit_message(
            call.message.chat.id,
            call.message.message_id,
            f"<b>تعديل اسم الزر ({html.escape(cfg['title'])}):</b>\nالاسم الحالي: <code>{html.escape(cfg['btn_label'])}</code>\n\n<b>أرسل الآن الاسم الجديد للزر:</b>",
            reply_markup=markup,
        )
        return

    if data.startswith("adm_uiedit_both|"):
        safe_answer_callback(call.id)
        ui_key = data.split("|", 1)[1]
        cfg = get_ui_config(ui_key)
        admin_states[user.id] = {"action": "ui_edit_label_and_sticker", "ui_key": ui_key, "temp_label_saved": False}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data=f"adm_uikey|{ui_key}", style="danger", scope="sections"))
        safe_edit_message(
            call.message.chat.id,
            call.message.message_id,
            f"<b>تعديل اسم الزر + الملصق ({html.escape(cfg['title'])}):</b>\n1. أرسل الآن <b>الاسم الجديد للزر</b> أولاً، وبعدها أرسل الملصق أو تخطّه:",
            reply_markup=markup,
        )
        return

    if data.startswith("adm_uiedit_cnt|"):
        safe_answer_callback(call.id)
        ui_key = data.split("|", 1)[1]
        cfg = get_ui_config(ui_key)
        admin_states[user.id] = {"action": "ui_edit_content", "ui_key": ui_key}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data=f"adm_uikey|{ui_key}", style="danger", scope="sections"))
        safe_edit_message(
            call.message.chat.id,
            call.message.message_id,
            f"<b>تعديل النص بداخل ({html.escape(cfg['title'])}):</b>\n<blockquote>{html.escape((cfg['inner_content'] or '')[:300])}</blockquote>\n<b>أرسل النص الجديد:</b>",
            reply_markup=markup,
        )
        return

    if data.startswith("adm_uiedit_stk|"):
        safe_answer_callback(call.id)
        ui_key = data.split("|", 1)[1]
        cfg = get_ui_config(ui_key)
        admin_states[user.id] = {"action": "ui_edit_sticker", "ui_key": ui_key}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data=f"adm_uikey|{ui_key}", style="danger", scope="sections"))
        safe_edit_message(
            call.message.chat.id,
            call.message.message_id,
            f"<b>إضافة ملصق أو إيموجي مميز لـ ({html.escape(cfg['title'])}):</b>\nأرسل الآن <b>الملصق (Sticker)</b> أو <b>إيموجي مميز (Custom Emoji)</b>:",
            reply_markup=markup,
        )
        return

    if data.startswith("adm_uidel_stk|"):
        ui_key = data.split("|", 1)[1]
        update_ui_config(ui_key, sticker_id="", custom_emoji_id="", custom_emoji_char="")
        safe_answer_callback(call.id, "تم حذف الملصق والإيموجي من هذا الزر.")
        text, markup = build_single_ui_key_editor(ui_key)
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data.startswith("adm_uireset_one|"):
        ui_key = data.split("|", 1)[1]
        defaults = CUSTOMIZABLE_UI_KEYS.get(ui_key, {})
        update_ui_config(
            ui_key,
            btn_label=defaults.get("default_label", ui_key),
            inner_content=defaults.get("default_content", ""),
            sticker_id="",
            custom_emoji_id="",
            custom_emoji_char="",
        )
        safe_answer_callback(call.id, "تمت استعادة الإعدادات الافتراضية لهذا الزر.")
        text, markup = build_single_ui_key_editor(ui_key)
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data == "adm_ui_reset_all":
        reset_all_ui_configs()
        safe_answer_callback(call.id, "تمت استعادة جميع الأزرار والأقسام للوضع الافتراضي.", show_alert=True)
        call.data = "adm_ui_custom_menu"
        handle_admin_callback(call)
        return

    if data == "adm_close":
        safe_answer_callback(call.id, "تم إغلاق اللوحة.")
        try:
            bot.delete_message(call.message.chat.id, call.message.message_id)
        except Exception:
            pass
        return

    if data == "adm_clear_cache":
        clear_all_media_cache()
        safe_answer_callback(call.id, "تم مسح جميع سجلات الكاش بنجاح.", show_alert=True)
        safe_edit_message(call.message.chat.id, call.message.message_id, get_admin_dashboard_text(), reply_markup=build_admin_main_keyboard())
        return

    if data == "adm_toggle_bot":
        new_val = "0" if get_setting("bot_enabled", "1") == "1" else "1"
        set_setting("bot_enabled", new_val)
        safe_answer_callback(call.id, f"حالة البوت: {'يعمل' if new_val == '1' else 'صيانة'}")
        safe_edit_message(call.message.chat.id, call.message.message_id, get_admin_dashboard_text(), reply_markup=build_admin_main_keyboard())
        return

    if data == "adm_toggle_fsub":
        new_val = "0" if get_setting("force_sub_enabled", "1") == "1" else "1"
        set_setting("force_sub_enabled", new_val)
        safe_answer_callback(call.id, f"الاشتراك الإجباري: {'مفعل' if new_val == '1' else 'معطل'}")
        safe_edit_message(call.message.chat.id, call.message.message_id, get_admin_dashboard_text(), reply_markup=build_admin_main_keyboard())
        return

    if data == "adm_cookies_menu":
        safe_answer_callback(call.id)
        c_exists = has_cookies_file()
        text = (
            f"{badge}<b>إدارة كوكيز المنصات (Instagram & YouTube Cookies):</b>\n"
            "<blockquote>"
            f"<b>الحالة الحالية:</b> <code>{'مفعل ومرفوع' if c_exists else 'غير مرفوع (يعمل تلقائياً بدون كوكيز)'}</code>\n\n"
            "<i>رفع ملف <code>cookies.txt</code> يفيد في فتح المنشورات المقيدة بالعمر أو الخاصة.</i>"
            "</blockquote>"
        )
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.row(
            make_btn("رفع ملف cookies.txt", callback_data="adm_up_cookies", style="success", scope="sections"),
            make_btn("حذف الكوكيز", callback_data="adm_del_cookies", style="danger", scope="sections"),
        )
        markup.row(make_btn("رجوع", callback_data="admin_home", style="primary", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data == "adm_up_cookies":
        safe_answer_callback(call.id)
        admin_states[user.id] = {"action": "upload_cookies_file"}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data="adm_cookies_menu", style="danger", scope="sections"))
        safe_edit_message(
            call.message.chat.id,
            call.message.message_id,
            "<b>أرسل الآن ملف <code>cookies.txt</code> كمستند (Document) أو الصق نص الكوكيز بصيغة Netscape:</b>",
            reply_markup=markup,
        )
        return

    if data == "adm_del_cookies":
        if os.path.exists(COOKIES_FILE_PATH):
            try:
                os.remove(COOKIES_FILE_PATH)
            except Exception:
                pass
        safe_answer_callback(call.id, "تم حذف ملف الكوكيز.")
        call.data = "adm_cookies_menu"
        handle_admin_callback(call)
        return

    if data == "adm_premium_menu":
        safe_answer_callback(call.id)
        curr_place = get_setting("premium_placement", "off")
        start_ce = get_setting("premium_start_emoji_id", "")
        sec_ce = get_setting("premium_sections_emoji_id", "")
        sticker_id = get_setting("welcome_sticker_id", "")

        text = (
            f"{badge}<b>إعدادات الملصقات والمميز العام (اختياري):</b>\n"
            "<blockquote>"
            f"الظهور العام: {html.escape(PLACEMENT_LABELS.get(curr_place, curr_place))}\n"
            f"إيموجي البداية: <code>{'مضاف' if start_ce else 'غير مضاف'}</code>\n"
            f"إيموجي الأقسام: <code>{'مضاف' if sec_ce else 'غير مضاف'}</code>\n"
            f"الملصق الترحيبي: <code>{'مضاف' if sticker_id else 'غير مضاف'}</code>"
            "</blockquote>"
        )
        markup = types.InlineKeyboardMarkup(row_width=2)
        place_btns = []
        for p_key, p_label in PLACEMENT_LABELS.items():
            check = "[محدد] " if curr_place == p_key else ""
            place_btns.append(make_btn(f"{check}{p_label}", callback_data=f"adm_set_place|{p_key}", style="success" if curr_place == p_key else "primary", scope="sections"))
        markup.row(place_btns[0], place_btns[1])
        markup.row(place_btns[2], place_btns[3])
        markup.row(
            make_btn("إضافة ملصق/مميز للبداية", callback_data="adm_add_prem|start", style="primary", scope="sections"),
            make_btn("إضافة ملصق/مميز للأقسام", callback_data="adm_add_prem|sections", style="primary", scope="sections"),
        )
        markup.row(
            make_btn("إضافة للكل", callback_data="adm_add_prem|both", style="success", scope="sections"),
            make_btn("مسح جميع الملصقات والمميز", callback_data="adm_clear_prem", style="danger", scope="sections"),
        )
        markup.row(make_btn("رجوع", callback_data="admin_home", style="danger", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data.startswith("adm_set_place|"):
        new_place = data.split("|")[1]
        set_setting("premium_placement", new_place)
        safe_answer_callback(call.id, f"تم التحديد: {PLACEMENT_LABELS.get(new_place, new_place)}")
        call.data = "adm_premium_menu"
        handle_admin_callback(call)
        return

    if data.startswith("adm_add_prem|"):
        safe_answer_callback(call.id)
        scope_choice = data.split("|")[1]
        action_map = {"start": "set_premium_start", "sections": "set_premium_sections", "both": "set_premium_both"}
        admin_states[user.id] = {"action": action_map.get(scope_choice, "set_premium_both")}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data="adm_premium_menu", style="danger", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, "<b>أرسل الآن الملصق (Sticker) أو الإيموجي المميز (Custom Emoji):</b>", reply_markup=markup)
        return

    if data == "adm_clear_prem":
        for k in ("welcome_sticker_id", "premium_start_emoji_id", "premium_start_emoji_char", "premium_sections_emoji_id", "premium_sections_emoji_char"):
            set_setting(k, "")
        set_setting("premium_placement", "off")
        safe_answer_callback(call.id, "تم مسح الملصقات والمميز العام بالكامل.")
        call.data = "adm_premium_menu"
        handle_admin_callback(call)
        return

    if data == "adm_colors_menu":
        safe_answer_callback(call.id)
        curr_theme = get_setting("color_theme", "mixed")
        text = f"<b>ثيم ألوان الأزرار والأقسام:</b>\n<blockquote>النمط الحالي: {html.escape(THEME_LABELS.get(curr_theme, curr_theme))}</blockquote>"
        markup = types.InlineKeyboardMarkup(row_width=2)
        theme_btns = []
        for t_key, t_label in THEME_LABELS.items():
            check = "[محدد] " if curr_theme == t_key else ""
            style_preview = t_key if t_key in ("primary", "success", "danger") else ("success" if curr_theme == t_key else "primary")
            theme_btns.append(SmartInlineButton(text=f"{check}{t_label}", callback_data=f"adm_set_theme|{t_key}", style=style_preview))
        markup.row(theme_btns[0], theme_btns[1])
        markup.row(theme_btns[2], theme_btns[3])
        markup.row(theme_btns[4], make_btn("رجوع", callback_data="admin_home", style="danger", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data.startswith("adm_set_theme|"):
        new_theme = data.split("|")[1]
        set_setting("color_theme", new_theme)
        safe_answer_callback(call.id, f"تم التفعيل: {THEME_LABELS.get(new_theme, new_theme)}")
        call.data = "adm_colors_menu"
        handle_admin_callback(call)
        return

    if data == "adm_stats":
        safe_answer_callback(call.id)
        with db_lock:
            conn = get_db_connection()
            total_u = conn.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
            banned_u = conn.execute("SELECT COUNT(*) as c FROM users WHERE is_banned = 1").fetchone()["c"]
            cached_c = conn.execute("SELECT COUNT(*) as c FROM media_cache").fetchone()["c"]
            recent_users = conn.execute("SELECT first_name, username, joined_at FROM users ORDER BY rowid DESC LIMIT 5").fetchall()
            conn.close()

        recent_lines = []
        for idx, ru in enumerate(recent_users, 1):
            uname = f"(@{html.escape(ru['username'])})" if ru["username"] else ""
            recent_lines.append(f"{idx}. {html.escape((ru['first_name'] or 'مستخدم')[:18])} {uname}")
        recent_text = "\n".join(recent_lines) + "\n" if recent_lines else "لا يوجد مشتركين بعد.\n"

        stats_msg = (
            f"{badge}<b>إحصائيات المشتركين:</b>\n"
            "<blockquote>"
            f"إجمالي المشتركين: <code>{total_u}</code>\n"
            f"نشط للإذاعة: <code>{total_u - banned_u}</code> | محظور: <code>{banned_u}</code>\n"
            f"الكاش: <code>{cached_c}</code>"
            "</blockquote>\n"
            f"<b>أحدث المشتركين المنضمين:</b>\n<blockquote>{recent_text}</blockquote>"
        )
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data="admin_home", style="danger", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, stats_msg, reply_markup=markup)
        return

    if data == "adm_fsub_menu":
        safe_answer_callback(call.id)
        channels = get_force_channels()
        text = f"{badge}<b>قنوات الاشتراك الإجباري:</b>\n<blockquote>"
        markup = types.InlineKeyboardMarkup(row_width=2)
        if not channels:
            text += "لا توجد قنوات مضافة.</blockquote>"
        else:
            bot_id = get_bot_id()
            for ch in channels:
                c_id_str = str(ch["chat_id"])
                short_title = (ch["title"] or "قناة")[:16]
                status_note = ""
                if bot_id:
                    try:
                        bm = bot.get_chat_member(c_id_str, bot_id)
                        if bm.status in ("administrator", "creator"):
                            status_note = " (البوت مشرف - مفعل)"
                            clear_inaccessible_channel(c_id_str)
                        else:
                            status_note = " (البوت ليس مشرفاً - ارفعه مشرفاً!)"
                    except Exception:
                        status_note = " (تعذر الوصول - ارفع البوت مشرفاً!)"
                text += f"• <b>{html.escape(ch['title'])}</b> <code>{html.escape(c_id_str)}</code>{status_note}\n"
                markup.add(make_btn(f"حذف: {short_title}", callback_data=f"adm_del_ch|{ch['chat_id']}", style="danger", scope="sections"))
            text += "</blockquote>"

        markup.row(
            make_btn("إضافة قناة", callback_data="adm_add_ch", style="success", scope="sections"),
            make_btn("مسح الكل", callback_data="adm_clear_chs", style="danger", scope="sections"),
        )
        markup.row(make_btn("رجوع", callback_data="admin_home", style="primary", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data == "adm_add_ch":
        safe_answer_callback(call.id)
        admin_states[user.id] = {"action": "add_force_channel"}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data="adm_fsub_menu", style="danger", scope="sections"))
        safe_edit_message(
            call.message.chat.id,
            call.message.message_id,
            "<b>ارفع البوت مشرفاً في القناة ثم أرسل معرفها (<code>@Ch</code>) أو وجّه منشوراً منها:</b>",
            reply_markup=markup,
        )
        return

    if data.startswith("adm_del_ch|"):
        ch_id = data.split("|", 1)[1]
        clear_inaccessible_channel(ch_id)
        with db_lock:
            conn = get_db_connection()
            conn.execute("DELETE FROM force_channels WHERE chat_id = ?", (ch_id,))
            conn.commit()
            conn.close()
        safe_answer_callback(call.id, "تم حذف القناة.")
        call.data = "adm_fsub_menu"
        handle_admin_callback(call)
        return

    if data == "adm_clear_chs":
        clear_inaccessible_channel(None)
        with db_lock:
            conn = get_db_connection()
            conn.execute("DELETE FROM force_channels")
            conn.commit()
            conn.close()
        safe_answer_callback(call.id, "تم مسح القنوات.")
        call.data = "adm_fsub_menu"
        handle_admin_callback(call)
        return

    if data == "adm_welcome_menu":
        safe_answer_callback(call.id)
        curr_welcome = get_setting("welcome_text", DEFAULT_WELCOME_TEXT)
        text = f"{badge}<b>رسالة البداية (/start):</b>\n<blockquote>{html.escape(curr_welcome[:250])}</blockquote>"
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.row(
            make_btn("تعديل النص", callback_data="adm_edit_welcome", style="primary", scope="sections"),
            make_btn("معاينة", callback_data="adm_preview_welcome", style="success", scope="sections"),
        )
        markup.row(
            make_btn("استعادة الافتراضي", callback_data="adm_reset_welcome", style="primary", scope="sections"),
            make_btn("رجوع", callback_data="admin_home", style="danger", scope="sections"),
        )
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data == "adm_edit_welcome":
        safe_answer_callback(call.id)
        admin_states[user.id] = {"action": "set_welcome_text"}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data="adm_welcome_menu", style="danger", scope="sections"))
        safe_edit_message(
            call.message.chat.id,
            call.message.message_id,
            "<b>أرسل نص الترحيب الجديد (يدعم الإيموجي المميز وكلمة <code>@البوت</code>):</b>",
            reply_markup=markup,
        )
        return

    if data == "adm_reset_welcome":
        set_setting("welcome_text", DEFAULT_WELCOME_TEXT)
        set_setting("welcome_entities", "[]")
        safe_answer_callback(call.id, "تمت استعادة الترحيب الافتراضي.")
        call.data = "adm_welcome_menu"
        handle_admin_callback(call)
        return

    if data == "adm_preview_welcome":
        safe_answer_callback(call.id, "جاري إرسال المعاينة...")
        send_welcome_screen(call.message.chat.id, user)
        return

    if data == "adm_broadcast_menu":
        safe_answer_callback(call.id)
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.row(
            make_btn("إذاعة نسخ", callback_data="adm_bc_copy", style="primary", scope="sections"),
            make_btn("إذاعة توجيه", callback_data="adm_bc_forward", style="success", scope="sections"),
        )
        markup.row(make_btn("رجوع", callback_data="admin_home", style="danger", scope="sections"))
        safe_edit_message(
            call.message.chat.id,
            call.message.message_id,
            f"{badge}<b>قسم الإذاعة:</b>\n<blockquote>اختر طريقة الإرسال لجميع المشتركين:</blockquote>",
            reply_markup=markup,
        )
        return

    if data in ("adm_bc_copy", "adm_bc_forward"):
        safe_answer_callback(call.id)
        admin_states[user.id] = {"action": "broadcast_copy" if data == "adm_bc_copy" else "broadcast_forward"}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data="adm_broadcast_menu", style="danger", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, "<b>أرسل الرسالة أو المنشور المراد إذاعته الآن:</b>", reply_markup=markup)
        return

    if data == "adm_ban_menu":
        safe_answer_callback(call.id)
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.row(
            make_btn("حظر عضو", callback_data="adm_do_ban", style="danger", scope="sections"),
            make_btn("فك حظر", callback_data="adm_do_unban", style="success", scope="sections"),
        )
        markup.row(make_btn("رجوع", callback_data="admin_home", style="primary", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, f"{badge}<b>إدارة الحظر:</b>", reply_markup=markup)
        return

    if data in ("adm_do_ban", "adm_do_unban"):
        safe_answer_callback(call.id)
        admin_states[user.id] = {"action": "ban_user" if data == "adm_do_ban" else "unban_user"}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data="adm_ban_menu", style="danger", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, "<b>أرسل الآيدي الرقمي (ID) للمستخدم:</b>", reply_markup=markup)
        return

    if data == "adm_admins_menu":
        safe_answer_callback(call.id)
        with db_lock:
            conn = get_db_connection()
            adms = conn.execute("SELECT * FROM admins").fetchall()
            conn.close()

        text = f"{badge}<b>المشرفين:</b>\n<blockquote>"
        markup = types.InlineKeyboardMarkup(row_width=2)
        for a in adms:
            aid = a["user_id"]
            role = "مالك" if aid == OWNER_ID else "مشرف"
            text += f"• <code>{aid}</code> ({role})\n"
            if aid != OWNER_ID and user.id == OWNER_ID:
                markup.add(make_btn(f"حذف {aid}", callback_data=f"adm_del_adm|{aid}", style="danger", scope="sections"))
        text += "</blockquote>"

        if user.id == OWNER_ID:
            markup.row(
                make_btn("إضافة مشرف", callback_data="adm_add_adm", style="success", scope="sections"),
                make_btn("رجوع", callback_data="admin_home", style="primary", scope="sections"),
            )
        else:
            markup.row(make_btn("رجوع", callback_data="admin_home", style="primary", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, text, reply_markup=markup)
        return

    if data == "adm_add_adm":
        if user.id != OWNER_ID:
            safe_answer_callback(call.id, "للمالك الأساسي فقط.", show_alert=True)
            return
        safe_answer_callback(call.id)
        admin_states[user.id] = {"action": "add_new_admin"}
        markup = types.InlineKeyboardMarkup()
        markup.add(make_btn("رجوع", callback_data="adm_admins_menu", style="danger", scope="sections"))
        safe_edit_message(call.message.chat.id, call.message.message_id, "<b>أرسل الآيدي الرقمي (ID) للمشرف الجديد:</b>", reply_markup=markup)
        return

    if data.startswith("adm_del_adm|"):
        if user.id != OWNER_ID:
            safe_answer_callback(call.id, "للمالك الأساسي فقط.", show_alert=True)
            return
        target_aid = int(data.split("|")[1])
        with db_lock:
            conn = get_db_connection()
            conn.execute("DELETE FROM admins WHERE user_id = ?", (target_aid,))
            conn.commit()
            conn.close()
        safe_answer_callback(call.id, "تمت إزالة المشرف.")
        call.data = "adm_admins_menu"
        handle_admin_callback(call)
        return


def register_admin_input_handler():
    @bot.message_handler(
        func=lambda m: m.from_user and m.from_user.id in admin_states,
        content_types=["text", "photo", "video", "audio", "voice", "document", "sticker", "animation"],
    )
    def handle_admin_state_inputs(message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            admin_states.pop(user_id, None)
            return

        state_info = admin_states.get(user_id)
        if not state_info:
            return
        action = state_info.get("action")

        if message.text and message.text.strip() in ("/cancel", "الغاء", "إلغاء"):
            admin_states.pop(user_id, None)
            safe_send_message(message.chat.id, "<b>تم الإلغاء والعودة للوحة التحكم.</b>", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
            return

        if action == "ui_edit_label":
            ui_key = state_info.get("ui_key")
            if not message.text:
                safe_send_message(message.chat.id, "يرجى إرسال الاسم الجديد للزر كنص.")
                return
            new_lbl = message.text.strip()[:60]
            found_ce_id, found_char = None, ""
            if message.entities:
                for ent in message.entities:
                    if ent.type == "custom_emoji" and getattr(ent, "custom_emoji_id", None):
                        found_ce_id = ent.custom_emoji_id
                        found_char = utf16_slice(message.text, ent.offset, ent.length) or ""
                        break
            if found_ce_id:
                update_ui_config(ui_key, btn_label=new_lbl, custom_emoji_id=found_ce_id, custom_emoji_char=found_char)
            else:
                update_ui_config(ui_key, btn_label=new_lbl)

            admin_states.pop(user_id, None)
            text, markup = build_single_ui_key_editor(ui_key)
            safe_send_message(message.chat.id, f"<b>تم تحديث اسم الزر بنجاح إلى:</b> <code>{html.escape(new_lbl)}</code>\n\n{text}", reply_markup=markup, reply_to_message_id=message.message_id)
            return

        if action == "ui_edit_label_and_sticker":
            ui_key = state_info.get("ui_key")
            if message.text and not state_info.get("temp_label_saved"):
                new_lbl = message.text.strip()[:60]
                update_ui_config(ui_key, btn_label=new_lbl)
                state_info["temp_label_saved"] = True
                safe_send_message(
                    message.chat.id,
                    f"<b>تم حفظ اسم الزر:</b> <code>{html.escape(new_lbl)}</code>\nالآن أرسل <b>الملصق</b> أو <b>الإيموجي المميز</b>، أو أرسل <code>تخطي</code>:",
                    reply_to_message_id=message.message_id,
                )
                return
            if message.text and message.text.strip() in ("تخطي", "بدون", "لا", "skip"):
                admin_states.pop(user_id, None)
                text, markup = build_single_ui_key_editor(ui_key)
                safe_send_message(message.chat.id, f"<b>تم الحفظ بدون إضافة ملصق.</b>\n\n{text}", reply_markup=markup, reply_to_message_id=message.message_id)
                return
            if message.content_type == "sticker":
                st_id = message.sticker.file_id
                ce_id = getattr(message.sticker, "custom_emoji_id", "") or ""
                ce_ch = getattr(message.sticker, "emoji", "") or ""
                update_ui_config(ui_key, sticker_id=st_id, custom_emoji_id=ce_id if ce_id else None, custom_emoji_char=ce_ch if ce_id else None)
                admin_states.pop(user_id, None)
                text, markup = build_single_ui_key_editor(ui_key)
                safe_send_message(message.chat.id, f"<b>تم حفظ الملصق مع الزر بنجاح.</b>\n\n{text}", reply_markup=markup, reply_to_message_id=message.message_id)
                return
            if message.text and message.entities:
                for ent in message.entities:
                    if ent.type == "custom_emoji" and getattr(ent, "custom_emoji_id", None):
                        ce_id = ent.custom_emoji_id
                        ce_ch = utf16_slice(message.text, ent.offset, ent.length) or ""
                        update_ui_config(ui_key, custom_emoji_id=ce_id, custom_emoji_char=ce_ch)
                        admin_states.pop(user_id, None)
                        text, markup = build_single_ui_key_editor(ui_key)
                        safe_send_message(message.chat.id, f"<b>تم حفظ الإيموجي المميز للزر بنجاح.</b>\n\n{text}", reply_markup=markup, reply_to_message_id=message.message_id)
                        return
            safe_send_message(message.chat.id, "أرسل الملصق/الإيموجي المميز، أو أرسل <code>تخطي</code> أو <code>إلغاء</code>.", reply_to_message_id=message.message_id)
            return

        if action == "ui_edit_content":
            ui_key = state_info.get("ui_key")
            if not message.text:
                safe_send_message(message.chat.id, "يرجى إرسال النص الجديد.")
                return
            entities_list = [
                {
                    "type": ent.type, "offset": ent.offset, "length": ent.length,
                    "url": getattr(ent, "url", None), "language": getattr(ent, "language", None),
                    "custom_emoji_id": getattr(ent, "custom_emoji_id", None),
                }
                for ent in (message.entities or [])
            ]
            html_content = convert_text_and_entities_to_html(message.text, entities_list) if entities_list else message.text
            update_ui_config(ui_key, inner_content=html_content)
            admin_states.pop(user_id, None)
            text, markup = build_single_ui_key_editor(ui_key)
            safe_send_message(message.chat.id, f"<b>تم تحديث النص الداخلي بنجاح.</b>\n\n{text}", reply_markup=markup, reply_to_message_id=message.message_id)
            return

        if action == "ui_edit_sticker":
            ui_key = state_info.get("ui_key")
            if message.content_type == "sticker":
                st_id = message.sticker.file_id
                ce_id = getattr(message.sticker, "custom_emoji_id", "") or ""
                ce_ch = getattr(message.sticker, "emoji", "") or ""
                update_ui_config(ui_key, sticker_id=st_id, custom_emoji_id=ce_id if ce_id else None, custom_emoji_char=ce_ch if ce_id else None)
                admin_states.pop(user_id, None)
                text, markup = build_single_ui_key_editor(ui_key)
                safe_send_message(message.chat.id, f"<b>تم إرفاق الملصق بنجاح.</b>\n\n{text}", reply_markup=markup, reply_to_message_id=message.message_id)
                return
            if message.text and message.entities:
                for ent in message.entities:
                    if ent.type == "custom_emoji" and getattr(ent, "custom_emoji_id", None):
                        update_ui_config(ui_key, custom_emoji_id=ent.custom_emoji_id, custom_emoji_char=utf16_slice(message.text, ent.offset, ent.length) or "")
                        admin_states.pop(user_id, None)
                        text, markup = build_single_ui_key_editor(ui_key)
                        safe_send_message(message.chat.id, f"<b>تم إرفاق الإيموجي المميز بنجاح.</b>\n\n{text}", reply_markup=markup, reply_to_message_id=message.message_id)
                        return
            safe_send_message(message.chat.id, "يرجى إرسال ملصق أو إيموجي مميز، أو أرسل <code>إلغاء</code>.", reply_to_message_id=message.message_id)
            return

        if action == "set_welcome_text":
            if not message.text:
                safe_send_message(message.chat.id, "يرجى إرسال نص رسالة الترحيب.")
                return
            entities_list = [
                {
                    "type": ent.type, "offset": ent.offset, "length": ent.length,
                    "url": getattr(ent, "url", None), "language": getattr(ent, "language", None),
                    "custom_emoji_id": getattr(ent, "custom_emoji_id", None),
                }
                for ent in (message.entities or [])
            ]
            set_setting("welcome_text", message.text)
            set_setting("welcome_entities", json.dumps(entities_list, ensure_ascii=False))
            admin_states.pop(user_id, None)
            safe_send_message(message.chat.id, "<b>تم تحديث رسالة البداية (/start) بنجاح.</b>", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
            return

        if action == "upload_cookies_file":
            if message.content_type == "document" and message.document:
                try:
                    file_info = bot.get_file(message.document.file_id)
                    downloaded = bot.download_file(file_info.file_path)
                    with open(COOKIES_FILE_PATH, "wb") as cf:
                        cf.write(downloaded)
                    admin_states.pop(user_id, None)
                    safe_send_message(message.chat.id, "<b>تم حفظ وتفعيل ملف الكوكيز (cookies.txt) بنجاح.</b>", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
                    return
                except Exception as e:
                    safe_send_message(message.chat.id, f"خطأ أثناء حفظ الملف: <code>{html.escape(str(e))}</code>")
                    return
            elif message.text and ("# Netscape HTTP Cookie File" in message.text or "instagram.com" in message.text or "youtube.com" in message.text):
                with open(COOKIES_FILE_PATH, "w", encoding="utf-8") as cf:
                    cf.write(message.text)
                admin_states.pop(user_id, None)
                safe_send_message(message.chat.id, "<b>تم حفظ نص الكوكيز بنجاح.</b>", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
                return
            safe_send_message(message.chat.id, "<b>أرسل ملف <code>cookies.txt</code> كمستند أو الصق نص الكوكيز، أو أرسل <code>إلغاء</code>.</b>", reply_to_message_id=message.message_id)
            return

        if action in ("set_premium_start", "set_premium_sections", "set_premium_both"):
            target_scope = "start" if action == "set_premium_start" else ("sections" if action == "set_premium_sections" else "both")
            if message.content_type == "sticker":
                file_id = message.sticker.file_id
                ce_id = getattr(message.sticker, "custom_emoji_id", "") or ""
                emoji_ch = getattr(message.sticker, "emoji", "") or ""
                if target_scope in ("start", "both"):
                    set_setting("welcome_sticker_id", file_id)
                    if ce_id:
                        set_setting("premium_start_emoji_id", ce_id)
                        set_setting("premium_start_emoji_char", emoji_ch)
                if target_scope in ("sections", "both") and ce_id:
                    set_setting("premium_sections_emoji_id", ce_id)
                    set_setting("premium_sections_emoji_char", emoji_ch)
                if get_setting("premium_placement", "off") == "off":
                    set_setting("premium_placement", "both" if target_scope == "both" else ("start_only" if target_scope == "start" else "sections_only"))
                admin_states.pop(user_id, None)
                safe_send_message(message.chat.id, "<b>تم حفظ الملصق بنجاح.</b>", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
                return
            if message.text and message.entities:
                for ent in message.entities:
                    if ent.type == "custom_emoji" and getattr(ent, "custom_emoji_id", None):
                        found_ce_id = ent.custom_emoji_id
                        found_char = utf16_slice(message.text, ent.offset, ent.length) or ""
                        if target_scope in ("start", "both"):
                            set_setting("premium_start_emoji_id", found_ce_id)
                            set_setting("premium_start_emoji_char", found_char)
                        if target_scope in ("sections", "both"):
                            set_setting("premium_sections_emoji_id", found_ce_id)
                            set_setting("premium_sections_emoji_char", found_char)
                        if get_setting("premium_placement", "off") == "off":
                            set_setting("premium_placement", "both" if target_scope == "both" else ("start_only" if target_scope == "start" else "sections_only"))
                        admin_states.pop(user_id, None)
                        safe_send_message(message.chat.id, f"<b>تم تفعيل الإيموجي المميز بنجاح:</b>\n<code>{html.escape(found_ce_id)}</code>", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
                        return
            safe_send_message(message.chat.id, "<b>أرسل إيموجي مميز أو ملصق، أو أرسل <code>إلغاء</code>.</b>", reply_to_message_id=message.message_id)
            return

        if action == "add_force_channel":
            chat_id_str, title_str, invite_link_str = None, "قناة البوت", None
            if message.forward_from_chat and message.forward_from_chat.type in ("channel", "supergroup"):
                f_chat = message.forward_from_chat
                chat_id_str = str(f_chat.id)
                title_str = f_chat.title or "قناة البوت"
                if f_chat.username:
                    invite_link_str = f"https://t.me/{f_chat.username}"
                else:
                    try:
                        invite_link_str = bot.export_chat_invite_link(f_chat.id)
                    except Exception:
                        invite_link_str = "https://t.me/"
            elif message.text:
                parts = message.text.strip().split()
                target = parts[0]
                if target.startswith("https://t.me/"):
                    uname = target.replace("https://t.me/", "").strip("/")
                    if not uname.startswith("+"):
                        target = f"@{uname}"
                try:
                    chat_info = bot.get_chat(target)
                    chat_id_str = str(chat_info.id)
                    title_str = chat_info.title or target
                    if len(parts) > 1 and parts[1].startswith("http"):
                        invite_link_str = parts[1]
                    elif chat_info.username:
                        invite_link_str = f"https://t.me/{chat_info.username}"
                    elif chat_info.invite_link:
                        invite_link_str = chat_info.invite_link
                    else:
                        invite_link_str = bot.export_chat_invite_link(chat_info.id)
                except Exception as e:
                    safe_send_message(message.chat.id, f"<b>تعذر الوصول للقناة:</b> <code>{html.escape(str(e))}</code>\nتأكد من رفع البوت مشرفاً في القناة.", reply_to_message_id=message.message_id)
                    return

            if chat_id_str:
                bot_id = get_bot_id()
                if bot_id:
                    try:
                        bot_member = bot.get_chat_member(chat_id_str, bot_id)
                        if bot_member.status not in ("administrator", "creator"):
                            safe_send_message(message.chat.id, f"<b>تنبيه:</b> البوت ليس مشرفاً في قناة <b>{html.escape(title_str)}</b>. ارفعه مشرفاً أولاً.", reply_to_message_id=message.message_id)
                            return
                    except Exception as e:
                        safe_send_message(message.chat.id, f"<b>تنبيه:</b> لم يتمكن البوت من التحقق من صلاحيات الإشراف (<code>{html.escape(str(e))}</code>).", reply_to_message_id=message.message_id)
                        return

                clear_inaccessible_channel(chat_id_str)
                with db_lock:
                    conn = get_db_connection()
                    conn.execute(
                        "INSERT OR REPLACE INTO force_channels (chat_id, title, invite_link, added_at) VALUES (?, ?, ?, ?)",
                        (chat_id_str, title_str, invite_link_str, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                    )
                    conn.commit()
                    conn.close()
                admin_states.pop(user_id, None)
                safe_send_message(message.chat.id, f"<b>تمت إضافة القناة بنجاح:</b> {html.escape(title_str)}", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
            return

        if action in ("broadcast_copy", "broadcast_forward"):
            admin_states.pop(user_id, None)
            with db_lock:
                conn = get_db_connection()
                users_rows = conn.execute("SELECT user_id FROM users").fetchall()
                conn.close()

            status_msg = safe_send_message(message.chat.id, f"<b>جاري الإذاعة إلى <code>{len(users_rows)}</code> مستخدم...</b>", reply_to_message_id=message.message_id)

            def run_broadcast():
                sent, failed = 0, 0
                for r in users_rows:
                    try:
                        if action == "broadcast_forward":
                            bot.forward_message(r["user_id"], message.chat.id, message.message_id)
                        else:
                            bot.copy_message(r["user_id"], message.chat.id, message.message_id)
                        sent += 1
                        time.sleep(0.04)
                    except Exception:
                        failed += 1
                if status_msg:
                    safe_edit_message(message.chat.id, status_msg.message_id, f"<b>اكتملت الإذاعة</b> (تم: <code>{sent}</code> | فشل: <code>{failed}</code>)", reply_markup=build_admin_main_keyboard())

            FAST_EXECUTOR.submit(run_broadcast)
            return

        if action in ("ban_user", "unban_user"):
            if not message.text or not message.text.strip().isdigit():
                safe_send_message(message.chat.id, "يرجى إرسال الآيدي الرقمي (ID) للمستخدم.")
                return
            target_uid = int(message.text.strip())
            ban_val = 1 if action == "ban_user" else 0
            with db_lock:
                conn = get_db_connection()
                conn.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (ban_val, target_uid))
                conn.commit()
                conn.close()
            admin_states.pop(user_id, None)
            safe_send_message(message.chat.id, f"تم <b>{'حظر' if ban_val == 1 else 'فك حظر'}</b> المستخدم <code>{target_uid}</code>.", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
            return

        if action == "add_new_admin":
            if not message.text or not message.text.strip().isdigit():
                safe_send_message(message.chat.id, "يرجى إرسال الآيدي الرقمي (ID) للمشرف الجديد.")
                return
            new_adm_id = int(message.text.strip())
            with db_lock:
                conn = get_db_connection()
                conn.execute("INSERT OR REPLACE INTO admins (user_id, added_by, added_at) VALUES (?, ?, ?)", (new_adm_id, user_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                conn.commit()
                conn.close()
            admin_states.pop(user_id, None)
            safe_send_message(message.chat.id, f"تمت ترقية <code>{new_adm_id}</code> إلى مشرف بنجاح.", reply_markup=build_admin_main_keyboard(), reply_to_message_id=message.message_id)
            return
