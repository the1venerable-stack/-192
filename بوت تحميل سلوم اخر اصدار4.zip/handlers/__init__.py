#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تسجيل جميع معالجات البوت بالترتيب الصحيح.
"""

from handlers.commands import register_command_handlers
from handlers.admin import register_admin_input_handler
from handlers.media import register_media_and_callback_handlers


def register_all_handlers():
    register_command_handlers()
    register_admin_input_handler()
    register_media_and_callback_handlers()
