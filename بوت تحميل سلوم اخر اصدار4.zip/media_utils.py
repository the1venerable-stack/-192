#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
أدوات معالجة الوسائط (FFmpeg / FFprobe):
- الحفاظ على أعلى دقة ممكنة للفيديو (بدون ضغط مدمر للجودة) وتمرير الأبعاد الحقيقية لتيليجرام.
- تحويل الصوت إلى OGG / MP3 بجودة عالية.
- فحص وتنزيل الملفات الثنائية وتنظيف الملفات المؤقتة.
"""

import os
import gc
import json
import time
import struct
import shutil
import hashlib
import subprocess

from config import DOWNLOAD_DIR, TELEGRAM_MAX_UPLOAD_MB
from network import http_session, DEFAULT_UA, logger


def check_ffmpeg_installed():
    return shutil.which("ffmpeg") is not None


def get_video_stream_info(file_path):
    """
    يستخرج بيانات الفيديو (وجود مسار فيديو، الكودك، العرض، الارتفاع، المدة) عبر ffprobe
    لتمريرها إلى send_video حتى يعرض تيليجرام الفيديو بدقته الكاملة بدون تشويه.
    """
    info = {"has_video": False, "codec": "", "width": 0, "height": 0, "duration": 0.0}
    if not file_path or not os.path.exists(file_path):
        return info

    if not shutil.which("ffprobe"):
        ext = os.path.splitext(file_path)[1].lower()
        info["has_video"] = ext in (".mp4", ".mkv", ".mov", ".webm", ".avi", ".flv", ".ts", ".m4v", ".3gp")
        return info

    cmd = [
        "ffprobe", "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=codec_name,width,height:format=duration",
        "-of", "json",
        file_path,
    ]
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        data = json.loads(res.stdout or "{}")
        streams = data.get("streams") or []
        if streams:
            st = streams[0]
            codec = (st.get("codec_name") or "").lower()
            if codec and codec not in ("png", "mjpeg", "webp", "gif", "bmp"):
                info["has_video"] = True
                info["codec"] = codec
                info["width"] = int(st.get("width") or 0)
                info["height"] = int(st.get("height") or 0)
        dur = (data.get("format") or {}).get("duration")
        if dur:
            info["duration"] = float(dur)
    except Exception:
        pass
    return info


def probe_has_video_stream(file_path):
    return get_video_stream_info(file_path)["has_video"]


def prepare_high_quality_video(input_path, work_dir, prefix="video"):
    """
    يجهّز الفيديو للإرسال بأعلى جودة ممكنة ومتوافقة تماماً مع مشغّل تيليجرام:
    1. إذا كان MP4 بكودك H.264 وحجمه ضمن حد تيليجرام (49MB): يرسله كما هو 100% بدون أي إعادة ترميز.
    2. إذا كان بحاوية أخرى (MKV/WEBM) بكودك H.264 وحجمه <= 49MB: ينقله لحاوية MP4 بـ (-c copy) بدون فقدان جودة.
    3. إذا كان الكودك غير متوافق (مثل AV1/VP9) أو تجاوز حد 49MB: يعيد ترميزه بجودة عالية جداً (CRF 19 أو أعلى بت ريت يسمح به حد 48MB).
    """
    if not input_path or not os.path.exists(input_path):
        return input_path
    if not check_ffmpeg_installed():
        return input_path

    size_mb = os.path.getsize(input_path) / (1024 * 1024)
    v_info = get_video_stream_info(input_path)
    codec = v_info.get("codec", "")
    is_mp4 = input_path.lower().endswith(".mp4")
    is_h264 = codec in ("h264", "avc1", "")

    # حالة 1: ملف MP4 جاهز بكودك H.264 وضمن حد تيليجرام -> صفر فقدان جودة
    if is_mp4 and is_h264 and size_mb <= TELEGRAM_MAX_UPLOAD_MB:
        return input_path

    out_path = os.path.join(work_dir, f"{prefix}_hq.mp4")

    # حالة 2: حاوية غير MP4 لكن الكودك H.264 وضمن حد تيليجرام -> نسخ خام فوري
    if not is_mp4 and is_h264 and size_mb <= TELEGRAM_MAX_UPLOAD_MB:
        cmd_copy = [
            "ffmpeg", "-y",
            "-i", input_path,
            "-c:v", "copy",
            "-c:a", "aac",
            "-b:a", "192k",
            "-movflags", "+faststart",
            out_path,
        ]
        res = subprocess.run(cmd_copy, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
        if res.returncode == 0 and os.path.exists(out_path) and os.path.getsize(out_path) > 4096:
            if os.path.abspath(input_path) != os.path.abspath(out_path):
                cleanup_file_and_memory(input_path)
            return out_path
        return input_path

    # حالة 3: تجاوز حد 49MB أو كودك غير H.264 -> ترميز عالي الجودة متوافق مع تيليجرام
    duration = v_info.get("duration") or 0.0
    extra_args = []
    if size_mb > TELEGRAM_MAX_UPLOAD_MB and duration > 2:
        # حساب أعلى بت ريت ممكن يبقي الملف تحت 47MB بجودة ممتازة
        target_total_kbps = int(((47.0 * 1024 * 8) / duration))
        audio_kbps = 128 if target_total_kbps > 600 else 96
        video_kbps = max(400, target_total_kbps - audio_kbps)
        extra_args = [
            "-b:v", f"{video_kbps}k",
            "-maxrate", f"{int(video_kbps * 1.15)}k",
            "-bufsize", f"{video_kbps * 2}k",
            "-c:a", "aac", "-b:a", f"{audio_kbps}k",
        ]
    else:
        extra_args = [
            "-crf", "19",
            "-c:a", "aac", "-b:a", "192k",
        ]

    vf_args = []
    if v_info.get("height", 0) > 1080 and size_mb > TELEGRAM_MAX_UPLOAD_MB:
        vf_args = ["-vf", "scale=-2:1080"]

    cmd_enc = [
        "ffmpeg", "-y",
        "-i", input_path,
        *vf_args,
        "-c:v", "libx264",
        "-preset", "fast",
        "-pix_fmt", "yuv420p",
        *extra_args,
        "-movflags", "+faststart",
        out_path,
    ]
    res = subprocess.run(cmd_enc, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=240)
    if res.returncode == 0 and os.path.exists(out_path) and os.path.getsize(out_path) > 4096:
        if os.path.abspath(input_path) != os.path.abspath(out_path):
            cleanup_file_and_memory(input_path)
        return out_path
    return input_path


def convert_to_voice_ogg(input_path, output_path):
    if not check_ffmpeg_installed():
        return input_path
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-vn",
        "-c:a", "libopus",
        "-b:a", "96k",
        "-vbr", "on",
        "-compression_level", "10",
        output_path,
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    if res.returncode == 0 and os.path.exists(output_path) and os.path.getsize(output_path) > 0:
        return output_path
    return input_path


def convert_to_mp3(input_path, output_path):
    if not check_ffmpeg_installed():
        return input_path
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-vn",
        "-c:a", "libmp3lame",
        "-b:a", "256k",
        output_path,
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    if res.returncode == 0 and os.path.exists(output_path) and os.path.getsize(output_path) > 0:
        return output_path
    return input_path


def is_valid_media_binary_header(head_bytes, expected_type=None):
    if not head_bytes or len(head_bytes) < 12:
        return False
    stripped = head_bytes[:256].lstrip().lower()
    bad_prefixes = (
        b"<!doctype",
        b"<html",
        b"<head",
        b"<script",
        b"<body",
        b"<?xml",
        b"{\"error",
        b"{\"status\":\"error",
        b"{\"success\":false",
        b"{\"success\":0",
        b"error:",
        b"access denied",
        b"403 forbidden",
        b"404 not found",
    )
    if stripped.startswith(bad_prefixes):
        return False

    if expected_type == "video":
        return (
            b"ftyp" in head_bytes[:32]
            or b"moov" in head_bytes[:32]
            or head_bytes.startswith(b"\x1a\x45\xdf\xa3")
            or head_bytes.startswith(b"FLV")
            or head_bytes.startswith(b"RIFF")
            or head_bytes.startswith(b"OggS")
            or head_bytes[0:1] == b"\x47"
        )

    if expected_type == "audio":
        return (
            head_bytes.startswith(b"ID3")
            or head_bytes[:2] in (b"\xff\xfb", b"\xff\xf3", b"\xff\xf2", b"\xff\xf1", b"\xff\xe3")
            or b"ftyp" in head_bytes[:32]
            or head_bytes.startswith(b"OggS")
            or head_bytes.startswith(b"RIFF")
            or head_bytes.startswith(b"fLaC")
            or head_bytes.startswith(b"\x1a\x45\xdf\xa3")
        )

    return True


def download_binary_file(media_url, dest_path, headers=None, min_size=2048, expected_type=None):
    if not media_url or not isinstance(media_url, str) or not media_url.startswith(("http://", "https://")):
        return False
    h = {
        "User-Agent": DEFAULT_UA,
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
        "Connection": "keep-alive",
    }
    if headers and isinstance(headers, dict):
        h.update(headers)

    effective_min = max(min_size, 24576 if expected_type == "video" else (8192 if expected_type == "audio" else min_size))
    tmp_path = f"{dest_path}.part"
    try:
        r = http_session.get(media_url, headers=h, stream=True, timeout=(6, 25), verify=False, allow_redirects=True)
        if r.status_code in (200, 206):
            ctype = (r.headers.get("Content-Type") or "").lower()
            if "text/html" in ctype or "application/json" in ctype or "text/plain" in ctype:
                return False
            if expected_type == "image" and "video/" in ctype:
                return False
            if expected_type == "video" and ("image/" in ctype or "audio/mpeg" in ctype):
                return False

            first_chunk = b""
            total_written = 0
            with open(tmp_path, "wb") as f:
                for chunk in r.iter_content(65536):
                    if not chunk:
                        continue
                    if not first_chunk:
                        first_chunk = chunk[:512]
                        if not is_valid_media_binary_header(first_chunk, expected_type=expected_type):
                            break
                    f.write(chunk)
                    total_written += len(chunk)

            if total_written >= effective_min and is_valid_media_binary_header(first_chunk, expected_type=expected_type):
                os.replace(tmp_path, dest_path)
                if expected_type == "video" and shutil.which("ffprobe"):
                    if not probe_has_video_stream(dest_path):
                        try:
                            os.remove(dest_path)
                        except Exception:
                            pass
                        return False
                return True
    except Exception as e:
        logger.debug(f"Binary download error: {e}")
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass
    return False


def get_image_dimensions_fast(file_path):
    try:
        with open(file_path, "rb") as f:
            head = f.read(32)
            if len(head) < 24:
                return 0, 0
            if head.startswith(b"\x89PNG\r\n\x1a\n") and head[12:16] == b"IHDR":
                w, h = struct.unpack(">LL", head[16:24])
                return int(w), int(h)
            if head[:6] in (b"GIF87a", b"GIF89a"):
                w, h = struct.unpack("<HH", head[6:10])
                return int(w), int(h)
            if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
                chunk = head[12:16]
                if chunk == b"VP8 ":
                    w, h = struct.unpack("<HH", head[26:30])
                    return int(w & 0x3FFF), int(h & 0x3FFF)
                if chunk == b"VP8L":
                    b0, b1, b2, b3 = head[21:25]
                    w = 1 + (((b1 & 0x3F) << 8) | b0)
                    h = 1 + (((b3 & 0x0F) << 10) | (b2 << 2) | ((b1 & 0xC0) >> 6))
                    return int(w), int(h)
                if chunk == b"VP8X":
                    w = 1 + int.from_bytes(head[24:27], "little")
                    h = 1 + int.from_bytes(head[27:30], "little")
                    return int(w), int(h)
            if head[:2] == b"\xff\xd8":
                f.seek(2)
                while True:
                    marker = f.read(2)
                    if len(marker) < 2 or marker[0] != 0xFF:
                        break
                    mtype = marker[1]
                    while mtype == 0xFF:
                        b = f.read(1)
                        if not b:
                            break
                        mtype = b[0]
                    if mtype in (0xD8, 0xD9) or (0xD0 <= mtype <= 0xD7):
                        continue
                    len_bytes = f.read(2)
                    if len(len_bytes) < 2:
                        break
                    seg_len = struct.unpack(">H", len_bytes)[0]
                    if mtype in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                        sof = f.read(5)
                        if len(sof) == 5:
                            h, w = struct.unpack(">HH", sof[1:5])
                            return int(w), int(h)
                        break
                    if seg_len < 2:
                        break
                    f.seek(seg_len - 2, 1)
    except Exception:
        pass
    return 0, 0


def validate_and_filter_images(image_paths):
    valid_items = []
    seen_hashes = set()

    for p in image_paths:
        if not p or not os.path.exists(p):
            continue
        fsize = os.path.getsize(p)
        if fsize < 2500:
            continue
        try:
            with open(p, "rb") as f:
                data = f.read()
            head_strip = data[:64].lstrip().lower()
            if head_strip.startswith((b"<!doctype", b"<html", b"<?xml", b"{\"error")):
                continue
            file_hash = hashlib.sha256(data).hexdigest()
            if file_hash in seen_hashes:
                continue
            seen_hashes.add(file_hash)

            w, h = get_image_dimensions_fast(p)
            if (w > 0 and h > 0) and (w < 220 or h < 220):
                continue
            is_png = data.startswith(b"\x89PNG\r\n\x1a\n")
            valid_items.append({
                "path": p,
                "size": fsize,
                "w": w,
                "h": h,
                "is_square": (w > 0 and h > 0 and abs(w - h) <= 4),
                "is_png": is_png,
            })
        except Exception:
            continue

    if len(valid_items) > 1:
        has_large_photo = any((not it["is_png"] and it["size"] > 25000) or it["w"] >= 600 for it in valid_items)
        if has_large_photo:
            filtered = [
                it for it in valid_items
                if not (it["is_square"] and (it["is_png"] or it["w"] in (192, 256, 300, 512) or it["size"] < 18000))
            ]
            if filtered:
                valid_items = filtered

    return [it["path"] for it in valid_items]


def cleanup_file_and_memory(*paths):
    for p in paths:
        if not p:
            continue
        try:
            if os.path.isfile(p) or os.path.islink(p):
                os.remove(p)
            elif os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
        except Exception:
            pass
    try:
        gc.collect()
    except Exception:
        pass


def purge_stale_temp_files(max_age_seconds=600):
    try:
        if not os.path.exists(DOWNLOAD_DIR):
            return
        now = time.time()
        for name in os.listdir(DOWNLOAD_DIR):
            full_p = os.path.join(DOWNLOAD_DIR, name)
            try:
                if now - os.path.getmtime(full_p) > max_age_seconds:
                    cleanup_file_and_memory(full_p)
            except Exception:
                continue
    except Exception:
        pass
