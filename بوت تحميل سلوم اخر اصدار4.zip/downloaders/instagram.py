#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
محرك انستغرام المطور (9 طبقات) مع اختيار أعلى دقة فيديو متاحة (HD) واستخراج الوصف الكامل.
"""

import os
import re
import json
from urllib.parse import urlparse, urljoin

import requests
from bs4 import BeautifulSoup

from network import http_session, DEFAULT_UA, logger
from media_utils import download_binary_file, probe_has_video_stream, validate_and_filter_images

IG_SHORTCODE_RE = re.compile(
    r"(?:instagram\.com|instagr\.am)/(?:[A-Za-z0-9_.\-]+/)?(?:p|reel|reels|tv)/([A-Za-z0-9_\-]+)",
    re.IGNORECASE,
)

IG_BAD_AUTHORS = {
    "vxinstagram", "d.vxinstagram", "ddinstagram", "d.ddinstagram",
    "kkinstagram", "instafix", "fxstagram", "uuinstagram", "instagram", "insta", "meta",
    "login", "snapsave", "fastdl", "saveig", "cobalt", "igram",
    "unknown", "none", "null", "undefined", "error", "not found",
}

STATIC_UI_URL_PATTERNS = (
    "rsrc.php", "static.cdninstagram.com", "static.xx.fbcdn.net", "static.whatsapp.net",
    "gstatic.com", "google.com/images/branding", "/rsrc/", "/images/instagram/",
    "favicon", "apple-touch-icon", "branding", "logo", "placeholder", "blank.gif",
    "spacer.gif", "1x1", "pixel", "sprite", "default_profile",
    "44884218_345707102882519_2446069589734326272_n",
)

AVATAR_URL_PATTERNS = (
    "t51.2885-19", "/s150x150/", "/s320x320/", "/p50x50/", "/p100x100/", "/s64x64/", "profile_pic",
)

COBALT_INSTANCES = [
    "https://cobalt-backend.canine.tools",
    "https://co.eepy.today",
]


def is_valid_media_url(u, media_type="image"):
    if not u or not isinstance(u, str) or not u.startswith(("http://", "https://")):
        return False
    ul = u.lower()
    for bad in STATIC_UI_URL_PATTERNS:
        if bad in ul:
            return False
    if media_type == "image":
        for av in AVATAR_URL_PATTERNS:
            if av in ul:
                return False
        base_path = ul.split("?")[0]
        if base_path.endswith((".svg", ".ico", ".mp4", ".webm", ".m4a", ".mp3", ".js", ".css")):
            return False
    return True


def clean_instagram_author(raw_author):
    if not raw_author or not isinstance(raw_author, str):
        return ""
    a = raw_author.strip()
    m_handle = re.search(r"\(@([A-Za-z0-9_.\-]+)\)", a)
    if m_handle:
        a = m_handle.group(1)
    else:
        a = re.sub(r"\s+on\s+instagram.*$", "", a, flags=re.IGNORECASE).strip()
        a = a.lstrip("@").strip()
    a_low = a.lower()
    if not a_low or a_low in IG_BAD_AUTHORS:
        return ""
    if any(b in a_low for b in ("vxinstagram", "ddinstagram", "kkinstagram", "instafix", "fxstagram", "uuinstagram", "login •", "instagram photos and videos")):
        return ""
    return a[:45]


def clean_instagram_caption_and_title(raw_text, shortcode=""):
    fallback = f"منشور انستغرام ({shortcode})" if shortcode else "منشور انستغرام"
    if not raw_text or not isinstance(raw_text, str):
        return fallback, ""
    t = raw_text.strip()
    m_cap = re.search(r":\s*[\"“](.+?)[\"”]\s*\.?\s*$", t, flags=re.DOTALL)
    if m_cap:
        t = m_cap.group(1).strip()
    t_low = t.lower()
    if t_low in IG_BAD_AUTHORS or any(b in t_low for b in ("vxinstagram", "ddinstagram", "kkinstagram", "instafix", "login • instagram", "create an account")):
        return fallback, ""
    if not t:
        return fallback, ""
    first_line = t.splitlines()[0].strip() if t.splitlines() else t
    short_title = first_line[:130] if first_line else fallback
    return short_title, t[:2500]


def clean_instagram_title(raw_title, shortcode=""):
    short_t, _ = clean_instagram_caption_and_title(raw_title, shortcode)
    return short_t


def extract_instagram_shortcode(url):
    m = IG_SHORTCODE_RE.search(url or "")
    return m.group(1) if m else None


def normalize_instagram_url(url):
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
        ),
        "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
    }
    clean = (url or "").strip()

    if "/share/" in clean.lower() or "instagr.am" in clean.lower():
        try:
            r = http_session.get(clean, headers=headers, allow_redirects=True, timeout=12, verify=False)
            if r.url and "instagram.com" in r.url:
                clean = r.url
            else:
                m_og = re.search(r'property=["\']og:url["\']\s+content=["\'](https://[^"\']+)["\']', r.text)
                if m_og:
                    clean = m_og.group(1)
        except Exception as e:
            logger.debug(f"Instagram share redirect note: {e}")

    m = IG_SHORTCODE_RE.search(clean)
    if m:
        shortcode = m.group(1)
        post_type = "reel" if ("/reel/" in clean.lower() or "/reels/" in clean.lower()) else "p"
        return f"https://www.instagram.com/{post_type}/{shortcode}/"

    try:
        parsed = urlparse(clean)
        if "instagram.com" in parsed.netloc.lower():
            path = re.sub(r"/reels/", "/reel/", parsed.path, flags=re.IGNORECASE)
            return f"https://www.instagram.com{path}"
    except Exception:
        pass
    return clean


def _pick_best_video_version(video_versions):
    """يختار أعلى دقة فيديو متاحة بدلاً من أخذ أول عنصر عشوائياً."""
    if not isinstance(video_versions, list) or not video_versions:
        return None
    valid = [v for v in video_versions if isinstance(v, dict) and v.get("url")]
    if not valid:
        return None
    valid.sort(key=lambda v: (int(v.get("width") or 0) * int(v.get("height") or 0), int(v.get("bandwidth") or 0)), reverse=True)
    return valid[0].get("url")


def _extract_from_ig_media_dict(media_dict, add_v_fn, add_i_fn, result_meta):
    if not isinstance(media_dict, dict):
        return

    owner = media_dict.get("owner") or media_dict.get("user") or {}
    if isinstance(owner, dict) and not result_meta.get("author"):
        cand_author = owner.get("username") or owner.get("full_name") or ""
        cleaned_a = clean_instagram_author(cand_author)
        if cleaned_a:
            result_meta["author"] = cleaned_a

    if not result_meta.get("description") or not result_meta.get("title"):
        raw_cap_text = ""
        cap_obj = media_dict.get("caption")
        if isinstance(cap_obj, dict) and cap_obj.get("text"):
            raw_cap_text = cap_obj["text"]
        elif isinstance(cap_obj, str) and cap_obj.strip():
            raw_cap_text = cap_obj
        else:
            edges_cap = (media_dict.get("edge_media_to_caption") or {}).get("edges") or []
            if edges_cap and isinstance(edges_cap[0], dict):
                raw_cap_text = ((edges_cap[0].get("node") or {}).get("text") or "").strip()
        if raw_cap_text:
            short_t, full_d = clean_instagram_caption_and_title(raw_cap_text)
            if short_t and not result_meta.get("title"):
                result_meta["title"] = short_t
            if full_d and not result_meta.get("description"):
                result_meta["description"] = full_d

    def extract_single_node(node):
        if not isinstance(node, dict):
            return
        v_url = _pick_best_video_version(node.get("video_versions")) or node.get("video_url")
        if v_url and (node.get("is_video") or node.get("media_type") == 2 or node.get("__typename") == "GraphVideo" or ".mp4" in str(v_url)):
            add_v_fn(v_url)
            return

        i_url = None
        if isinstance(node.get("display_resources"), list) and node["display_resources"]:
            i_url = node["display_resources"][-1].get("src")
        if not i_url and isinstance((node.get("image_versions2") or {}).get("candidates"), list):
            cands = node["image_versions2"]["candidates"]
            if cands:
                cands_sorted = sorted(cands, key=lambda c: int(c.get("width") or 0) * int(c.get("height") or 0), reverse=True)
                i_url = cands_sorted[0].get("url")
        if not i_url:
            i_url = node.get("display_url") or node.get("thumbnail_src")
        if i_url:
            add_i_fn(i_url)

    sidecar_edges = (media_dict.get("edge_sidecar_to_children") or {}).get("edges") or []
    carousel_media = media_dict.get("carousel_media") or []

    if sidecar_edges:
        for edge in sidecar_edges:
            if isinstance(edge, dict):
                extract_single_node(edge.get("node") or edge)
    elif carousel_media and isinstance(carousel_media, list):
        for item in carousel_media:
            extract_single_node(item)
    else:
        extract_single_node(media_dict)


def parse_embed_context_json(html_text):
    if not html_text:
        return None

    m_ctx = re.search(r'"contextJSON"\s*:\s*("(?:\\.|[^"\\])*")', html_text)
    if m_ctx:
        try:
            unquoted = json.loads(m_ctx.group(1))
            ctx_data = json.loads(unquoted)
            media_obj = (ctx_data.get("gql_data") or {}).get("shortcode_media") or ctx_data.get("shortcode_media")
            if isinstance(media_obj, dict):
                return media_obj
        except Exception:
            pass

    for s_match in re.findall(r"<script[^>]*>(.*?)</script>", html_text, flags=re.DOTALL):
        if "xdt_api__v1__media__shortcode__web_info" in s_match or "shortcode_media" in s_match or "video_versions" in s_match:
            try:
                m_items = re.search(r'"xdt_api__v1__media__shortcode__web_info"\s*:\s*\{\s*"items"\s*:\s*(\[\{.*?\}\])', s_match)
                if m_items:
                    arr = json.loads(m_items.group(1))
                    if arr and isinstance(arr[0], dict):
                        return arr[0]
            except Exception:
                pass
    return None


def download_instagram_multi_layer(url, work_dir):
    result = {"videos": [], "images": [], "title": "", "description": "", "author": ""}
    clean_url = normalize_instagram_url(url)
    shortcode = extract_instagram_shortcode(clean_url)
    if not shortcode:
        return result

    video_urls = []
    image_urls = []

    def add_v(u):
        if u and isinstance(u, str):
            u_clean = u.replace("\\u0026", "&").replace("\\/", "/").replace("&amp;", "&").replace("\\u003C", "<").strip()
            if is_valid_media_url(u_clean, "video") and u_clean not in video_urls:
                video_urls.append(u_clean)

    def add_i(u):
        if u and isinstance(u, str):
            u_clean = u.replace("\\u0026", "&").replace("\\/", "/").replace("&amp;", "&").strip()
            if is_valid_media_url(u_clean, "image") and u_clean not in image_urls:
                image_urls.append(u_clean)

    session = requests.Session()
    lsd_token = "AVqbxe3J_YA"

    # الطبقة 1: Embed Captioned
    try:
        embed_headers = {
            "User-Agent": DEFAULT_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
            "Referer": "https://www.instagram.com/",
            "Sec-Fetch-Dest": "iframe",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "cross-site",
        }
        for emb_path in (
            f"https://www.instagram.com/p/{shortcode}/embed/captioned/",
            f"https://www.instagram.com/reel/{shortcode}/embed/captioned/",
        ):
            er = session.get(emb_path, headers=embed_headers, timeout=12, verify=False)
            if er.status_code != 200 or not er.text:
                continue
            etext = er.text
            m_lsd = re.search(r'\["LSD",\[\],\{"token":"([^"]+)"\}', etext)
            if m_lsd:
                lsd_token = m_lsd.group(1)

            media_obj = parse_embed_context_json(etext)
            if media_obj:
                _extract_from_ig_media_dict(media_obj, add_v, add_i, result)

            if not video_urls:
                for vm in re.findall(r'\\?"video_url\\?"\s*:\s*\\?"(https?:[^"\\]+(?:\\.[^"\\]*)*)\\?"', etext):
                    add_v(vm)

            soup = BeautifulSoup(etext, "html.parser")
            if not result["author"]:
                user_el = soup.find("span", class_="UsernameText") or soup.find("a", class_="EmbedProfile")
                if user_el:
                    cleaned_u = clean_instagram_author(user_el.get_text(strip=True))
                    if cleaned_u:
                        result["author"] = cleaned_u

            if not result["description"] or not result["title"]:
                cap_el = soup.find("div", class_="Caption")
                if cap_el:
                    for u_span in cap_el.find_all("a", class_="CaptionUsername"):
                        u_span.decompose()
                    for c_more in cap_el.find_all("div", class_="CaptionComments"):
                        c_more.decompose()
                    st, fd = clean_instagram_caption_and_title(cap_el.get_text(" ", strip=True), shortcode)
                    if st and not result["title"]:
                        result["title"] = st
                    if fd and not result["description"]:
                        result["description"] = fd

            for vtag in soup.find_all("video"):
                if vtag.get("src"):
                    add_v(vtag["src"])

            if not video_urls and not image_urls:
                for img in soup.find_all("img", class_="EmbeddedMediaImage"):
                    src = img.get("src") or img.get("srcset", "").split(" ")[0]
                    if src:
                        add_i(src)
                for dm in re.findall(r'\\?"display_url\\?"\s*:\s*\\?"(https?:[^"\\]+(?:\\.[^"\\]*)*)\\?"', etext):
                    add_i(dm)

            if video_urls or image_urls:
                break
    except Exception as e:
        logger.debug(f"IG Layer 1 note: {e}")

    # الطبقة 2: Direct SSR Page
    if not video_urls:
        try:
            page_headers = {
                "User-Agent": DEFAULT_UA,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Upgrade-Insecure-Requests": "1",
            }
            pr = session.get(f"https://www.instagram.com/reel/{shortcode}/", headers=page_headers, timeout=12, verify=False)
            if pr.status_code == 200 and pr.text:
                ptext = pr.text
                m_lsd2 = re.search(r'\["LSD",\[\],\{"token":"([^"]+)"\}', ptext)
                if m_lsd2:
                    lsd_token = m_lsd2.group(1)

                media_obj2 = parse_embed_context_json(ptext)
                if media_obj2:
                    _extract_from_ig_media_dict(media_obj2, add_v, add_i, result)

                if not video_urls:
                    for vm in re.findall(r'"video_versions"\s*:\s*\[\s*\{[^}]*"url"\s*:\s*"(https?:[^"]+)"', ptext):
                        add_v(vm)
                    for vm2 in re.findall(r'"video_url"\s*:\s*"(https?:[^"]+)"', ptext):
                        add_v(vm2)

                if not result["description"]:
                    psoup = BeautifulSoup(ptext, "html.parser")
                    og_desc = psoup.find("meta", property="og:description") or psoup.find("meta", attrs={"name": "description"})
                    if og_desc and og_desc.get("content"):
                        st, fd = clean_instagram_caption_and_title(og_desc["content"], shortcode)
                        if st and not result["title"]:
                            result["title"] = st
                        if fd:
                            result["description"] = fd
        except Exception as e:
            logger.debug(f"IG Layer 2 note: {e}")

    # الطبقة 3: GraphQL API
    if not video_urls and not image_urls:
        try:
            csrf_token = session.cookies.get("csrftoken") or "missing"
            gql_headers = {
                "User-Agent": DEFAULT_UA,
                "Accept": "*/*",
                "Accept-Language": "en-US,en;q=0.9",
                "X-IG-App-ID": "936619743392459",
                "X-ASBD-ID": "129477",
                "X-IG-WWW-Claim": "0",
                "X-CSRFToken": csrf_token,
                "X-FB-LSD": lsd_token,
                "X-Requested-With": "XMLHttpRequest",
                "Content-Type": "application/x-www-form-urlencoded",
                "Referer": f"https://www.instagram.com/reel/{shortcode}/",
                "Origin": "https://www.instagram.com",
            }
            for doc_id in ("8845758582119845", "7341532402634560", "27128499623469141", "10015901848480474", "17991233890457762"):
                if video_urls or image_urls:
                    break
                payload = {
                    "av": "0", "__d": "www", "__user": "0", "__a": "1", "__req": "3", "lsd": lsd_token,
                    "fb_api_caller_class": "RelayModern",
                    "fb_api_req_friendly_name": "PolarisPostActionLoadPostQueryQuery",
                    "variables": json.dumps({
                        "shortcode": shortcode, "fetch_comment_count": 2, "fetch_related_profile_media_count": 0,
                        "parent_comment_count": 0, "child_comment_count": 0, "fetch_like_count": 10,
                        "fetch_tagged_user_count": None, "fetch_preview_comment_count": 2,
                        "has_threaded_comments": True, "hoisted_comment_id": None, "hoisted_reply_id": None,
                    }),
                    "server_timestamps": "true",
                    "doc_id": doc_id,
                }
                for ep in ("https://www.instagram.com/graphql/query", "https://www.instagram.com/api/graphql"):
                    gr = session.post(ep, data=payload, headers=gql_headers, timeout=10, verify=False)
                    if gr.status_code == 200 and gr.text:
                        gdata = gr.json()
                        data_root = gdata.get("data") or {}
                        media = data_root.get("xdt_shortcode_media") or data_root.get("shortcode_media")
                        if not media:
                            items = (data_root.get("xdt_api__v1__media__shortcode__web_info") or {}).get("items") or []
                            if items and isinstance(items[0], dict):
                                media = items[0]
                        if media and isinstance(media, dict):
                            _extract_from_ig_media_dict(media, add_v, add_i, result)
                            if video_urls or image_urls:
                                break
        except Exception as e:
            logger.debug(f"IG Layer 3 note: {e}")

    # الطبقة 4: الجسور النشطة
    if not video_urls and not image_urls:
        try:
            vr = http_session.get(
                f"https://vxinstagram.com/api/getPostDetails?id={shortcode}",
                headers={"User-Agent": DEFAULT_UA, "Accept": "application/json"},
                timeout=8,
                verify=False,
            )
            if vr.status_code == 200:
                vj = vr.json()
                if isinstance(vj, dict):
                    if not result["author"]:
                        vx_author = clean_instagram_author((vj.get("author") or {}).get("username") or "")
                        if vx_author:
                            result["author"] = vx_author
                    if vj.get("title"):
                        st, fd = clean_instagram_caption_and_title(vj.get("title"), shortcode)
                        if st and not result["title"]:
                            result["title"] = st
                        if fd and not result["description"]:
                            result["description"] = fd
                    if vj.get("is_video") and isinstance(vj.get("video"), dict) and vj["video"].get("url"):
                        add_v(vj["video"]["url"])
                    elif vj.get("thumbnail_url"):
                        add_i(vj["thumbnail_url"])
        except Exception:
            pass

    if not video_urls and not image_urls:
        bridge_hosts = [
            f"https://d.ddinstagram.com/reel/{shortcode}/",
            f"https://ddinstagram.com/reel/{shortcode}/",
            f"https://fxstagram.com/reel/{shortcode}/",
            f"https://uuinstagram.com/reel/{shortcode}/",
            f"https://d.vxinstagram.com/p/{shortcode}/",
            f"https://kkinstagram.com/reel/{shortcode}/",
            f"https://toinstagram.com/reel/{shortcode}/",
        ]
        bot_headers = {"User-Agent": "TelegramBot (like TwitterBot)", "Accept": "text/html,application/xhtml+xml,*/*"}
        for b_url in bridge_hosts:
            if video_urls or image_urls:
                break
            try:
                br = http_session.get(b_url, headers=bot_headers, timeout=10, allow_redirects=True, verify=False)
                if br.status_code != 200:
                    continue
                ctype = br.headers.get("Content-Type", "").lower()
                if "video/" in ctype:
                    add_v(br.url)
                    break
                if "image/" in ctype and is_valid_media_url(br.url, "image"):
                    add_i(br.url)
                    break

                bsoup = BeautifulSoup(br.text, "html.parser")
                for prop in ("og:video", "og:video:secure_url", "og:video:url", "twitter:player:stream"):
                    mtag = bsoup.find("meta", property=prop) or bsoup.find("meta", attrs={"name": prop})
                    if mtag and mtag.get("content"):
                        v_candidate = urljoin(b_url, mtag["content"])
                        if any(ext in v_candidate.lower() for ext in (".mp4", "video", "cdninstagram", "fbcdn", "rapidcdn", "/v/", "ddinstagram", "fxstagram", "uuinstagram")):
                            add_v(v_candidate)

                if not result["description"] or not result["title"]:
                    desc_tag = bsoup.find("meta", property="og:description") or bsoup.find("meta", attrs={"name": "description"})
                    if desc_tag and desc_tag.get("content"):
                        st, fd = clean_instagram_caption_and_title(desc_tag["content"], shortcode)
                        if st and st != f"منشور انستغرام ({shortcode})" and not result["title"]:
                            result["title"] = st
                        if fd and not result["description"]:
                            result["description"] = fd

                if not result["author"]:
                    tit_tag = bsoup.find("meta", property="og:title") or bsoup.find("meta", attrs={"name": "twitter:title"})
                    if tit_tag and tit_tag.get("content"):
                        cand_a = clean_instagram_author(tit_tag["content"])
                        if cand_a:
                            result["author"] = cand_a

                if not video_urls:
                    for prop in ("og:image", "twitter:image"):
                        itag = bsoup.find("meta", property=prop) or bsoup.find("meta", attrs={"name": prop})
                        if itag and itag.get("content"):
                            img_cand = urljoin(b_url, itag["content"])
                            if is_valid_media_url(img_cand, "image"):
                                add_i(img_cand)
                                break
            except Exception:
                continue

    # الطبقة 5: Cobalt API
    if not video_urls and not image_urls:
        for c_ep in COBALT_INSTANCES:
            if video_urls or image_urls:
                break
            try:
                c_headers = {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "User-Agent": DEFAULT_UA,
                    "Origin": c_ep,
                    "Referer": f"{c_ep}/",
                }
                cr = http_session.post(f"{c_ep.rstrip('/')}/", json={"url": clean_url, "videoQuality": "1080"}, headers=c_headers, timeout=10, verify=False)
                if cr.status_code != 200:
                    cr = http_session.post(f"{c_ep.rstrip('/')}/api/json", json={"url": clean_url, "vQuality": "1080"}, headers=c_headers, timeout=10, verify=False)
                if cr.status_code == 200:
                    cj = cr.json()
                    if cj.get("url"):
                        add_v(cj["url"])
                    elif isinstance(cj.get("picker"), list):
                        for p_item in cj["picker"]:
                            if isinstance(p_item, dict) and p_item.get("url"):
                                if p_item.get("type") == "video":
                                    add_v(p_item["url"])
                                else:
                                    add_i(p_item["url"])
            except Exception:
                continue

    for idx, vu in enumerate(video_urls[:5]):
        v_path = os.path.join(work_dir, f"ig_video_{idx}.mp4")
        if download_binary_file(vu, v_path, min_size=8192, expected_type="video"):
            if probe_has_video_stream(v_path):
                result["videos"].append(v_path)

    raw_downloaded_images = []
    for idx, iu in enumerate(image_urls[:10]):
        i_path = os.path.join(work_dir, f"ig_image_{idx}.jpg")
        if download_binary_file(iu, i_path, min_size=2500, expected_type="image"):
            raw_downloaded_images.append(i_path)

    result["images"] = validate_and_filter_images(raw_downloaded_images)
    result["author"] = clean_instagram_author(result.get("author", ""))
    result["title"] = clean_instagram_title(result.get("title", ""), shortcode)
    if not result["description"] and result["title"] and not result["title"].startswith("منشور انستغرام"):
        result["description"] = result["title"]

    return result
