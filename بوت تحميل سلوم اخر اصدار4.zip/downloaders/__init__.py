#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
خط التحميل الموحّد (Unified Download Pipeline) لجميع المنصات بأعلى دقة متاحة.
"""

import os
import re
from urllib.parse import urlparse, parse_qs, unquote

import yt_dlp

from config import COOKIES_FILE_PATH
from database import has_cookies_file
from network import http_session, DEFAULT_UA, SILENT_YDL_LOGGER, logger
from media_utils import (
    check_ffmpeg_installed,
    probe_has_video_stream,
    prepare_high_quality_video,
    convert_to_voice_ogg,
    convert_to_mp3,
    validate_and_filter_images,
    cleanup_file_and_memory,
)
from downloaders.instagram import (
    normalize_instagram_url,
    extract_instagram_shortcode,
    clean_instagram_author,
    clean_instagram_caption_and_title,
    download_instagram_multi_layer,
)
from downloaders.youtube import (
    normalize_youtube_url,
    extract_youtube_video_id,
    fetch_youtube_visitor_data,
    fetch_youtube_metadata_and_description,
    search_youtube_top5,
    download_youtube_multi_api_fallback,
)
from downloaders.platforms import (
    download_tiktok_multi_layer,
    download_telegram_public_post,
    scrape_google_and_webpage_media,
)

URL_REGEX = re.compile(r"(https?://[^\s<>\"']+)", re.IGNORECASE)


def extract_all_urls(text):
    if not text:
        return []
    cleaned = []
    for m in URL_REGEX.findall(text):
        u = m.strip().rstrip(").,!?;:'\"")
        if u and u not in cleaned:
            cleaned.append(u)
    return cleaned


def extract_first_url(text):
    urls = extract_all_urls(text)
    return urls[0] if urls else None


def normalize_cache_url(url):
    u_clean = (url or "").strip()
    u_low = u_clean.lower()
    if "instagram.com" in u_low or "instagr.am" in u_low:
        return normalize_instagram_url(u_clean)
    if "youtube.com" in u_low or "youtu.be" in u_low:
        return normalize_youtube_url(u_clean)
    return u_clean


def detect_platform_info(url):
    u = (url or "").lower()
    if "instagram.com" in u or "instagr.am" in u:
        sub = "ريلز" if ("/reel/" in u or "/reels/" in u) else ("قصة" if "/stories/" in u else "منشور")
        return {"name": "انستغرام", "badge": f"انستغرام • {sub}", "key": "instagram"}
    if "tiktok.com" in u:
        return {"name": "تيك توك", "badge": "تيك توك", "key": "tiktok"}
    if "youtube.com" in u or "youtu.be" in u:
        sub = "Shorts" if "/shorts/" in u else "فيديو"
        return {"name": "يوتيوب", "badge": f"يوتيوب • {sub}", "key": "youtube"}
    if "twitter.com" in u or "x.com" in u:
        return {"name": "منصة X", "badge": "منصة X", "key": "twitter"}
    if "facebook.com" in u or "fb.watch" in u or "fb.com" in u:
        return {"name": "فيسبوك", "badge": "فيسبوك", "key": "facebook"}
    if "snapchat.com" in u:
        return {"name": "سناب شات", "badge": "سناب شات", "key": "snapchat"}
    if "pinterest." in u or "pin.it" in u:
        return {"name": "بنترست", "badge": "بنترست", "key": "pinterest"}
    if "soundcloud.com" in u:
        return {"name": "ساوند كلاود", "badge": "ساوند كلاود", "key": "soundcloud"}
    if "threads.net" in u or "threads.com" in u:
        return {"name": "ثريدز", "badge": "ثريدز", "key": "threads"}
    if "t.me/" in u or "telegram.me/" in u:
        return {"name": "تيليجرام", "badge": "تيليجرام", "key": "telegram"}
    if "reddit.com" in u or "redd.it" in u:
        return {"name": "ريديت", "badge": "ريديت", "key": "reddit"}
    if "kwai.com" in u or "likee." in u:
        return {"name": "كواي / لايكي", "badge": "كواي / لايكي", "key": "kwai"}
    if "google." in u or "goo.gl" in u or "share.google" in u:
        return {"name": "جوجل", "badge": "جوجل", "key": "google"}
    return {"name": "رابط ويب", "badge": "رابط ويب", "key": "web"}


def analyze_and_resolve_url(url):
    current_url = (url or "").strip()
    u_low = current_url.lower()
    if "instagram.com" in u_low or "instagr.am" in u_low:
        return normalize_instagram_url(current_url), None
    if "youtube.com" in u_low or "youtu.be" in u_low:
        return normalize_youtube_url(current_url), None
    # لا نعدل روابط تيك توك المختصرة هنا لأن محرك تيك توك يفكها بنفسه مع الاحتفاظ بالرابط الأصلي
    if "tiktok.com" in u_low:
        return current_url, None

    try:
        parsed_init = urlparse(current_url)
        host_l = parsed_init.netloc.lower()
        if any(d in host_l for d in ("goo.gl", "share.google", "bit.ly", "tinyurl.com", "pin.it", "fb.watch")) or "/share/" in parsed_init.path.lower():
            r = http_session.get(current_url, headers={"User-Agent": DEFAULT_UA}, allow_redirects=True, timeout=12, verify=False)
            if r.url:
                current_url = r.url
                if "instagram.com" in current_url.lower():
                    return normalize_instagram_url(current_url), None
                if "youtube.com" in current_url.lower() or "youtu.be" in current_url.lower():
                    return normalize_youtube_url(current_url), None
    except Exception:
        pass

    try:
        parsed = urlparse(current_url)
        if "google." in parsed.netloc.lower():
            qs = parse_qs(parsed.query)
            if "imgurl" in qs and qs["imgurl"]:
                return unquote(qs["imgurl"][0]), None
            for param in ("url", "q"):
                if param in qs and qs[param]:
                    val = unquote(qs[param][0]).strip()
                    if val.startswith(("http://", "https://")):
                        if "youtube.com" in val.lower() or "youtu.be" in val.lower():
                            return normalize_youtube_url(val), None
                        return val, None
            if "q" in qs and qs["q"]:
                return current_url, unquote(qs["q"][0]).strip()
    except Exception:
        pass

    return current_url, None


def download_media_pipeline(url_or_query, mode, work_dir, is_search=False):
    """
    يحمل الوسائط بأعلى جودة ممكنة (1080p+ H.264/AAC) ويهيئها للإرسال الفوري.
    """
    output = {
        "status": False,
        "title": "منشور محمل",
        "description": "",
        "author": "",
        "video_path": None,
        "extra_videos": [],
        "voice_path": None,
        "audio_path": None,
        "images": [],
        "error": None,
    }

    has_ffmpeg = check_ffmpeg_installed()
    clean_url = url_or_query
    google_search_query = None

    if is_search:
        google_search_query = url_or_query
        top_items = search_youtube_top5(url_or_query)
        if top_items:
            clean_url = normalize_youtube_url(top_items[0]["url"])
            output["title"] = top_items[0].get("title") or output["title"]
            output["author"] = top_items[0].get("channel") or output["author"]
            is_search = False
        else:
            clean_url = f"ytsearch1:{url_or_query}"
    else:
        clean_url, google_search_query = analyze_and_resolve_url(url_or_query)

    is_ig = not is_search and ("instagram.com" in clean_url.lower() or "instagr.am" in clean_url.lower())
    is_yt = is_search or ("youtube.com" in clean_url.lower() or "youtu.be" in clean_url.lower())
    is_tt = not is_search and ("tiktok.com" in clean_url.lower() or "tiktok.com" in str(url_or_query).lower())

    if is_yt and not is_search:
        clean_url = normalize_youtube_url(clean_url)

    # أ) تيليجرام
    if not is_search and ("t.me/" in clean_url.lower() or "telegram.me/" in clean_url.lower()):
        tg_res = download_telegram_public_post(clean_url, work_dir)
        if tg_res.get("unsupported_reason"):
            output["error"] = tg_res["unsupported_reason"]
            return output
        if tg_res["videos"] or tg_res["audios"] or tg_res["images"]:
            output["title"] = tg_res["title"]
            output["description"] = tg_res.get("description") or tg_res["title"]
            if mode == "voice" and (tg_res["audios"] or tg_res["videos"]):
                src = tg_res["audios"][0] if tg_res["audios"] else tg_res["videos"][0]
                output["voice_path"] = convert_to_voice_ogg(src, os.path.join(work_dir, "tg_out.ogg"))
                output["status"] = True
                return output
            if tg_res["videos"]:
                output["video_path"] = prepare_high_quality_video(tg_res["videos"][0], work_dir, prefix="tg")
            output["images"] = tg_res["images"]
            if tg_res["audios"]:
                output["voice_path"] = convert_to_voice_ogg(tg_res["audios"][0], os.path.join(work_dir, "tg_v.ogg"))
            output["status"] = True
            return output

    video_candidates = []
    audio_candidates = []
    image_candidates = []

    # ب) تيك توك (4 طبقات متتالية قبل yt-dlp)
    if is_tt:
        tt_media = download_tiktok_multi_layer(clean_url, work_dir, original_url=url_or_query)
        if tt_media["images"] or tt_media["videos"] or tt_media["audios"]:
            output["title"] = tt_media["title"]
            output["description"] = tt_media.get("description") or tt_media["title"]
            output["author"] = tt_media.get("author", "")
            video_candidates.extend(tt_media["videos"])
            audio_candidates.extend(tt_media["audios"])
            image_candidates.extend(tt_media["images"])

    # ج) انستغرام 9 طبقات
    if is_ig:
        ig_media = download_instagram_multi_layer(clean_url, work_dir)
        if ig_media.get("title"):
            output["title"] = ig_media["title"]
        if ig_media.get("description"):
            output["description"] = ig_media["description"]
        if ig_media.get("author"):
            output["author"] = ig_media["author"]
        video_candidates.extend(ig_media["videos"])
        image_candidates.extend(ig_media["images"])

    # د) yt-dlp بأعلى دقة متاحة + طبقات الإنقاذ ليوتيوب
    need_ytdlp = is_yt or (not video_candidates and not image_candidates) or (
        mode in ("video", "voice", "mp3") and not video_candidates and not audio_candidates and len(image_candidates) <= 1
    )

    if need_ytdlp:
        target_for_ydl = f"ytsearch1:{google_search_query}" if (google_search_query and is_search and mode in ("video", "voice", "mp3")) else clean_url
        outtmpl = os.path.join(work_dir, "media_%(id)s_%(autonumber)s.%(ext)s")

        if mode in ("voice", "mp3"):
            format_selector = "bestaudio[ext=m4a]/bestaudio[ext=mp3]/bestaudio/best[ext=mp4]/best"
        elif is_tt:
            format_selector = "best[ext=mp4]/best"
        elif has_ffmpeg:
            format_selector = (
                "bestvideo*[height<=1080][vcodec^=avc1]+bestaudio[ext=m4a]/"
                "bestvideo*[height<=1080][ext=mp4]+bestaudio[ext=m4a]/"
                "bestvideo*[height<=1080]+bestaudio/"
                "best[height<=1080][ext=mp4]/"
                "bestvideo*+bestaudio/best"
            )
        else:
            format_selector = "best[height<=1080][ext=mp4]/best[ext=mp4]/best"

        base_ydl_opts = {
            "outtmpl": outtmpl,
            "format": format_selector,
            "noplaylist": False if is_ig else True,
            "quiet": True,
            "no_warnings": True,
            "logger": SILENT_YDL_LOGGER,
            "writethumbnail": False,
            "merge_output_format": "mp4" if (mode == "video" and has_ffmpeg and not is_tt) else None,
            "geo_bypass": True,
            "nocheckcertificate": True,
            "force_ipv4": True,
            "cachedir": False,
            "socket_timeout": 20,
            "retries": 2,
            "fragment_retries": 2,
        }
        if not is_tt:
            base_ydl_opts["http_headers"] = {
                "User-Agent": DEFAULT_UA,
                "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
            }

        if mode == "video" and not is_tt:
            base_ydl_opts["format_sort"] = ["res:1080", "vcodec:h264", "ext:mp4:m4a"]

        if has_cookies_file():
            base_ydl_opts["cookiefile"] = COOKIES_FILE_PATH

        def apply_ydl_info(info_dict):
            if not info_dict:
                return
            target_entry = info_dict
            if "entries" in info_dict and info_dict["entries"]:
                first_entry = next((e for e in info_dict["entries"] if e), None)
                if first_entry:
                    target_entry = first_entry
            raw_t = target_entry.get("title") or ""
            raw_desc = target_entry.get("description") or ""
            raw_a = target_entry.get("uploader") or target_entry.get("channel") or target_entry.get("uploader_id") or ""
            if is_ig:
                st, fd = clean_instagram_caption_and_title(raw_desc or raw_t, extract_instagram_shortcode(clean_url))
                if st and (not output["title"] or output["title"].startswith("منشور انستغرام")):
                    output["title"] = st
                if fd and not output["description"]:
                    output["description"] = fd
                if raw_a and not output["author"]:
                    output["author"] = clean_instagram_author(raw_a)
            else:
                if raw_t:
                    output["title"] = raw_t[:140]
                elif raw_desc and output["title"] == "منشور محمل":
                    output["title"] = raw_desc.splitlines()[0][:140]
                if raw_desc:
                    output["description"] = raw_desc[:2500]
                if raw_a:
                    output["author"] = raw_a[:60]

        def collect_ydl_files():
            nonlocal image_candidates
            new_ydl_images = []
            for fname in sorted(os.listdir(work_dir)):
                if not fname.startswith("media_"):
                    continue
                fpath = os.path.join(work_dir, fname)
                if not os.path.isfile(fpath) or os.path.getsize(fpath) < 4096:
                    continue
                if fname.endswith((".part", ".ytdl", ".temp")):
                    continue
                ext = os.path.splitext(fpath)[1].lower()
                if ext in (".jpg", ".jpeg", ".png", ".webp"):
                    if not is_yt and fpath not in image_candidates:
                        new_ydl_images.append(fpath)
                elif ext in (".mp3", ".m4a", ".ogg", ".opus", ".wav", ".aac", ".flac"):
                    if fpath not in audio_candidates:
                        audio_candidates.append(fpath)
                elif ext in (".mp4", ".mkv", ".webm", ".mov", ".avi", ".ts", ".m4v", ".3gp", ".flv"):
                    if fpath not in video_candidates and fpath not in audio_candidates:
                        if probe_has_video_stream(fpath) or (is_yt and mode == "video" and os.path.getsize(fpath) >= 24576):
                            video_candidates.append(fpath)
                        else:
                            audio_candidates.append(fpath)
            if new_ydl_images and not is_yt:
                image_candidates = validate_and_filter_images(image_candidates + new_ydl_images)

        yt_visitor_data = ""
        if is_yt and not is_search:
            vid_id_tmp = extract_youtube_video_id(clean_url)
            if vid_id_tmp:
                yt_visitor_data, _ = fetch_youtube_visitor_data(vid_id_tmp)

        if is_yt:
            p1_args = {"player_client": ["tv_simply", "web_embedded", "ios", "android_vr"], "player_skip": ["webpage"]}
            p2_args = {"player_client": ["mweb", "web_safari", "mediaconnect"], "player_skip": ["webpage"]}
            p3_args = {"player_client": ["default", "-android_sdkless"]}
            if yt_visitor_data:
                p1_args["visitor_data"] = [yt_visitor_data]
                p2_args["visitor_data"] = [yt_visitor_data]
            yt_client_profiles = [{"youtube": p1_args}, {"youtube": p2_args}, {"youtube": p3_args}]
        elif is_tt:
            yt_client_profiles = [
                {"tiktok": {"api_hostname": ["api16-normal-c-useast1a.tiktokv.com"]}},
                None,
            ]
        else:
            yt_client_profiles = [None]

        for idx_p, ext_args in enumerate(yt_client_profiles):
            if (mode == "video" and video_candidates) or (mode in ("voice", "mp3") and (audio_candidates or video_candidates)):
                break
            try:
                attempt_opts = dict(base_ydl_opts)
                if ext_args:
                    attempt_opts["extractor_args"] = ext_args
                if (is_yt and idx_p >= 2) or not has_ffmpeg:
                    attempt_opts["format"] = "best[height<=1080][ext=mp4]/best[ext=mp4]/best" if mode == "video" else "bestaudio/best"
                    attempt_opts.pop("merge_output_format", None)
                with yt_dlp.YoutubeDL(attempt_opts) as ydl:
                    info_dict = ydl.extract_info(target_for_ydl, download=True)
                    apply_ydl_info(info_dict)
                collect_ydl_files()
            except Exception as e:
                err_s = str(e).lower()
                logger.debug(f"yt-dlp profile {idx_p + 1} note: {e}")
                collect_ydl_files()
                if is_yt and idx_p >= 1 and ("not a bot" in err_s or "sign in" in err_s or "login_required" in err_s):
                    break

        if is_yt and not video_candidates and not audio_candidates:
            ext_fb = download_youtube_multi_api_fallback(clean_url, work_dir, mode=mode, result_meta=output)
            if ext_fb and os.path.exists(ext_fb):
                if mode in ("voice", "mp3") or ext_fb.lower().endswith((".mp3", ".m4a", ".ogg", ".opus", ".wav")):
                    audio_candidates.append(ext_fb)
                else:
                    video_candidates.append(ext_fb)

        if is_yt and not output.get("description"):
            vid_id_check = extract_youtube_video_id(clean_url)
            if vid_id_check:
                yt_m = fetch_youtube_metadata_and_description(vid_id_check)
                if yt_m.get("description"):
                    output["description"] = yt_m["description"]
                if yt_m.get("title") and output["title"] == "منشور محمل":
                    output["title"] = yt_m["title"]
                if yt_m.get("author") and not output["author"]:
                    output["author"] = yt_m["author"]

    # هـ) محرك الويب
    if not is_ig and not is_yt and not is_tt and not video_candidates and not audio_candidates and not image_candidates:
        if not is_search:
            web_media = scrape_google_and_webpage_media(clean_url, work_dir, search_query=google_search_query)
            if web_media.get("title") and output["title"] == "منشور محمل":
                output["title"] = web_media["title"]
            if web_media.get("description") and not output["description"]:
                output["description"] = web_media["description"]
            video_candidates.extend([v for v in web_media["videos"] if v not in video_candidates])
            audio_candidates.extend([a for a in web_media["audios"] if a not in audio_candidates])
            image_candidates.extend([i for i in web_media["images"] if i not in image_candidates])

    if not output.get("description") and output.get("title") and output["title"] != "منشور محمل":
        output["description"] = output["title"]

    if is_yt:
        image_candidates = []
    elif image_candidates:
        image_candidates = validate_and_filter_images(image_candidates)

    # و) تجهيز المخرجات بأعلى جودة
    if mode == "voice":
        source_media = audio_candidates[0] if audio_candidates else (video_candidates[0] if video_candidates else None)
        if source_media:
            ogg_path = os.path.join(work_dir, "voice_output.ogg")
            output["voice_path"] = convert_to_voice_ogg(source_media, ogg_path)
            if os.path.abspath(source_media) != os.path.abspath(output["voice_path"]):
                cleanup_file_and_memory(source_media)
            output["status"] = True
            return output
        if image_candidates and not is_yt:
            output["images"] = image_candidates
            output["status"] = True
            return output

    if mode == "mp3":
        source_media = audio_candidates[0] if audio_candidates else (video_candidates[0] if video_candidates else None)
        if source_media:
            mp3_path = os.path.join(work_dir, "audio_output.mp3")
            output["audio_path"] = convert_to_mp3(source_media, mp3_path)
            if os.path.abspath(source_media) != os.path.abspath(output["audio_path"]):
                cleanup_file_and_memory(source_media)
            output["status"] = True
            return output

    if not is_yt and image_candidates and not video_candidates:
        output["images"] = image_candidates
        source_for_voice = audio_candidates[0] if audio_candidates else None
        if source_for_voice:
            ogg_path = os.path.join(work_dir, "song_voice.ogg")
            output["voice_path"] = convert_to_voice_ogg(source_for_voice, ogg_path)
            if os.path.abspath(source_for_voice) != os.path.abspath(output["voice_path"]):
                cleanup_file_and_memory(source_for_voice)
        output["status"] = bool(output["images"] or output["voice_path"])
        return output

    if video_candidates:
        output["video_path"] = prepare_high_quality_video(video_candidates[0], work_dir, prefix="main")
        if len(video_candidates) > 1:
            output["extra_videos"] = [
                prepare_high_quality_video(ev_path, work_dir, prefix=f"extra_{idx_ev}")
                for idx_ev, ev_path in enumerate(video_candidates[1:5])
            ]
        if not is_yt and image_candidates and len(image_candidates) > 1:
            output["images"] = image_candidates[:6]
        output["status"] = True
        return output

    if audio_candidates:
        ogg_path = os.path.join(work_dir, "auto_voice.ogg")
        output["voice_path"] = convert_to_voice_ogg(audio_candidates[0], ogg_path)
        output["status"] = True
        return output

    if is_yt:
        output["error"] = "تعذر تنزيل هذا الفيديو حالياً. جرب إرسال الرابط مرة أخرى أو ارفع ملف cookies.txt من (/admin -> كوكيز)."
    elif is_ig:
        output["error"] = "تعذر استخراج هذا المنشور من انستغرام. إذا كان الحساب خاصاً، يمكن للمشرف رفع ملف كوكيز من (/admin -> كوكيز)."
    elif is_tt:
        output["error"] = "تعذر تنزيل هذا المنشور من تيك توك حالياً. تأكد من أن الفيديو عام وجرب مرة أخرى."
    else:
        output["error"] = "تعذر استخراج وسائط من هذا الرابط. تأكد من أن المنشور عام."
    return output
