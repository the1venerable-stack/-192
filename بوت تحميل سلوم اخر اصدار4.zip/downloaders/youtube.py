#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
محرك يوتيوب (البحث الهجين + 10 طبقات تنزيل بأعلى دقة متاحة 1080p+ مع استخراج الوصف).
"""

import os
import re
import sys
import json
import time
import threading
import subprocess
from urllib.parse import urlparse, parse_qs, quote_plus

import yt_dlp

from network import http_session, DEFAULT_UA, SILENT_YDL_LOGGER, logger
from database import has_cookies_file
from config import COOKIES_FILE_PATH
from media_utils import check_ffmpeg_installed, download_binary_file, cleanup_file_and_memory

YT_VIDEO_ID_RE = re.compile(
    r"(?:(?:www\.|m\.|music\.)?youtube(?:-nocookie)?\.com/(?:watch\?.*?v=|shorts/|embed/|live/|v/|clip/)|youtu\.be/)([A-Za-z0-9_\-]{11})",
    re.IGNORECASE,
)

PIPED_API_INSTANCES = [
    "https://pipedapi.kavin.rocks",
    "https://api.piped.private.coffee",
    "https://pipedapi.adminforge.de",
    "https://pipedapi.drgns.space",
    "https://piped-api.privacy.com.de",
    "https://pipedapi.smnz.de",
    "https://pipedapi.us.projectsegfau.lt",
    "https://piped-api.garudalinux.org",
    "https://pipedapi.leptons.xyz",
]

INVIDIOUS_API_INSTANCES = [
    "https://inv.nadeko.net",
    "https://inv.thepixora.com",
    "https://inv.clovius.club",
    "https://invidious.nerdvpn.de",
    "https://invidious.jing.rocks",
    "https://yt.chocolatemoo53.com",
    "https://invidious.tiekoetter.com",
    "https://yewtu.be",
    "https://inv.tux.pizza",
    "https://invidious.perennialte.ch",
    "https://iv.datura.network",
    "https://invidious.privacyredirect.com",
]

SAVETUBE_CDN_HOSTS = [
    "https://cdn51.savetube.su",
    "https://cdn52.savetube.su",
    "https://cdn59.savetube.su",
    "https://cdn61.savetube.su",
    "https://cdn54.savetube.su",
    "https://cdn55.savetube.su",
    "https://cdn58.savetube.su",
]

COBALT_API_INSTANCES = [
    "https://cobalt-backend.canine.tools",
    "https://co.eepy.today",
    "https://cobalt.synzr.space",
    "https://api.cobalt.tools",
]

_ytdlp_updated_once = False
_ytdlp_update_lock = threading.Lock()


def ensure_ytdlp_updated_background():
    global _ytdlp_updated_once
    with _ytdlp_update_lock:
        if _ytdlp_updated_once:
            return
        _ytdlp_updated_once = True

    def _run_update():
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "-U", "yt-dlp", "yt-dlp-ejs", "--quiet", "--disable-pip-version-check"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=110,
            )
            logger.info("[Auto-Updater] تم التحقق من تحديث yt-dlp إلى أحدث إصدار.")
        except Exception as e:
            logger.debug(f"[Auto-Updater] yt-dlp update note: {e}")

    threading.Thread(target=_run_update, daemon=True).start()


def format_duration_human(seconds):
    if not seconds or not isinstance(seconds, (int, float)) or seconds <= 0:
        return ""
    sec = int(seconds)
    mins, secs = divmod(sec, 60)
    hrs, mins = divmod(mins, 60)
    if hrs > 0:
        return f"{hrs}:{mins:02d}:{secs:02d}"
    return f"{mins:02d}:{secs:02d}"


def extract_youtube_video_id(url):
    if not url:
        return None
    m = YT_VIDEO_ID_RE.search(str(url))
    if m:
        return m.group(1)
    try:
        parsed = urlparse(str(url))
        qs = parse_qs(parsed.query)
        if "v" in qs and qs["v"] and len(qs["v"][0]) == 11:
            return qs["v"][0]
        path_parts = [p for p in (parsed.path or "").split("/") if p]
        if path_parts and ("youtube" in parsed.netloc.lower() or "youtu.be" in parsed.netloc.lower()):
            for part in reversed(path_parts):
                if re.match(r"^[A-Za-z0-9_\-]{11}$", part) and part.lower() not in ("watch", "shorts", "embed", "live"):
                    return part
    except Exception:
        pass
    return None


def normalize_youtube_url(url):
    if not url:
        return url
    vid_id = extract_youtube_video_id(url)
    if vid_id:
        return f"https://www.youtube.com/watch?v={vid_id}"
    return url.strip()


def extract_youtube_search_query(text):
    if not text:
        return None, False
    t = text.strip()
    m = re.match(r"^(?:ب|بـ|بحث|/search|/yt)\s+(.+)$", t, flags=re.IGNORECASE | re.DOTALL)
    if m:
        q = m.group(1).strip()
        return (q if len(q) >= 1 else None), True
    return t, False


def fetch_youtube_metadata_and_description(vid_id):
    meta = {"title": "", "description": "", "author": ""}
    if not vid_id:
        return meta

    clean_yt_url = f"https://www.youtube.com/watch?v={vid_id}"
    try:
        r = http_session.get(
            f"{clean_yt_url}&hl=ar",
            headers={"User-Agent": DEFAULT_UA, "Accept-Language": "ar,en-US;q=0.9,en;q=0.8"},
            timeout=7,
            verify=False,
        )
        if r.status_code == 200 and r.text:
            m_pr = re.search(r"var\s+ytInitialPlayerResponse\s*=\s*(\{.*?\});", r.text, flags=re.DOTALL)
            if not m_pr:
                m_pr = re.search(r"ytInitialPlayerResponse\s*=\s*(\{.*?\});", r.text, flags=re.DOTALL)
            if m_pr:
                pr_data = json.loads(m_pr.group(1))
                vd = pr_data.get("videoDetails") or {}
                if vd.get("title"):
                    meta["title"] = str(vd["title"]).strip()[:140]
                if vd.get("shortDescription"):
                    meta["description"] = str(vd["shortDescription"]).strip()[:2500]
                if vd.get("author"):
                    meta["author"] = str(vd["author"]).strip()[:60]
                if meta["title"] and meta["description"]:
                    return meta
    except Exception:
        pass

    if not meta["title"]:
        for oe_ep in (
            f"https://www.youtube.com/oembed?url={quote_plus(clean_yt_url)}&format=json",
            f"https://noembed.com/embed?url={quote_plus(clean_yt_url)}",
        ):
            try:
                oe = http_session.get(oe_ep, timeout=5, verify=False)
                if oe.status_code == 200:
                    oj = oe.json()
                    if oj.get("title"):
                        meta["title"] = str(oj["title"]).strip()[:140]
                    if oj.get("author_name") and not meta["author"]:
                        meta["author"] = str(oj["author_name"]).strip()[:60]
                    if meta["title"]:
                        break
            except Exception:
                continue

    return meta


def search_youtube_html_scrape(query, max_results=5):
    results = []
    headers = {"User-Agent": DEFAULT_UA, "Accept-Language": "ar,en-US;q=0.9,en;q=0.8"}
    try:
        url = f"https://www.youtube.com/results?search_query={quote_plus(query)}&hl=ar"
        r = http_session.get(url, headers=headers, timeout=10, verify=False)
        if r.status_code != 200 or not r.text:
            return results

        m = re.search(r"var\s+ytInitialData\s*=\s*(\{.*?\});</script>", r.text, flags=re.DOTALL)
        if not m:
            m = re.search(r"ytInitialData\s*=\s*(\{.*?\});", r.text, flags=re.DOTALL)
        if m:
            data = json.loads(m.group(1))
            contents = (
                (((data.get("contents") or {}).get("twoColumnSearchResultsRenderer") or {})
                 .get("primaryContents") or {})
                .get("sectionListRenderer") or {}
            ).get("contents") or []
            for sec in contents:
                items = ((sec.get("itemSectionRenderer") or {}).get("contents")) or []
                for it in items:
                    vr = it.get("videoRenderer")
                    if not vr or not isinstance(vr, dict):
                        continue
                    vid_id = vr.get("videoId")
                    if not vid_id:
                        continue
                    title_runs = ((vr.get("title") or {}).get("runs")) or []
                    title = title_runs[0].get("text", "فيديو يوتيوب") if title_runs else "فيديو يوتيوب"
                    owner_runs = (((vr.get("ownerText") or vr.get("longBylineText") or {}).get("runs")) or [])
                    channel = owner_runs[0].get("text", "YouTube") if owner_runs else "YouTube"
                    dur_txt = ((vr.get("lengthText") or {}).get("simpleText")) or "--:--"
                    results.append({
                        "id": vid_id,
                        "url": f"https://www.youtube.com/watch?v={vid_id}",
                        "title": title[:95],
                        "channel": channel[:40],
                        "duration": dur_txt,
                    })
                    if len(results) >= max_results:
                        return results
    except Exception as e:
        logger.debug(f"YouTube HTML search note: {e}")
    return results


def search_youtube_piped_or_invidious(query, max_results=5):
    results = []
    ua = {"User-Agent": DEFAULT_UA}
    for host in PIPED_API_INSTANCES[:4]:
        try:
            r = http_session.get(f"{host}/search", params={"q": query, "filter": "videos"}, headers=ua, timeout=6, verify=False)
            if r.status_code == 200:
                for it in (r.json() or {}).get("items") or []:
                    vid_id = extract_youtube_video_id(f"https://www.youtube.com{it.get('url') or ''}")
                    if not vid_id:
                        continue
                    results.append({
                        "id": vid_id,
                        "url": f"https://www.youtube.com/watch?v={vid_id}",
                        "title": (it.get("title") or "فيديو يوتيوب")[:95],
                        "channel": (it.get("uploaderName") or "YouTube")[:40],
                        "duration": format_duration_human(it.get("duration")) or "--:--",
                    })
                    if len(results) >= max_results:
                        return results
        except Exception:
            continue

    for host in INVIDIOUS_API_INSTANCES[:4]:
        try:
            r = http_session.get(f"{host}/api/v1/search", params={"q": query, "type": "video"}, headers=ua, timeout=6, verify=False)
            if r.status_code == 200:
                for it in r.json() or []:
                    if not isinstance(it, dict) or not it.get("videoId"):
                        continue
                    vid_id = it["videoId"]
                    results.append({
                        "id": vid_id,
                        "url": f"https://www.youtube.com/watch?v={vid_id}",
                        "title": (it.get("title") or "فيديو يوتيوب")[:95],
                        "channel": (it.get("author") or "YouTube")[:40],
                        "duration": format_duration_human(it.get("lengthSeconds")) or "--:--",
                    })
                    if len(results) >= max_results:
                        return results
        except Exception:
            continue
    return results


def search_youtube_top5(query):
    clean_q = (query or "").strip()
    if not clean_q:
        return []

    res_html = search_youtube_html_scrape(clean_q, max_results=5)
    if res_html:
        return res_html[:5]

    res_api = search_youtube_piped_or_invidious(clean_q, max_results=5)
    if res_api:
        return res_api[:5]

    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "logger": SILENT_YDL_LOGGER,
        "extract_flat": True,
        "skip_download": True,
        "noplaylist": True,
        "socket_timeout": 12,
        "force_ipv4": True,
    }
    if has_cookies_file():
        ydl_opts["cookiefile"] = COOKIES_FILE_PATH

    results = []
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(f"ytsearch5:{clean_q}", download=False)
            for entry in (info or {}).get("entries") or []:
                if not entry or not isinstance(entry, dict):
                    continue
                vid_id = entry.get("id") or ""
                vid_url = entry.get("url") or (f"https://www.youtube.com/watch?v={vid_id}" if vid_id else "")
                if vid_url and not vid_url.startswith("http"):
                    vid_url = f"https://www.youtube.com/watch?v={vid_url}"
                if not vid_url:
                    continue
                results.append({
                    "id": vid_id,
                    "url": normalize_youtube_url(vid_url),
                    "title": (entry.get("title") or "فيديو يوتيوب").strip()[:95],
                    "channel": (entry.get("uploader") or entry.get("channel") or "YouTube").strip()[:40],
                    "duration": format_duration_human(entry.get("duration")) or "--:--",
                })
                if len(results) >= 5:
                    break
    except Exception as e:
        logger.debug(f"YouTube top 5 search note: {e}")

    return results[:5]


def fetch_youtube_visitor_data(vid_id):
    visitor_data = ""
    sts_val = None
    try:
        r_emb = http_session.get(
            f"https://www.youtube.com/embed/{vid_id}?hl=en",
            headers={"User-Agent": DEFAULT_UA, "Referer": "https://www.youtube.com/"},
            timeout=6,
            verify=False,
        )
        if r_emb.status_code == 200 and r_emb.text:
            m_vd = re.search(r'"VISITOR_DATA"\s*:\s*"([^"]+)"', r_emb.text)
            if m_vd:
                visitor_data = m_vd.group(1)
            m_sts = re.search(r'"sts"\s*:\s*(\d+)', r_emb.text)
            if m_sts:
                sts_val = int(m_sts.group(1))
    except Exception:
        pass

    if not visitor_data:
        try:
            r_sw = http_session.get("https://www.youtube.com/sw.js_data", headers={"User-Agent": DEFAULT_UA}, timeout=5, verify=False)
            if r_sw.status_code == 200 and r_sw.text:
                m_sw = re.search(r'"(Cgt[A-Za-z0-9_\-%]+)"', r_sw.text)
                if m_sw:
                    visitor_data = m_sw.group(1)
        except Exception:
            pass
    return visitor_data, sts_val


def download_youtube_innertube_direct(vid_id, work_dir, mode="video", max_height=1080, result_meta=None):
    if not vid_id:
        return None

    visitor_data, sts_val = fetch_youtube_visitor_data(vid_id)
    has_ffmpeg = check_ffmpeg_installed()

    innertube_clients = [
        {
            "name": "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
            "ua": "Mozilla/5.0 (PlayStation; PlayStation 5/6.02) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Safari/605.1.15",
            "client_id": "85",
            "context": {"clientName": "TVHTML5_SIMPLY_EMBEDDED_PLAYER", "clientVersion": "2.0", "hl": "en", "gl": "US"},
            "thirdParty": {"embedUrl": f"https://www.youtube.com/embed/{vid_id}"},
        },
        {
            "name": "IOS",
            "ua": "com.google.ios.youtube/20.03.02 (iPhone16,2; U; CPU iOS 18_2_1 like Mac OS X;)",
            "client_id": "5",
            "context": {
                "clientName": "IOS", "clientVersion": "20.03.02", "deviceMake": "Apple",
                "deviceModel": "iPhone16,2", "osName": "iPhone", "osVersion": "18.2.1.22C161", "hl": "en", "gl": "US",
            },
        },
        {
            "name": "ANDROID_VR",
            "ua": "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            "client_id": "28",
            "context": {
                "clientName": "ANDROID_VR", "clientVersion": "1.60.19", "androidSdkVersion": 32,
                "osName": "Android", "osVersion": "12L", "deviceMake": "Oculus", "deviceModel": "Quest 3", "hl": "en", "gl": "US",
            },
        },
        {
            "name": "WEB_EMBEDDED_PLAYER",
            "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15",
            "client_id": "56",
            "context": {"clientName": "WEB_EMBEDDED_PLAYER", "clientVersion": "1.20260115.01.00", "hl": "en", "gl": "US"},
            "thirdParty": {"embedUrl": f"https://www.youtube.com/embed/{vid_id}"},
        },
    ]

    for c_spec in innertube_clients:
        try:
            c_ctx = dict(c_spec["context"])
            if visitor_data:
                c_ctx["visitorData"] = visitor_data
            full_context = {"client": c_ctx}
            if c_spec.get("thirdParty"):
                full_context["thirdParty"] = c_spec["thirdParty"]

            payload = {"videoId": vid_id, "context": full_context, "contentCheckOk": True, "racyCheckOk": True}
            if sts_val:
                payload["playbackContext"] = {"contentPlaybackContext": {"signatureTimestamp": sts_val}}

            req_headers = {
                "User-Agent": c_spec["ua"],
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-YouTube-Client-Name": c_spec["client_id"],
                "X-YouTube-Client-Version": c_ctx["clientVersion"],
                "Origin": "https://www.youtube.com",
            }
            if visitor_data:
                req_headers["X-Goog-Visitor-Id"] = visitor_data

            resp = http_session.post(
                "https://www.youtube.com/youtubei/v1/player?prettyPrint=false",
                json=payload,
                headers=req_headers,
                timeout=12,
                verify=False,
            )
            if resp.status_code != 200:
                continue
            pdata = resp.json()
            if not isinstance(pdata, dict):
                continue

            v_details = pdata.get("videoDetails") or {}
            if isinstance(result_meta, dict):
                if v_details.get("title") and (not result_meta.get("title") or result_meta.get("title") == "منشور محمل"):
                    result_meta["title"] = v_details["title"][:140]
                if v_details.get("shortDescription") and not result_meta.get("description"):
                    result_meta["description"] = v_details["shortDescription"][:2500]
                if v_details.get("author") and not result_meta.get("author"):
                    result_meta["author"] = v_details["author"][:50]

            s_data = pdata.get("streamingData") or {}
            if not s_data:
                continue

            dl_headers = {"User-Agent": c_spec["ua"], "Accept": "*/*"}
            muxed_formats = [f for f in (s_data.get("formats") or []) if f.get("url")]
            adaptive_formats = [f for f in (s_data.get("adaptiveFormats") or []) if f.get("url")]

            if mode in ("voice", "mp3"):
                audio_streams = [f for f in adaptive_formats if "audio" in str(f.get("mimeType", "")).lower()]
                audio_streams.sort(
                    key=lambda x: (1 if "mp4" in str(x.get("mimeType", "")).lower() else 0, int(x.get("bitrate") or 0)),
                    reverse=True,
                )
                for ast in audio_streams[:3]:
                    ext = ".m4a" if "mp4" in str(ast.get("mimeType", "")).lower() else ".webm"
                    out_aud = os.path.join(work_dir, f"yt_inner_{c_spec['name']}{ext}")
                    if download_binary_file(ast["url"], out_aud, headers=dl_headers, min_size=8192, expected_type="audio"):
                        return out_aud
                for mf in muxed_formats:
                    out_aud = os.path.join(work_dir, f"yt_inner_mux_{c_spec['name']}.mp4")
                    if download_binary_file(mf["url"], out_aud, headers=dl_headers, min_size=16384, expected_type="video"):
                        return out_aud
                continue

            # أولوية عالية لدمج أعلى فيديو 1080p MP4 H.264 + أفضل صوت M4A
            if has_ffmpeg and adaptive_formats:
                vid_streams = [
                    f for f in adaptive_formats
                    if "video/mp4" in str(f.get("mimeType", "")).lower() and int(f.get("height") or 0) <= max_height
                ] or [
                    f for f in adaptive_formats
                    if "video/" in str(f.get("mimeType", "")).lower() and int(f.get("height") or 0) <= max_height
                ]
                vid_streams.sort(
                    key=lambda x: (
                        int(x.get("height") or 0),
                        1 if "avc1" in str(x.get("mimeType", "")).lower() else 0,
                        int(x.get("bitrate") or 0),
                    ),
                    reverse=True,
                )
                aud_streams = [
                    f for f in adaptive_formats if "audio/mp4" in str(f.get("mimeType", "")).lower()
                ] or [
                    f for f in adaptive_formats if "audio/" in str(f.get("mimeType", "")).lower()
                ]
                aud_streams.sort(key=lambda x: int(x.get("bitrate") or 0), reverse=True)

                if vid_streams and aud_streams:
                    best_v = vid_streams[0]
                    best_a = aud_streams[0]
                    v_tmp = os.path.join(work_dir, f"inner_v_{c_spec['name']}.mp4")
                    a_tmp = os.path.join(work_dir, f"inner_a_{c_spec['name']}.m4a")
                    merged_out = os.path.join(work_dir, f"inner_merged_{c_spec['name']}.mp4")
                    if download_binary_file(best_v["url"], v_tmp, headers=dl_headers, min_size=24576, expected_type="video"):
                        if download_binary_file(best_a["url"], a_tmp, headers=dl_headers, min_size=8192, expected_type="audio"):
                            cmd_m = [
                                "ffmpeg", "-y", "-i", v_tmp, "-i", a_tmp,
                                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", merged_out,
                            ]
                            res_m = subprocess.run(cmd_m, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
                            cleanup_file_and_memory(v_tmp, a_tmp)
                            if res_m.returncode == 0 and os.path.exists(merged_out) and os.path.getsize(merged_out) > 24576:
                                return merged_out
                        cleanup_file_and_memory(v_tmp, a_tmp)

            hls_manifest = s_data.get("hlsManifestUrl")
            if hls_manifest and has_ffmpeg:
                out_hls = os.path.join(work_dir, f"yt_inner_hls_{c_spec['name']}.mp4")
                cmd_hls = [
                    "ffmpeg", "-y", "-user_agent", c_spec["ua"], "-i", hls_manifest,
                    "-c", "copy", "-bsf:a", "aac_adtstoasc", "-movflags", "+faststart", out_hls,
                ]
                res_hls = subprocess.run(cmd_hls, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=110)
                if res_hls.returncode == 0 and os.path.exists(out_hls) and os.path.getsize(out_hls) > 24576:
                    return out_hls

            if muxed_formats:
                muxed_formats.sort(key=lambda x: int(x.get("height") or 0), reverse=True)
                for mf in muxed_formats:
                    out_v = os.path.join(work_dir, f"yt_inner_muxed_{c_spec['name']}.mp4")
                    if download_binary_file(mf["url"], out_v, headers=dl_headers, min_size=24576, expected_type="video"):
                        return out_v
        except Exception as e:
            logger.debug(f"Innertube direct ({c_spec['name']}) note: {e}")

    return None


def download_youtube_savetube_api(clean_yt_url, work_dir, mode="video", result_meta=None):
    headers = {
        "User-Agent": DEFAULT_UA,
        "Accept": "application/json, text/plain, */*",
        "Origin": "https://ytshorts.savetube.me",
        "Referer": "https://ytshorts.savetube.me/",
    }
    for cdn_host in SAVETUBE_CDN_HOSTS:
        try:
            r_info = http_session.post(f"{cdn_host}/info", json={"url": clean_yt_url}, headers=headers, timeout=10, verify=False)
            if r_info.status_code != 200:
                continue
            data = (r_info.json() or {}).get("data") or {}
            if not isinstance(data, dict) or not data.get("key"):
                continue
            if isinstance(result_meta, dict) and data.get("title") and (not result_meta.get("title") or result_meta.get("title") == "منشور محمل"):
                result_meta["title"] = str(data["title"])[:140]

            key_token = data["key"]
            dl_type = "audio" if mode in ("voice", "mp3") else "video"
            qualities = ("320", "128") if dl_type == "audio" else ("1080", "720", "480")
            for q_val in qualities:
                r_dl = http_session.post(
                    f"{cdn_host}/download",
                    json={"downloadType": dl_type, "quality": q_val, "key": key_token},
                    headers=headers,
                    timeout=15,
                    verify=False,
                )
                if r_dl.status_code == 200:
                    dl_url = (r_dl.json().get("data") or {}).get("downloadUrl")
                    if dl_url:
                        ext = ".mp3" if dl_type == "audio" else ".mp4"
                        out_p = os.path.join(work_dir, f"yt_savetube_{q_val}{ext}")
                        if download_binary_file(dl_url, out_p, headers=headers, min_size=8192, expected_type="audio" if ext == ".mp3" else "video"):
                            return out_p
        except Exception:
            continue
    return None


def download_youtube_via_free_proxy(clean_yt_url, work_dir, mode="video", result_meta=None):
    has_ffmpeg = check_ffmpeg_installed()
    proxy_sources = (
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=3500&country=all&ssl=yes&anonymity=elite",
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=3500&country=all",
    )
    candidate_proxies = []
    for p_src in proxy_sources:
        try:
            pr = http_session.get(p_src, timeout=5, verify=False)
            if pr.status_code == 200 and pr.text:
                proto = "socks5" if "socks5" in p_src else "http"
                for line in pr.text.splitlines()[:25]:
                    ip_port = line.strip()
                    if re.match(r"^\d+\.\d+\.\d+\.\d+:\d+$", ip_port):
                        candidate_proxies.append(f"{proto}://{ip_port}")
        except Exception:
            continue

    working_proxies = []
    for px in candidate_proxies[:15]:
        try:
            tr = http_session.get("https://www.youtube.com/robots.txt", proxies={"http": px, "https": px}, timeout=3.5, verify=False)
            if tr.status_code == 200 and "User-agent" in tr.text:
                working_proxies.append(px)
                if len(working_proxies) >= 2:
                    break
        except Exception:
            continue

    for px in working_proxies:
        try:
            outtmpl = os.path.join(work_dir, "yt_px_%(id)s.%(ext)s")
            fmt = (
                "bestaudio[ext=m4a]/bestaudio/best"
                if mode in ("voice", "mp3")
                else (
                    "bestvideo*[height<=1080][ext=mp4]+bestaudio[ext=m4a]/bestvideo*[height<=1080]+bestaudio/best[height<=1080][ext=mp4]/best"
                    if has_ffmpeg
                    else "best[height<=1080][ext=mp4]/best[ext=mp4]/best"
                )
            )
            px_opts = {
                "outtmpl": outtmpl,
                "format": fmt,
                "proxy": px,
                "noplaylist": True,
                "quiet": True,
                "no_warnings": True,
                "logger": SILENT_YDL_LOGGER,
                "merge_output_format": "mp4" if (mode == "video" and has_ffmpeg) else None,
                "nocheckcertificate": True,
                "socket_timeout": 20,
                "retries": 2,
                "extractor_args": {"youtube": {"player_client": ["tv_simply", "ios", "android_vr"], "player_skip": ["webpage"]}},
            }
            with yt_dlp.YoutubeDL(px_opts) as ydl:
                info = ydl.extract_info(clean_yt_url, download=True)
                if info and isinstance(result_meta, dict):
                    if info.get("title") and (not result_meta.get("title") or result_meta.get("title") == "منشور محمل"):
                        result_meta["title"] = info["title"][:140]
                    if info.get("description") and not result_meta.get("description"):
                        result_meta["description"] = info["description"][:2500]
            for fn in os.listdir(work_dir):
                if fn.startswith("yt_px_") and not fn.endswith((".part", ".ytdl")):
                    fp = os.path.join(work_dir, fn)
                    if os.path.isfile(fp) and os.path.getsize(fp) > 16384:
                        return fp
        except Exception:
            continue
    return None


def download_youtube_multi_api_fallback(yt_url, work_dir, mode="video", result_meta=None):
    vid_id = extract_youtube_video_id(yt_url)
    if not vid_id:
        return None

    clean_yt_url = f"https://www.youtube.com/watch?v={vid_id}"
    headers = {"User-Agent": DEFAULT_UA, "Accept": "application/json, text/plain, */*"}

    if isinstance(result_meta, dict) and (not result_meta.get("description") or not result_meta.get("title") or result_meta.get("title") == "منشور محمل"):
        yt_meta = fetch_youtube_metadata_and_description(vid_id)
        if yt_meta.get("title") and (not result_meta.get("title") or result_meta.get("title") == "منشور محمل"):
            result_meta["title"] = yt_meta["title"]
        if yt_meta.get("description") and not result_meta.get("description"):
            result_meta["description"] = yt_meta["description"]
        if yt_meta.get("author") and not result_meta.get("author"):
            result_meta["author"] = yt_meta["author"]

    # 1. Innertube Direct (1080p adaptive merge)
    inner_res = download_youtube_innertube_direct(vid_id, work_dir, mode=mode, max_height=1080, result_meta=result_meta)
    if inner_res and os.path.exists(inner_res):
        return inner_res

    # 2. Savenow / Oceansaver (1080p first)
    loader_init_endpoints = (
        "https://p.savenow.to/ajax/download.php",
        "https://p.oceansaver.in/ajax/download.php",
        "https://ab.cococococ.com/ajax/download.php",
    )
    loader_progress_endpoints = (
        "https://p.savenow.to/ajax/progress.php",
        "https://p.oceansaver.in/ajax/progress.php",
    )
    loader_formats = ("mp3", "m4a") if mode in ("voice", "mp3") else ("1080", "720", "480")
    loader_headers = {"User-Agent": DEFAULT_UA, "Accept": "*/*", "Origin": "https://loader.to", "Referer": "https://loader.to/"}

    for fmt_req in loader_formats:
        for init_ep in loader_init_endpoints:
            try:
                init_r = http_session.get(
                    init_ep,
                    params={
                        "button": "1", "start": "1", "end": "1", "format": fmt_req,
                        "iframe_source": "https://allinonedownloader.com/",
                        "url": clean_yt_url, "api": "dfcb6d76f2f6a9894gjkege8a4ab232222",
                    },
                    headers=loader_headers,
                    timeout=12,
                    verify=False,
                )
                if init_r.status_code != 200:
                    continue
                ij = init_r.json()
                if not ij.get("success") or not ij.get("id"):
                    continue

                task_id = ij["id"]
                direct_prog_url = ij.get("progress_url")
                for poll_i in range(25):
                    time.sleep(1.5 if poll_i < 6 else 2.0)
                    if direct_prog_url and direct_prog_url.startswith("http"):
                        prog_r = http_session.get(direct_prog_url, headers=loader_headers, timeout=10, verify=False)
                    else:
                        prog_ep = loader_progress_endpoints[poll_i % len(loader_progress_endpoints)]
                        prog_r = http_session.get(prog_ep, params={"id": task_id}, headers=loader_headers, timeout=10, verify=False)
                    if prog_r.status_code != 200:
                        continue
                    pj = prog_r.json()
                    if (pj.get("success") == 1 or pj.get("progress") == 1000) and pj.get("download_url"):
                        ext = ".mp3" if mode in ("voice", "mp3") else ".mp4"
                        out_p = os.path.join(work_dir, f"yt_savenow_{fmt_req}{ext}")
                        if download_binary_file(pj["download_url"], out_p, headers=loader_headers, min_size=8192, expected_type="audio" if ext == ".mp3" else "video"):
                            return out_p
                        break
                    if pj.get("success", 0) < 0 or str(pj.get("text", "")).lower().startswith("error"):
                        break
            except Exception:
                continue

    # 3. SaveTube CDN (1080p first)
    st_res = download_youtube_savetube_api(clean_yt_url, work_dir, mode=mode, result_meta=result_meta)
    if st_res and os.path.exists(st_res):
        return st_res

    # 4. CnvMP3
    try:
        cnv_headers = {
            "User-Agent": DEFAULT_UA,
            "Content-Type": "application/json",
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://cnvmp3.com",
            "Referer": "https://cnvmp3.com/v25",
        }
        is_aud = mode in ("voice", "mp3")
        fmt_val = 1 if is_aud else 0
        ext = ".mp3" if is_aud else ".mp4"
        out_cnv = os.path.join(work_dir, f"yt_cnv{ext}")
        video_title = (result_meta or {}).get("title") or "youtube_video"
        for cnv_ep in ("https://cnvmp3.com/download_video_ucep.php", "https://cnvmp3.com/download_video.php"):
            for q_try in ((0, 1) if is_aud else (1080, 720, 480)):
                try:
                    cnv_r = http_session.post(
                        cnv_ep,
                        json={"url": clean_yt_url, "quality": q_try, "title": video_title, "formatValue": fmt_val},
                        headers=cnv_headers,
                        timeout=15,
                        verify=False,
                    )
                    if cnv_r.status_code == 200:
                        dl_link = cnv_r.json().get("download_link") or cnv_r.json().get("url")
                        if dl_link and download_binary_file(dl_link, out_cnv, headers=cnv_headers, min_size=8192, expected_type="audio" if is_aud else "video"):
                            return out_cnv
                except Exception:
                    continue
    except Exception:
        pass

    # 5. Invidious
    for inv_host in INVIDIOUS_API_INSTANCES:
        try:
            r = http_session.get(f"{inv_host}/api/v1/videos/{vid_id}", headers=headers, timeout=9, verify=False)
            if r.status_code != 200:
                continue
            idata = r.json()
            if not isinstance(idata, dict):
                continue
            if isinstance(result_meta, dict):
                if idata.get("title") and (not result_meta.get("title") or result_meta.get("title") == "منشور محمل"):
                    result_meta["title"] = idata["title"][:140]
                if idata.get("description") and not result_meta.get("description"):
                    result_meta["description"] = idata["description"][:2500]
                if idata.get("author") and not result_meta.get("author"):
                    result_meta["author"] = idata["author"][:50]

            if mode in ("voice", "mp3"):
                for af in idata.get("adaptiveFormats") or []:
                    if "audio" in str(af.get("type", "")).lower():
                        itag = af.get("itag")
                        out_p = os.path.join(work_dir, "yt_inv_audio.m4a")
                        if itag and download_binary_file(f"{inv_host}/latest_version?id={vid_id}&itag={itag}&local=true", out_p, min_size=8192, expected_type="audio"):
                            return out_p
                        if af.get("url") and download_binary_file(af["url"], out_p, min_size=8192, expected_type="audio"):
                            return out_p

            fmt_streams = idata.get("formatStreams") or []
            fmt_streams.sort(
                key=lambda x: int(str(x.get("resolution", "0")).replace("p", "") or 0 if str(x.get("resolution", "")).replace("p", "").isdigit() else 360),
                reverse=True,
            )
            for fs in fmt_streams:
                out_p = os.path.join(work_dir, "yt_inv_video.mp4")
                itag = fs.get("itag")
                if itag and download_binary_file(f"{inv_host}/latest_version?id={vid_id}&itag={itag}&local=true", out_p, min_size=24576, expected_type="video"):
                    return out_p
                f_url = fs.get("url")
                if f_url:
                    if f_url.startswith("/"):
                        f_url = f"{inv_host}{f_url}"
                    if download_binary_file(f_url, out_p, min_size=24576, expected_type="video"):
                        return out_p
        except Exception:
            continue

    # 6. Piped API
    for p_host in PIPED_API_INSTANCES:
        try:
            r = http_session.get(f"{p_host}/streams/{vid_id}", headers=headers, timeout=9, verify=False)
            if r.status_code != 200:
                continue
            pdata = r.json()
            if not isinstance(pdata, dict):
                continue
            if mode in ("voice", "mp3"):
                for ast in pdata.get("audioStreams") or []:
                    if ast.get("url"):
                        out_p = os.path.join(work_dir, "yt_piped_audio.m4a")
                        if download_binary_file(ast["url"], out_p, min_size=8192, expected_type="audio"):
                            return out_p

            hls_url = pdata.get("hls")
            if hls_url and check_ffmpeg_installed():
                out_p = os.path.join(work_dir, "yt_piped_hls.mp4")
                cmd = ["ffmpeg", "-y", "-i", hls_url, "-c", "copy", "-bsf:a", "aac_adtstoasc", "-movflags", "+faststart", out_p]
                res_ff = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
                if res_ff.returncode == 0 and os.path.exists(out_p) and os.path.getsize(out_p) > 24576:
                    return out_p

            v_streams = [s for s in (pdata.get("videoStreams") or []) if not s.get("videoOnly", True) and s.get("url")]
            v_streams.sort(
                key=lambda x: int(str(x.get("quality", "0")).replace("p", "") or 0 if str(x.get("quality", "")).replace("p", "").isdigit() else 360),
                reverse=True,
            )
            for vst in v_streams:
                out_p = os.path.join(work_dir, "yt_piped_video.mp4")
                if download_binary_file(vst["url"], out_p, min_size=24576, expected_type="video"):
                    return out_p
        except Exception:
            continue

    # 7. Cobalt API
    for c_ep in COBALT_API_INSTANCES:
        try:
            c_headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": DEFAULT_UA,
                "Origin": c_ep,
                "Referer": f"{c_ep}/",
            }
            payload_v10 = {
                "url": clean_yt_url,
                "videoQuality": "1080",
                "downloadMode": "audio" if mode in ("voice", "mp3") else "auto",
                "youtubeVideoCodec": "h264",
            }
            cr = http_session.post(f"{c_ep.rstrip('/')}/", json=payload_v10, headers=c_headers, timeout=10, verify=False)
            if cr.status_code != 200:
                cr = http_session.post(
                    f"{c_ep.rstrip('/')}/api/json",
                    json={"url": clean_yt_url, "vQuality": "1080", "isAudioOnly": mode in ("voice", "mp3")},
                    headers=c_headers,
                    timeout=10,
                    verify=False,
                )
            if cr.status_code == 200:
                dl_u = cr.json().get("url")
                if dl_u:
                    ext = ".mp3" if mode in ("voice", "mp3") else ".mp4"
                    out_p = os.path.join(work_dir, f"yt_cobalt{ext}")
                    if download_binary_file(dl_u, out_p, headers={"User-Agent": DEFAULT_UA}, min_size=8192, expected_type="audio" if ext == ".mp3" else "video"):
                        return out_p
        except Exception:
            continue

    # 8. Free Proxy Auto-Rescue
    px_res = download_youtube_via_free_proxy(clean_yt_url, work_dir, mode=mode, result_meta=result_meta)
    if px_res and os.path.exists(px_res):
        return px_res

    return None
