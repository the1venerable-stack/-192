#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
محركات المنصات الإضافية:
- تيك توك متعدد الطبقات السريع:
  1) TikWM API (POST + GET مع إعادة محاولة عند حد الطلبات)
  2) استخراج مباشر من صفحة تيك توك (__UNIVERSAL_DATA_FOR_REHYDRATION__ + كوكيز الجلسة tt_chain_token)
  3) TikTok Mobile Feed API (بدون علامة مائية وبأعلى بت ريت)
  4) LoveTik API
  (ثم yt-dlp بدون تعديل User-Agent كطبقة خامسة)
- منشورات تيليجرام العامة
- صفحات الويب وروابط جوجل المباشرة
"""

import os
import re
import json
import time
from urllib.parse import urlparse, urljoin

import requests
from bs4 import BeautifulSoup

from network import http_session, DEFAULT_UA, logger
from media_utils import download_binary_file, validate_and_filter_images
from downloaders.instagram import is_valid_media_url

TIKTOK_ID_RE = re.compile(r"/(?:video|photo|v)/(\d{15,22})", re.IGNORECASE)

_fast_session = requests.Session()


def resolve_tiktok_url_and_id(url):
    """يفك اختصار روابط تيك توك (vt.tiktok.com / vm.tiktok.com / tiktok.com/t/...) لاستخراج معرف الفيديو."""
    clean = (url or "").strip()
    m = TIKTOK_ID_RE.search(clean)
    if m:
        return clean, m.group(1)

    mobile_ua = (
        "Mozilla/5.0 (Linux; Android 13; SM-S918B) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    )
    try:
        r = _fast_session.get(
            clean,
            headers={"User-Agent": mobile_ua, "Accept": "*/*"},
            allow_redirects=True,
            timeout=(5, 7),
            stream=True,
            verify=False,
        )
        final_url = r.url or clean
        history = list(getattr(r, "history", []) or [])
        r.close()
        m2 = TIKTOK_ID_RE.search(final_url)
        if m2:
            return final_url, m2.group(1)
        for hist in history:
            loc = hist.headers.get("Location") or ""
            mh = TIKTOK_ID_RE.search(loc)
            if mh:
                return loc, mh.group(1)
        return final_url, None
    except Exception as e:
        logger.debug(f"[TikTok] redirect resolve note: {e}")
        return clean, None


def _abs_tikwm_url(u):
    if not u or not isinstance(u, str):
        return ""
    u = u.strip()
    if u.startswith("//"):
        return "https:" + u
    if u.startswith("/"):
        return "https://www.tikwm.com" + u
    return u


def _download_tiktok_stream(media_url, dest_path, expected_type="video", session=None, extra_headers=None):
    clean_headers = {"User-Agent": "Mozilla/5.0", "Accept": "*/*"}
    if extra_headers:
        clean_headers.update(extra_headers)

    # إذا مررنا جلسة تحتوي كوكيز تيك توك (مثل tt_chain_token)، نحمّل بها مباشرة
    if session is not None:
        tmp_path = f"{dest_path}.part"
        min_sz = 16384 if expected_type == "video" else (4096 if expected_type == "audio" else 1500)
        try:
            r = session.get(media_url, headers=clean_headers, stream=True, timeout=(6, 25), verify=False, allow_redirects=True)
            if r.status_code in (200, 206):
                ctype = (r.headers.get("Content-Type") or "").lower()
                if "text/html" not in ctype and "application/json" not in ctype:
                    total = 0
                    with open(tmp_path, "wb") as f:
                        for chunk in r.iter_content(65536):
                            if chunk:
                                f.write(chunk)
                                total += len(chunk)
                    if total >= min_sz:
                        os.replace(tmp_path, dest_path)
                        return True
        except Exception as e:
            logger.debug(f"[TikTok] session stream error: {e}")
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
        return False

    min_sz = 16384 if expected_type == "video" else (4096 if expected_type == "audio" else 1500)
    return download_binary_file(media_url, dest_path, headers=clean_headers, min_size=min_sz, expected_type=expected_type)


def _tiktok_layer_tikwm(target_url, work_dir, result):
    """الطبقة 1: TikWM API (POST ثم GET مع إعادة محاولة عند حد 1 req/sec)."""
    api_headers = {"User-Agent": "Mozilla/5.0"}
    for attempt in range(2):
        try:
            if attempt == 0:
                resp = _fast_session.post(
                    "https://www.tikwm.com/api/",
                    data={"url": target_url, "hd": 1},
                    headers=api_headers,
                    timeout=(5, 10),
                    verify=False,
                )
            else:
                resp = _fast_session.get(
                    "https://www.tikwm.com/api/",
                    params={"url": target_url, "hd": 1},
                    headers=api_headers,
                    timeout=(5, 10),
                    verify=False,
                )
            if resp.status_code != 200:
                continue
            j = resp.json()
            msg_low = str(j.get("msg") or "").lower()
            if j.get("code") != 0:
                if ("limit" in msg_low or "1 request" in msg_low) and attempt == 0:
                    time.sleep(1.5)
                    continue
                logger.info(f"[TikTok] TikWM code={j.get('code')} msg={j.get('msg')}")
                continue

            data = j.get("data")
            if not data or not isinstance(data, dict):
                continue

            raw_t = (data.get("title") or "").strip()
            if raw_t:
                result["title"] = raw_t[:140]
                result["description"] = raw_t[:2500]
            author_obj = data.get("author") or {}
            if isinstance(author_obj, dict):
                result["author"] = author_obj.get("nickname") or author_obj.get("unique_id") or result["author"]

            images_list = data.get("images") or []
            if images_list:
                for idx, img_url in enumerate(images_list[:10]):
                    img_abs = _abs_tikwm_url(img_url)
                    img_path = os.path.join(work_dir, f"tt_slide_{idx}.jpg")
                    if _download_tiktok_stream(img_abs, img_path, expected_type="image"):
                        result["images"].append(img_path)

            music_url = _abs_tikwm_url(data.get("music") or (data.get("music_info") or {}).get("play") or "")
            if music_url:
                aud_path = os.path.join(work_dir, "tt_music.mp3")
                if _download_tiktok_stream(music_url, aud_path, expected_type="audio"):
                    result["audios"].append(aud_path)

            if not images_list:
                for field in ("hdplay", "play", "wmplay"):
                    vid_url = _abs_tikwm_url(data.get(field) or "")
                    if not vid_url:
                        continue
                    vid_path = os.path.join(work_dir, f"tt_tikwm_{field}.mp4")
                    if _download_tiktok_stream(vid_url, vid_path, expected_type="video"):
                        result["videos"].append(vid_path)
                        return True

            if result["images"] or result["videos"] or result["audios"]:
                return True
        except Exception as e:
            logger.info(f"[TikTok] TikWM error: {e}")
    return False


def _tiktok_layer_webpage_direct(target_url, work_dir, result):
    """
    الطبقة 2: استخراج مباشر من صفحة تيك توك (__UNIVERSAL_DATA_FOR_REHYDRATION__)
    مع الاحتفاظ بكوكيز الجلسة (tt_chain_token) المطلوبة لتحميل ملف MP4 من خوادم tiktokcdn.
    """
    sess = requests.Session()
    page_headers = {
        "User-Agent": DEFAULT_UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    try:
        r = sess.get(target_url, headers=page_headers, timeout=(6, 10), allow_redirects=True, verify=False)
        if r.status_code != 200 or not r.text:
            return False

        m = re.search(
            r'<script\s+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)</script>',
            r.text,
            flags=re.DOTALL,
        )
        if not m:
            return False
        uni = json.loads(m.group(1))
        default_scope = uni.get("__DEFAULT_SCOPE__") or {}
        video_detail = default_scope.get("webapp.video-detail") or {}
        item = ((video_detail.get("itemInfo") or {}).get("itemStruct")) or {}
        if not isinstance(item, dict) or not item:
            return False

        desc = (item.get("desc") or "").strip()
        if desc:
            result["title"] = desc[:140]
            result["description"] = desc[:2500]
        author = item.get("author") or {}
        if isinstance(author, dict):
            result["author"] = author.get("nickname") or author.get("uniqueId") or result["author"]

        dl_headers = {"User-Agent": DEFAULT_UA, "Referer": "https://www.tiktok.com/"}

        # صور (Image Post)
        img_post = (item.get("imagePost") or {}).get("images") or []
        if img_post:
            for idx, im in enumerate(img_post[:10]):
                for iu in ((im.get("imageURL") or {}).get("urlList")) or []:
                    ip = os.path.join(work_dir, f"tt_web_img_{idx}.jpg")
                    if _download_tiktok_stream(iu, ip, expected_type="image", session=sess, extra_headers=dl_headers):
                        result["images"].append(ip)
                        break
            music_u = (item.get("music") or {}).get("playUrl")
            if music_u:
                ap = os.path.join(work_dir, "tt_web_music.mp3")
                if _download_tiktok_stream(music_u, ap, expected_type="audio", session=sess, extra_headers=dl_headers):
                    result["audios"].append(ap)
            if result["images"]:
                return True

        # فيديو (أعلى بت ريت)
        video_obj = item.get("video") or {}
        vid_urls = []
        for br in sorted(video_obj.get("bitrateInfo") or [], key=lambda b: int(b.get("Bitrate") or 0), reverse=True):
            for u in ((br.get("PlayAddr") or {}).get("UrlList")) or []:
                if u and u not in vid_urls:
                    vid_urls.append(u)
        for k in ("playAddr", "downloadAddr"):
            u = video_obj.get(k)
            if u and isinstance(u, str) and u not in vid_urls:
                vid_urls.append(u)

        for idx, vu in enumerate(vid_urls[:3]):
            vp = os.path.join(work_dir, f"tt_web_vid_{idx}.mp4")
            if _download_tiktok_stream(vu, vp, expected_type="video", session=sess, extra_headers=dl_headers):
                result["videos"].append(vp)
                return True
    except Exception as e:
        logger.debug(f"[TikTok] webpage layer note: {e}")
    return False


def _tiktok_layer_mobile_api(aweme_id, work_dir, result):
    """الطبقة 3: واجهة تطبيق تيك توك المباشرة (Mobile Feed API)."""
    if not aweme_id:
        return False

    api_hosts = (
        "https://api16-normal-c-useast1a.tiktokv.com/aweme/v1/feed/",
        "https://api22-normal-c-useast2a.tiktokv.com/aweme/v1/feed/",
    )
    api_headers = {
        "User-Agent": "com.zhiliaoapp.musically/2022600030 (Linux; U; Android 13; en_US; Pixel 7; Build/TQ2A.230505.002; Cronet/58.0.2991.0)",
        "Accept": "application/json",
    }
    for ep in api_hosts:
        try:
            r = _fast_session.get(ep, params={"aweme_id": aweme_id}, headers=api_headers, timeout=(5, 8), verify=False)
            if r.status_code != 200 or not r.text:
                continue
            j = r.json()
            aweme_list = j.get("aweme_list") or []
            item = next((c for c in aweme_list if str(c.get("aweme_id")) == str(aweme_id)), None) or (aweme_list[0] if aweme_list else None)
            if not isinstance(item, dict):
                continue

            desc = (item.get("desc") or "").strip()
            if desc:
                result["title"] = desc[:140]
                result["description"] = desc[:2500]
            author = item.get("author") or {}
            if isinstance(author, dict):
                result["author"] = author.get("nickname") or author.get("unique_id") or result["author"]

            img_info = (item.get("image_post_info") or {}).get("images") or []
            if img_info:
                for idx, im in enumerate(img_info[:10]):
                    for iu in ((im.get("display_image") or {}).get("url_list")) or []:
                        ip = os.path.join(work_dir, f"tt_api_img_{idx}.jpg")
                        if _download_tiktok_stream(iu, ip, expected_type="image"):
                            result["images"].append(ip)
                            break
                for mu in ((item.get("music") or {}).get("play_url") or {}).get("url_list") or []:
                    ap = os.path.join(work_dir, "tt_api_music.mp3")
                    if _download_tiktok_stream(mu, ap, expected_type="audio"):
                        result["audios"].append(ap)
                        break
                if result["images"]:
                    return True

            video_obj = item.get("video") or {}
            vid_urls = []
            for br in sorted(video_obj.get("bit_rate") or [], key=lambda b: int(b.get("bit_rate") or 0), reverse=True):
                for u in ((br.get("play_addr") or {}).get("url_list")) or []:
                    if u and u not in vid_urls:
                        vid_urls.append(u)
            for key_name in ("play_addr", "play_addr_h264", "download_addr"):
                for u in ((video_obj.get(key_name) or {}).get("url_list")) or []:
                    if u and u not in vid_urls:
                        vid_urls.append(u)

            for idx, vu in enumerate(vid_urls[:3]):
                vp = os.path.join(work_dir, f"tt_api_vid_{idx}.mp4")
                if _download_tiktok_stream(vu, vp, expected_type="video"):
                    result["videos"].append(vp)
                    return True
        except Exception as e:
            logger.debug(f"[TikTok] Mobile API note: {e}")
    return False


def _tiktok_layer_lovetik(target_url, work_dir, result):
    """الطبقة 4: LoveTik API."""
    headers = {
        "User-Agent": DEFAULT_UA,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Origin": "https://lovetik.com",
        "Referer": "https://lovetik.com/",
        "X-Requested-With": "XMLHttpRequest",
    }
    try:
        r = _fast_session.post("https://lovetik.com/api/ajax/search", data={"query": target_url}, headers=headers, timeout=(5, 9), verify=False)
        if r.status_code != 200:
            return False
        j = r.json()
        if j.get("status") != "ok":
            return False
        if j.get("desc") and not result.get("description"):
            desc = str(j["desc"]).strip()
            result["title"] = desc[:140]
            result["description"] = desc[:2500]
        if j.get("author_name") and not result.get("author"):
            result["author"] = str(j["author_name"])[:50]

        links = [lk for lk in (j.get("links") or []) if "MP4" in str(lk.get("t") or "").upper() and lk.get("a")]
        links.sort(key=lambda x: (1 if "HD" in str(x.get("t") or "").upper() else 0, 1 if "NO WATERMARK" in str(x.get("t") or "").upper() else 0), reverse=True)
        for idx, lk in enumerate(links[:2]):
            vp = os.path.join(work_dir, f"tt_lovetik_{idx}.mp4")
            if _download_tiktok_stream(lk["a"], vp, expected_type="video"):
                result["videos"].append(vp)
                return True
    except Exception as e:
        logger.debug(f"[TikTok] LoveTik note: {e}")
    return False


def download_tiktok_multi_layer(url, work_dir, original_url=None):
    """
    محرك تيك توك السريع متعدد الطبقات (بدون خوادم Cobalt المتعطلة):
    1) TikWM بالرابط الأصلي مباشرة.
    2) استخراج مباشر من صفحة تيك توك مع كوكيز الجلسة.
    3) TikTok Mobile Feed API.
    4) LoveTik API.
    """
    result = {"videos": [], "audios": [], "images": [], "title": "منشور تيك توك", "description": "", "author": ""}
    primary_url = (original_url or url or "").strip()
    if "tiktok.com" not in primary_url.lower():
        return result

    if _tiktok_layer_tikwm(primary_url, work_dir, result):
        return result

    if _tiktok_layer_webpage_direct(primary_url, work_dir, result):
        return result

    resolved_url, aweme_id = resolve_tiktok_url_and_id(primary_url)
    if aweme_id and _tiktok_layer_mobile_api(aweme_id, work_dir, result):
        return result

    if _tiktok_layer_lovetik(resolved_url or primary_url, work_dir, result):
        return result

    return result


def download_telegram_public_post(url, work_dir):
    result = {"videos": [], "audios": [], "images": [], "title": "منشور تيليجرام", "description": "", "unsupported_reason": None}
    parsed = urlparse(url)
    path_parts = [p for p in parsed.path.split("/") if p]

    if not path_parts:
        return result

    if path_parts[0].lower() in ("addlist", "joinchat") or path_parts[0].startswith("+"):
        result["unsupported_reason"] = (
            "هذا الرابط هو رابط إضافة مجلد أو دعوة انضمام وليس رابط منشور عام (مثال: t.me/channel/123)."
        )
        return result

    if len(path_parts) >= 2 and path_parts[-1].isdigit():
        embed_url = f"https://t.me/{path_parts[-2]}/{path_parts[-1]}?embed=1"
        headers = {"User-Agent": DEFAULT_UA}
        try:
            resp = http_session.get(embed_url, headers=headers, timeout=15, verify=False)
            if resp.status_code == 200:
                soup = BeautifulSoup(resp.text, "html.parser")
                text_div = soup.find("div", class_="tgme_widget_message_text")
                if text_div:
                    full_txt = text_div.get_text("\n", strip=True)
                    result["title"] = full_txt.splitlines()[0][:120] if full_txt else "منشور تيليجرام"
                    result["description"] = full_txt[:2500]

                for v in soup.find_all("video"):
                    src = v.get("src")
                    if src and src.startswith("http"):
                        vr = http_session.get(src, headers=headers, stream=True, timeout=25, verify=False)
                        if vr.status_code == 200:
                            vp = os.path.join(work_dir, "tg_video.mp4")
                            with open(vp, "wb") as f:
                                for ch in vr.iter_content(65536):
                                    if ch:
                                        f.write(ch)
                            if os.path.getsize(vp) > 1024:
                                result["videos"].append(vp)

                for a in soup.find_all("audio"):
                    src = a.get("src")
                    if src and src.startswith("http"):
                        ar = http_session.get(src, headers=headers, timeout=20, verify=False)
                        if ar.status_code == 200:
                            ap = os.path.join(work_dir, "tg_voice.ogg")
                            with open(ap, "wb") as f:
                                f.write(ar.content)
                            result["audios"].append(ap)

                for photo_wrap in soup.find_all("a", class_=re.compile("tgme_widget_message_photo_wrap")):
                    style_attr = photo_wrap.get("style", "")
                    m = re.search(r"background-image:url\(['\"]?(https://[^'\")]+)['\"]?\)", style_attr)
                    if m:
                        ir = http_session.get(m.group(1), headers=headers, timeout=15, verify=False)
                        if ir.status_code == 200:
                            ip = os.path.join(work_dir, f"tg_photo_{len(result['images'])}.jpg")
                            with open(ip, "wb") as f:
                                f.write(ir.content)
                            result["images"].append(ip)
        except Exception as e:
            logger.debug(f"Telegram embed scrape note: {e}")

    return result


def scrape_google_and_webpage_media(url, work_dir, search_query=None):
    headers = {"User-Agent": DEFAULT_UA, "Accept": "*/*"}
    result = {"videos": [], "audios": [], "images": [], "title": search_query or "منشور محمل", "description": ""}

    u_low = (url or "").lower()
    if any(k in u_low for k in ("instagram.com", "instagr.am", "youtube.com", "youtu.be", "tiktok.com")):
        return result

    try:
        resp = http_session.get(url, headers=headers, stream=True, timeout=22, allow_redirects=True, verify=False)
        content_type = resp.headers.get("Content-Type", "").lower()

        if "video/" in content_type or url.lower().split("?")[0].endswith((".mp4", ".mov", ".webm", ".mkv")):
            vid_path = os.path.join(work_dir, "direct_video.mp4")
            with open(vid_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
            if os.path.getsize(vid_path) > 1024:
                result["videos"].append(vid_path)
                return result

        if "audio/" in content_type or url.lower().split("?")[0].endswith((".mp3", ".m4a", ".wav", ".ogg", ".opus", ".aac")):
            aud_path = os.path.join(work_dir, "direct_audio.mp3")
            with open(aud_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
            if os.path.getsize(aud_path) > 1024:
                result["audios"].append(aud_path)
                return result

        if "image/" in content_type or url.lower().split("?")[0].endswith((".jpg", ".jpeg", ".png", ".webp", ".gif")):
            ext = ".png" if "png" in content_type else ".jpg"
            img_path = os.path.join(work_dir, f"direct_image{ext}")
            with open(img_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
            if os.path.getsize(img_path) > 512:
                result["images"].append(img_path)
                return result

        html_text = resp.text
        soup = BeautifulSoup(html_text, "html.parser")
        if soup.title and soup.title.string:
            result["title"] = soup.title.string.strip()[:120]

        desc_meta = soup.find("meta", property="og:description") or soup.find("meta", attrs={"name": "description"}) or soup.find("meta", attrs={"name": "twitter:description"})
        if desc_meta and desc_meta.get("content"):
            result["description"] = desc_meta["content"].strip()[:2500]

        video_urls, audio_urls, image_urls = [], [], []

        for prop in ("og:video", "og:video:url", "og:video:secure_url", "twitter:player:stream"):
            tag = soup.find("meta", property=prop) or soup.find("meta", attrs={"name": prop})
            if tag and tag.get("content"):
                v_u = urljoin(url, tag["content"])
                if is_valid_media_url(v_u, "video"):
                    video_urls.append(v_u)

        for prop in ("og:audio", "og:audio:secure_url", "twitter:audio:src"):
            tag = soup.find("meta", property=prop) or soup.find("meta", attrs={"name": prop})
            if tag and tag.get("content"):
                audio_urls.append(urljoin(url, tag["content"]))

        for prop in ("og:image", "twitter:image"):
            tag = soup.find("meta", property=prop) or soup.find("meta", attrs={"name": prop})
            if tag and tag.get("content"):
                i_u = urljoin(url, tag["content"])
                if is_valid_media_url(i_u, "image"):
                    image_urls.append(i_u)

        for vtag in soup.find_all("video"):
            if vtag.get("src"):
                video_urls.append(urljoin(url, vtag["src"]))
            for stag in vtag.find_all("source"):
                if stag.get("src"):
                    video_urls.append(urljoin(url, stag["src"]))

        for m_vid in re.findall(r'(https?://[^"\'\s<>\\]+\.mp4(?:\?[^"\'\s<>\\]+)?)', html_text):
            clean_v = m_vid.replace("\\u0026", "&").replace("\\/", "/")
            if is_valid_media_url(clean_v, "video") and clean_v not in video_urls:
                video_urls.append(clean_v)

        for idx, v_url in enumerate(video_urls[:3]):
            try:
                v_resp = http_session.get(v_url, headers=headers, stream=True, timeout=20, verify=False)
                if v_resp.status_code == 200:
                    v_path = os.path.join(work_dir, f"web_video_{idx}.mp4")
                    with open(v_path, "wb") as f:
                        for chunk in v_resp.iter_content(65536):
                            if chunk:
                                f.write(chunk)
                    if os.path.getsize(v_path) > 4096:
                        result["videos"].append(v_path)
                        break
            except Exception:
                continue

        for idx, a_url in enumerate(audio_urls[:3]):
            try:
                a_resp = http_session.get(a_url, headers=headers, stream=True, timeout=20, verify=False)
                if a_resp.status_code == 200:
                    a_path = os.path.join(work_dir, f"web_audio_{idx}.mp3")
                    with open(a_path, "wb") as f:
                        for chunk in a_resp.iter_content(65536):
                            if chunk:
                                f.write(chunk)
                    if os.path.getsize(a_path) > 2048:
                        result["audios"].append(a_path)
                        break
            except Exception:
                continue

        raw_web_imgs = []
        for idx, i_url in enumerate(image_urls[:4]):
            try:
                i_resp = http_session.get(i_url, headers=headers, stream=True, timeout=15, verify=False)
                if i_resp.status_code == 200:
                    i_path = os.path.join(work_dir, f"web_image_{idx}.jpg")
                    with open(i_path, "wb") as f:
                        for chunk in i_resp.iter_content(65536):
                            if chunk:
                                f.write(chunk)
                    if os.path.getsize(i_path) > 2048:
                        raw_web_imgs.append(i_path)
            except Exception:
                continue
        result["images"] = validate_and_filter_images(raw_web_imgs)

    except Exception as e:
        logger.debug(f"Web scrape note: {e}")

    return result
