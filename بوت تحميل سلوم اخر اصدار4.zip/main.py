#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
نقطة تشغيل البوت الرئيسية (main.py).
تتضمن حلقة Polling مقاومة للأخطاء لحل مشاكل:
- Error code: 502. Description: Bad Gateway
- HTTPSConnectionPool(host='api.telegram.org', port=443): Read timed out
مع إعادة اتصال تلقائية نظيفة بدون إغراق الكونسول بالأخطاء.
"""

import time
import requests
from telebot import apihelper

from config import BOT_TOKEN
from network import install_doh_resolver, logger
from database import init_db
from bot_instance import bot
from downloaders.youtube import ensure_ytdlp_updated_background
from handlers import register_all_handlers


def _reset_telegram_session():
    """يعيد تهيئة جلسة الاتصال بـ Telegram API عند حدوث 502 أو Timeout."""
    try:
        apihelper._get_req_session(reset=True)
    except Exception:
        pass


def run_resilient_polling():
    """
    حلقة تشغيل مستقرة للبوت على الاستضافات (مثل Lunes Host / Pterodactyl):
    - long_polling_timeout=20 أقل بكثير من READ_TIMEOUT=45 لمنع أخطاء Read timed out.
    - التقاط أخطاء 502 / 503 / 504 و ReadTimeout و ConnectionError وإعادة الاتصال تلقائياً بسلاسة.
    """
    backoff = 2
    while True:
        try:
            bot.polling(
                none_stop=False,
                interval=0,
                timeout=25,
                long_polling_timeout=20,
                skip_pending=True,
            )
            backoff = 2
        except KeyboardInterrupt:
            logger.info("تم إيقاف البوت يدوياً.")
            break
        except apihelper.ApiTelegramException as e:
            code = getattr(e, "error_code", None)
            if code in (502, 503, 504):
                _reset_telegram_session()
                logger.info(f"استجابة مؤقتة من خادم تيليجرام ({code}) — إعادة الاتصال خلال {backoff} ثوانٍ...")
                time.sleep(backoff)
                backoff = min(backoff * 2, 15)
            elif code == 429:
                retry_after = 5
                try:
                    retry_after = int((e.result_json or {}).get("parameters", {}).get("retry_after", 5))
                except Exception:
                    pass
                logger.info(f"حد الطلبات من تيليجرام (429) — انتظار {retry_after} ثوانٍ...")
                time.sleep(max(retry_after, 3))
            elif code == 409:
                logger.warning("يوجد نسخة أخرى من البوت تعمل بنفس التوكن (409) — إعادة المحاولة بعد 10 ثوانٍ...")
                time.sleep(10)
            else:
                logger.warning(f"خطأ من Telegram API ({code}): {e.description}")
                time.sleep(backoff)
                backoff = min(backoff * 2, 15)
        except (
            requests.exceptions.ReadTimeout,
            requests.exceptions.ConnectTimeout,
            requests.exceptions.ConnectionError,
            requests.exceptions.Timeout,
        ):
            _reset_telegram_session()
            time.sleep(backoff)
            backoff = min(backoff + 2, 10)
        except Exception as e:
            err_l = str(e).lower()
            if any(k in err_l for k in ("timed out", "502", "bad gateway", "connection aborted", "remote disconnected", "connection reset")):
                _reset_telegram_session()
                time.sleep(backoff)
                backoff = min(backoff + 2, 10)
            else:
                logger.warning(f"إعادة تشغيل الاتصال بعد خطأ غير متوقع: {e}")
                time.sleep(5)


def main():
    install_doh_resolver()
    init_db()
    register_all_handlers()
    ensure_ytdlp_updated_background()

    if not BOT_TOKEN or BOT_TOKEN == "PUT_YOUR_BOT_TOKEN_HERE":
        logger.error("يرجى وضع توكن البوت في config.py أو في متغير البيئة BOT_TOKEN قبل التشغيل.")
        return

    logger.info("تم تشغيل البوت بنجاح (اتصال مستقر + جودة عالية + أداء محسّن).")
    run_resilient_polling()


if __name__ == "__main__":
    main()
