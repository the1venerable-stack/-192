#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تهيئة كائن البوت (TeleBot) مع ضبط مهل الاتصال وإزالة تكرار الأخطاء في الكونسول
ودوال الإرسال والتعديل الآمنة ونظام الاشتراك الإجباري.
"""

import re
import html
import logging

import telebot
from telebot import types, apihelper

from config import BOT_TOKEN, DEFAULT_FORCE_SUB_TEXT
from network import logger
from database import (
    is_admin,
    get_setting,
    get_ui_config,
    get_force_channels,
    mark_channel_inaccessible,
    is_channel_temporarily_skipped,
)

# =============================================================================
# ضبط مهل الاتصال لـ Telegram API لمنع أخطاء ReadTimeout و 502 Bad Gateway
# =============================================================================
apihelper.CONNECT_TIMEOUT = 15
apihelper.READ_TIMEOUT = 45
apihelper.RETRY_ON_ERROR = True
apihelper.RETRY_TIMEOUT = 3
apihelper.MAX_RETRIES = 3
apihelper.SESSION_TIME_TO_LIVE = 300

# كتم طباعة الأخطاء المكررة من لوجر TeleBot الداخلي (نتعامل معها في main.py بنظافة)
telebot.logger.setLevel(logging.CRITICAL)

bot = telebot.TeleBot(BOT_TOKEN, parse_mode=None, threaded=True, num_threads=12)

admin_states = {}
_cached_bot_username = None
_cached_bot_id = None


def get_bot_username():
    global _cached_bot_username, _cached_bot_id
    if _cached_bot_username:
        return _cached_bot_username
    try:
        me = bot.get_me()
        _cached_bot_username = me.username or "البوت"
        _cached_bot_id = me.id
        return _cached_bot_username
    except Exception:
        return "البوت"


def get_bot_id():
    global _cached_bot_id
    if _cached_bot_id:
        return _cached_bot_id
    try:
        me = bot.get_me()
        _cached_bot_id = me.id
        return _cached_bot_id
    except Exception:
        try:
            return int(BOT_TOKEN.split(":")[0])
        except Exception:
            return None


class SmartInlineButton(types.InlineKeyboardButton):
    """زر تيليجرام يدعم الألوان والأيقونات المميزة عند تفعيلها."""
    def __init__(self, text, style=None, icon_custom_emoji_id=None, **kwargs):
        super().__init__(text=text, **kwargs)
        self.btn_style = style
        self.btn_icon_custom_emoji_id = icon_custom_emoji_id

    def to_dict(self):
        data = super().to_dict()
        if self.btn_style in ("primary", "success", "danger"):
            data["style"] = self.btn_style
        if self.btn_icon_custom_emoji_id:
            data["icon_custom_emoji_id"] = str(self.btn_icon_custom_emoji_id)
        return data


def strip_advanced_button_fields(reply_markup):
    if not isinstance(reply_markup, types.InlineKeyboardMarkup):
        return reply_markup
    for row in reply_markup.keyboard:
        for btn in row:
            if isinstance(btn, SmartInlineButton):
                btn.btn_icon_custom_emoji_id = None
                btn.btn_style = None
    return reply_markup


def utf16_slice(text, offset, length):
    try:
        encoded = text.encode("utf-16-le")
        return encoded[offset * 2:(offset + length) * 2].decode("utf-16-le", errors="ignore")
    except Exception:
        return text[offset:offset + length]


def get_active_custom_emoji(scope, ui_key=None):
    if ui_key:
        cfg = get_ui_config(ui_key)
        if cfg.get("custom_emoji_id"):
            return cfg["custom_emoji_id"], (cfg.get("custom_emoji_char") or "")

    placement = get_setting("premium_placement", "off")
    if placement == "off":
        return None, ""
    if scope == "start" and placement not in ("both", "start_only"):
        return None, ""
    if scope == "sections" and placement not in ("both", "sections_only"):
        return None, ""

    if scope == "start":
        ce_id = get_setting("premium_start_emoji_id", "").strip()
        ce_char = get_setting("premium_start_emoji_char", "").strip()
        if not ce_id:
            ce_id = get_setting("premium_sections_emoji_id", "").strip()
            ce_char = get_setting("premium_sections_emoji_char", "").strip()
        return (ce_id if ce_id else None), ce_char

    ce_id = get_setting("premium_sections_emoji_id", "").strip()
    ce_char = get_setting("premium_sections_emoji_char", "").strip()
    if not ce_id:
        ce_id = get_setting("premium_start_emoji_id", "").strip()
        ce_char = get_setting("premium_start_emoji_char", "").strip()
    return (ce_id if ce_id else None), ce_char


def format_premium_badge(scope="sections", fallback_emoji="", ui_key=None):
    ce_id, ce_char = get_active_custom_emoji(scope, ui_key=ui_key)
    if ce_id:
        char_to_use = ce_char or fallback_emoji or "•"
        return f'<tg-emoji emoji-id="{html.escape(ce_id)}">{html.escape(char_to_use)}</tg-emoji> '
    return ""


def resolve_button_style(preferred_style="primary"):
    theme = get_setting("color_theme", "mixed")
    if theme == "default":
        return None
    if theme in ("primary", "success", "danger"):
        return theme
    return preferred_style


def make_btn(text=None, callback_data=None, url=None, style="primary", scope="sections", ui_key=None, format_vars=None):
    final_text = text
    if ui_key:
        cfg = get_ui_config(ui_key)
        if final_text is None:
            final_text = cfg["btn_label"]
        if format_vars and isinstance(format_vars, dict):
            for k, v in format_vars.items():
                final_text = final_text.replace(f"{{{k}}}", str(v))

    final_style = resolve_button_style(style)
    ce_id, _ = get_active_custom_emoji(scope, ui_key=ui_key)
    kwargs = {}
    if callback_data is not None:
        kwargs["callback_data"] = callback_data
    if url is not None:
        kwargs["url"] = url
    return SmartInlineButton(
        text=str(final_text or ""),
        style=final_style,
        icon_custom_emoji_id=ce_id,
        **kwargs,
    )


def send_ui_optional_sticker(chat_id, ui_key):
    cfg = get_ui_config(ui_key)
    st_id = (cfg.get("sticker_id") or "").strip()
    if st_id:
        try:
            bot.send_sticker(chat_id, st_id)
        except Exception as e:
            logger.debug(f"Optional UI sticker note for {ui_key}: {e}")


def safe_answer_callback(call_id, text=None, show_alert=False):
    try:
        bot.answer_callback_query(call_id, text=text, show_alert=show_alert)
    except Exception:
        pass


def safe_send_message(chat_id, text, reply_markup=None, parse_mode="HTML", entities=None, reply_to_message_id=None, disable_web_page_preview=True):
    try:
        if entities:
            return bot.send_message(
                chat_id,
                text,
                entities=entities,
                reply_markup=reply_markup,
                reply_to_message_id=reply_to_message_id,
                disable_web_page_preview=disable_web_page_preview,
            )
        return bot.send_message(
            chat_id,
            text,
            parse_mode=parse_mode,
            reply_markup=reply_markup,
            reply_to_message_id=reply_to_message_id,
            disable_web_page_preview=disable_web_page_preview,
        )
    except Exception as e:
        err_str = str(e)
        if reply_markup and any(k in err_str.upper() for k in ("BUTTON_", "CUSTOM_EMOJI", "STYLE", "400")):
            try:
                clean_markup = strip_advanced_button_fields(reply_markup)
                return bot.send_message(
                    chat_id,
                    text if not parse_mode else re.sub(r"</?tg-emoji[^>]*>", "", text),
                    parse_mode=parse_mode if not entities else None,
                    reply_markup=clean_markup,
                    reply_to_message_id=reply_to_message_id,
                    disable_web_page_preview=disable_web_page_preview,
                )
            except Exception:
                pass
        plain_text = re.sub(r"<[^>]+>", "", text)
        try:
            return bot.send_message(
                chat_id,
                plain_text,
                reply_markup=strip_advanced_button_fields(reply_markup) if reply_markup else None,
                reply_to_message_id=reply_to_message_id,
            )
        except Exception:
            return None


def safe_edit_message(chat_id, message_id, text, reply_markup=None, parse_mode="HTML"):
    try:
        return bot.edit_message_text(
            text,
            chat_id=chat_id,
            message_id=message_id,
            parse_mode=parse_mode,
            reply_markup=reply_markup,
            disable_web_page_preview=True,
        )
    except Exception as e:
        err_str = str(e)
        if "message is not modified" in err_str.lower():
            return None
        if "message to edit not found" in err_str.lower():
            return safe_send_message(chat_id, text, reply_markup=reply_markup, parse_mode=parse_mode)
        try:
            clean_markup = strip_advanced_button_fields(reply_markup) if reply_markup else None
            clean_text = re.sub(r"</?tg-emoji[^>]*>", "", text)
            return bot.edit_message_text(
                clean_text,
                chat_id=chat_id,
                message_id=message_id,
                parse_mode=parse_mode,
                reply_markup=clean_markup,
                disable_web_page_preview=True,
            )
        except Exception:
            return None


# =============================================================================
# نظام الاشتراك الإجباري المحصّن ضد خطأ (member list is inaccessible)
# =============================================================================
def check_user_subscription(user_id):
    if is_admin(user_id):
        return []
    if get_setting("force_sub_enabled", "1") != "1":
        return []

    channels = get_force_channels()
    if not channels:
        return []

    unsubscribed = []
    for ch in channels:
        chat_id = str(ch["chat_id"])
        if is_channel_temporarily_skipped(chat_id):
            continue

        try:
            member = bot.get_chat_member(chat_id, user_id)
            status = member.status
            if status in ("left", "kicked"):
                unsubscribed.append(ch)
            elif status == "restricted" and hasattr(member, "is_member") and not member.is_member:
                unsubscribed.append(ch)
        except Exception as e:
            err_l = str(e).lower()
            if any(k in err_l for k in (
                "member list is inaccessible",
                "chat not found",
                "bot is not a member",
                "bot was kicked",
                "forbidden",
                "have no rights",
                "not enough rights",
                "channel_private",
            )):
                mark_channel_inaccessible(chat_id, duration=3600)
            continue

    return unsubscribed


def send_force_sub_prompt(chat_id, user, reply_to_message_id=None):
    unsubscribed = check_user_subscription(user.id)
    if not unsubscribed:
        return True

    send_ui_optional_sticker(chat_id, "btn_verify_sub")

    markup = types.InlineKeyboardMarkup(row_width=2)
    ch_buttons = []
    for idx, ch in enumerate(unsubscribed, start=1):
        title = (ch.get("title") or f"قناة {idx}")[:20]
        invite_link = ch.get("invite_link") or "https://t.me/"
        ch_buttons.append(make_btn(title, url=invite_link, style="primary", scope="sections"))
    if ch_buttons:
        markup.add(*ch_buttons)

    markup.add(
        make_btn(callback_data="verify_subscription", style="success", scope="sections", ui_key="btn_verify_sub")
    )

    verify_cfg = get_ui_config("btn_verify_sub")
    raw_text = verify_cfg.get("inner_content") or get_setting("force_sub_text", DEFAULT_FORCE_SUB_TEXT)
    safe_name = html.escape(user.first_name or "المستخدم")
    badge = format_premium_badge("sections", "", ui_key="btn_verify_sub")
    text = f"{badge}<b>الاشتراك الإجباري</b>\n<blockquote>{html.escape(raw_text).replace('{name}', safe_name)}</blockquote>"

    safe_send_message(
        chat_id,
        text,
        reply_markup=markup,
        parse_mode="HTML",
        reply_to_message_id=reply_to_message_id,
    )
    return False
