#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
بناء واجهات البوت:
- رسالة الترحيب (/start)
- لوحة تحكم الأدمن (/admin) وقوائم تخصيص الأزرار
- تنسيق الكابتشن الطبيعي للفيديو والوسائط (بدون أي عبارات مثل مضغوط / قوية / أصلية)
"""

import re
import html
import json
from telebot import types

from config import (
    DEFAULT_WELCOME_TEXT,
    CUSTOMIZABLE_UI_KEYS,
    PLACEMENT_LABELS,
    THEME_LABELS,
)
from database import (
    db_lock,
    get_db_connection,
    get_setting,
    get_ui_config,
    is_admin,
    has_cookies_file,
)
from bot_instance import (
    bot,
    get_bot_username,
    get_active_custom_emoji,
    format_premium_badge,
    make_btn,
    safe_send_message,
)
from network import logger


def convert_text_and_entities_to_html(raw_text, entities_data):
    if not entities_data:
        return html.escape(raw_text)

    try:
        utf16_bytes = raw_text.encode("utf-16-le")
        total_units = len(utf16_bytes) // 2
        sorted_ents = sorted(entities_data, key=lambda x: x.get("offset", 0))

        out_parts = []
        cursor_unit = 0

        for ent in sorted_ents:
            off = ent.get("offset", 0)
            length = ent.get("length", 0)
            etype = ent.get("type", "")
            if off < cursor_unit or off + length > total_units:
                continue

            if off > cursor_unit:
                prefix = utf16_bytes[cursor_unit * 2:off * 2].decode("utf-16-le", errors="ignore")
                out_parts.append(html.escape(prefix))

            segment = utf16_bytes[off * 2:(off + length) * 2].decode("utf-16-le", errors="ignore")
            esc_seg = html.escape(segment)

            if etype == "custom_emoji" and ent.get("custom_emoji_id"):
                ce_id = html.escape(str(ent["custom_emoji_id"]))
                out_parts.append(f'<tg-emoji emoji-id="{ce_id}">{esc_seg}</tg-emoji>')
            elif etype == "bold":
                out_parts.append(f"<b>{esc_seg}</b>")
            elif etype == "italic":
                out_parts.append(f"<i>{esc_seg}</i>")
            elif etype == "underline":
                out_parts.append(f"<u>{esc_seg}</u>")
            elif etype == "strikethrough":
                out_parts.append(f"<s>{esc_seg}</s>")
            elif etype == "code":
                out_parts.append(f"<code>{esc_seg}</code>")
            elif etype == "pre":
                out_parts.append(f"<pre>{esc_seg}</pre>")
            elif etype == "blockquote":
                out_parts.append(f"<blockquote>{esc_seg}</blockquote>")
            elif etype == "text_link" and ent.get("url"):
                out_parts.append(f'<a href="{html.escape(ent["url"])}">{esc_seg}</a>')
            else:
                out_parts.append(esc_seg)

            cursor_unit = off + length

        if cursor_unit < total_units:
            tail = utf16_bytes[cursor_unit * 2:].decode("utf-16-le", errors="ignore")
            out_parts.append(html.escape(tail))

        return "".join(out_parts)
    except Exception:
        return html.escape(raw_text)


def build_welcome_message_and_entities():
    raw_text = get_setting("welcome_text", DEFAULT_WELCOME_TEXT)
    raw_entities_json = get_setting("welcome_entities", "[]")
    bot_uname = f"@{get_bot_username()}"

    try:
        entities_data = json.loads(raw_entities_json)
    except Exception:
        entities_data = []

    placement = get_setting("premium_placement", "off")
    allow_start_premium = placement in ("both", "start_only")

    if entities_data and allow_start_premium:
        html_text = convert_text_and_entities_to_html(raw_text, entities_data)
    else:
        html_text = html.escape(raw_text)

    html_text = html_text.replace("@البوت", html.escape(bot_uname)).replace("{bot}", html.escape(bot_uname))

    if allow_start_premium and not entities_data:
        ce_id, ce_char = get_active_custom_emoji("start")
        if ce_id:
            badge_html = f'<tg-emoji emoji-id="{html.escape(ce_id)}">{html.escape(ce_char or "•")}</tg-emoji>'
            html_text = f"{badge_html} {html_text}"

    return html_text, None, "HTML"


def send_welcome_screen(chat_id, user, reply_to_message_id=None):
    sticker_id = get_setting("welcome_sticker_id", "").strip()
    if sticker_id:
        try:
            bot.send_sticker(chat_id, sticker_id)
        except Exception as e:
            logger.debug(f"تعذر إرسال الملصق الترحيبي: {e}")

    welcome_text, welcome_entities, parse_mode = build_welcome_message_and_entities()

    markup = types.InlineKeyboardMarkup(row_width=2)
    bot_uname = get_bot_username()

    markup.row(
        make_btn(callback_data="user_help_guide", style="success", scope="start", ui_key="btn_help_guide"),
        make_btn(callback_data="user_smart_search_hint", style="primary", scope="start", ui_key="btn_smart_search"),
    )
    markup.row(
        make_btn(
            url=f"https://t.me/{bot_uname}?startgroup=true",
            style="success",
            scope="start",
            ui_key="btn_add_group",
        )
    )

    if is_admin(user.id):
        markup.row(
            make_btn(callback_data="admin_home", style="danger", scope="sections", ui_key="btn_admin_panel")
        )

    safe_send_message(
        chat_id,
        welcome_text,
        reply_markup=markup,
        parse_mode=parse_mode,
        entities=welcome_entities,
        reply_to_message_id=reply_to_message_id,
    )


def clean_general_description(raw_desc):
    if not raw_desc or not isinstance(raw_desc, str):
        return ""
    desc = raw_desc.strip()
    if not desc:
        return ""
    bad_phrases = (
        "login • instagram",
        "create an account or log in to instagram",
        "enjoy the videos and music you love, upload original content",
    )
    d_low = desc.lower()
    if any(bp in d_low for bp in bad_phrases):
        return ""
    desc = re.sub(r"\n{3,}", "\n\n", desc).strip()
    return desc[:2500]


def format_media_caption_with_description(badge, title, description, platform_name, author_display, bot_uname):
    """
    كابتشن عادي ونظيف للفيديو أو الوسائط بدون أي كلمات مثل (مضغوط / قوية / أصلية).
    """
    safe_title = html.escape(re.sub(r"\s+", " ", str(title or "منشور محمل")).strip()[:140])
    safe_uname = html.escape(bot_uname)
    clean_desc = clean_general_description(description)

    author_part = f"<code>{html.escape(author_display[:30])}</code> | " if author_display else ""
    footer_html = f"<blockquote><b>{html.escape(platform_name)}</b> | {author_part}@{safe_uname}</blockquote>"

    effective_desc = clean_desc if clean_desc else re.sub(r"\s+", " ", str(title or "")).strip()
    if effective_desc in ("منشور محمل", "") or effective_desc.startswith(("منشور انستغرام (", "فيديو يوتيوب (")):
        effective_desc = ""

    overflow_desc = ""
    desc_block_html = ""
    if effective_desc:
        max_desc_chars_in_caption = 620
        if len(effective_desc) > max_desc_chars_in_caption:
            in_cap_desc = effective_desc[:max_desc_chars_in_caption].rstrip() + "..."
            overflow_desc = effective_desc
        else:
            in_cap_desc = effective_desc
        desc_block_html = f"\n<b>الوصف:</b>\n<blockquote>{html.escape(in_cap_desc)}</blockquote>"

    full_caption = f"{badge}<b>{safe_title}</b>{desc_block_html}\n{footer_html}"
    clean_caption = re.sub(r"</?tg-emoji[^>]*>", "", full_caption)
    return full_caption, clean_caption, overflow_desc


# =============================================================================
# لوحة تحكم الأدمن (/admin)
# =============================================================================
def build_admin_main_keyboard():
    force_on = get_setting("force_sub_enabled", "1") == "1"
    bot_on = get_setting("bot_enabled", "1") == "1"
    cookies_ok = has_cookies_file()

    markup = types.InlineKeyboardMarkup(row_width=3)

    bot_lbl = get_ui_config("adm_btn_bot")["btn_label"]
    fsub_lbl = get_ui_config("adm_btn_fsub")["btn_label"]
    cookies_lbl = get_ui_config("adm_btn_cookies")["btn_label"]

    markup.row(
        make_btn(f"{bot_lbl}: {'مفعل' if bot_on else 'معطل'}", callback_data="adm_toggle_bot", style="success" if bot_on else "danger", scope="sections", ui_key="adm_btn_bot"),
        make_btn(f"{fsub_lbl}: {'مفعل' if force_on else 'معطل'}", callback_data="adm_toggle_fsub", style="success" if force_on else "danger", scope="sections", ui_key="adm_btn_fsub"),
    )

    markup.row(
        make_btn(callback_data="adm_ui_custom_menu", style="success", scope="sections", ui_key="adm_btn_ui_custom")
    )

    markup.row(
        make_btn(callback_data="adm_premium_menu", style="primary", scope="sections", ui_key="adm_btn_premium"),
        make_btn(callback_data="adm_colors_menu", style="success", scope="sections", ui_key="adm_btn_colors"),
        make_btn(callback_data="adm_welcome_menu", style="primary", scope="sections", ui_key="adm_btn_welcome"),
    )

    markup.row(
        make_btn(callback_data="adm_fsub_menu", style="danger", scope="sections", ui_key="adm_btn_channels"),
        make_btn(callback_data="adm_stats", style="primary", scope="sections", ui_key="adm_btn_users"),
        make_btn(callback_data="adm_broadcast_menu", style="success", scope="sections", ui_key="adm_btn_broadcast"),
    )

    markup.row(
        make_btn(f"{cookies_lbl}: {'مفعل' if cookies_ok else 'إضافة'}", callback_data="adm_cookies_menu", style="success" if cookies_ok else "primary", scope="sections", ui_key="adm_btn_cookies"),
        make_btn(callback_data="adm_ban_menu", style="danger", scope="sections", ui_key="adm_btn_ban"),
        make_btn(callback_data="adm_admins_menu", style="success", scope="sections", ui_key="adm_btn_admins"),
    )

    markup.row(
        make_btn(callback_data="adm_clear_cache", style="primary", scope="sections", ui_key="adm_btn_clear_cache"),
        make_btn(callback_data="adm_close", style="danger", scope="sections", ui_key="btn_cancel"),
    )
    return markup


def get_admin_dashboard_text():
    with db_lock:
        conn = get_db_connection()
        total_users = conn.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
        banned_users = conn.execute("SELECT COUNT(*) as c FROM users WHERE is_banned = 1").fetchone()["c"]
        total_channels = conn.execute("SELECT COUNT(*) as c FROM force_channels").fetchone()["c"]
        total_admins = conn.execute("SELECT COUNT(*) as c FROM admins").fetchone()["c"]
        cached_items = conn.execute("SELECT COUNT(*) as c FROM media_cache").fetchone()["c"]
        conn.close()

    placement = get_setting("premium_placement", "off")
    placement_str = PLACEMENT_LABELS.get(placement, placement)
    theme = get_setting("color_theme", "mixed")
    theme_str = THEME_LABELS.get(theme, theme)
    badge = format_premium_badge("sections", "")

    return (
        f"{badge}<b>لوحة التحكم (/admin)</b>\n"
        "<blockquote>"
        f"المشتركين: <code>{total_users}</code> | الكاش: <code>{cached_items}</code>\n"
        f"القنوات: <code>{total_channels}</code> | المشرفين: <code>{total_admins}</code> | المحظورين: <code>{banned_users}</code>\n"
        f"المميز العام: {html.escape(placement_str)} | الثيم: {html.escape(theme_str)}\n"
        f"كوكيز انستا/يوتيوب: <code>{'مفعل' if has_cookies_file() else 'تلقائي بدون كوكيز'}</code>"
        "</blockquote>\n"
        "<b>اختر القسم المطلوب للتعديل أو الإدارة:</b>"
    )


def build_ui_customization_list_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)
    btns = []
    for u_key in CUSTOMIZABLE_UI_KEYS.keys():
        cfg = get_ui_config(u_key)
        has_extra = bool(cfg["sticker_id"] or cfg["custom_emoji_id"])
        suffix = " [ملصق/مميز]" if has_extra else ""
        btns.append(
            make_btn(
                f"{cfg['btn_label'][:22]}{suffix}",
                callback_data=f"adm_uikey|{u_key}",
                style="success" if has_extra else "primary",
                scope="sections",
            )
        )
    for i in range(0, len(btns), 2):
        if i + 1 < len(btns):
            markup.row(btns[i], btns[i + 1])
        else:
            markup.row(btns[i])

    markup.row(make_btn("استعادة جميع الأزرار للافتراضي", callback_data="adm_ui_reset_all", style="danger", scope="sections"))
    markup.row(make_btn("رجوع للوحة التحكم", callback_data="admin_home", style="primary", scope="sections"))
    return markup


def build_single_ui_key_editor(ui_key):
    cfg = get_ui_config(ui_key)
    st_status = "مضاف (اختياري)" if cfg["sticker_id"] else "غير مضاف (بدون ملصق)"
    ce_status = f"مضاف ({cfg['custom_emoji_id']})" if cfg["custom_emoji_id"] else "غير مضاف (بدون إيموجي)"
    content_preview = (cfg["inner_content"] or "لا يوجد نص داخلي مخصص لهذا الزر")[:250]

    text = (
        f"<b>تخصيص: {html.escape(cfg['title'])}</b>\n"
        "<blockquote>"
        f"<b>اسم الزر الحالي:</b> <code>{html.escape(cfg['btn_label'])}</code>\n"
        f"<b>الملصق المرفق (اختياري):</b> <code>{html.escape(st_status)}</code>\n"
        f"<b>أيقونة الزر المميزة (اختياري):</b> <code>{html.escape(ce_status)}</code>\n"
        "</blockquote>\n"
        f"<b>النص/المحتوى بداخل الزر أو القسم:</b>\n"
        f"<blockquote>{html.escape(content_preview)}</blockquote>\n"
        "<b>اختر ما تريد تعديله:</b>"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.row(
        make_btn("تعديل اسم الزر فقط", callback_data=f"adm_uiedit_lbl|{ui_key}", style="primary", scope="sections"),
        make_btn("تعديل اسم الزر + ملصق/مميز", callback_data=f"adm_uiedit_both|{ui_key}", style="success", scope="sections"),
    )
    if cfg["has_content"]:
        markup.row(make_btn("تعديل النص بداخل الزر/القسم", callback_data=f"adm_uiedit_cnt|{ui_key}", style="primary", scope="sections"))
    markup.row(
        make_btn("إضافة/تغيير الملصق أو الإيموجي", callback_data=f"adm_uiedit_stk|{ui_key}", style="success", scope="sections"),
        make_btn("حذف الملصق/الإيموجي (بدون)", callback_data=f"adm_uidel_stk|{ui_key}", style="danger", scope="sections"),
    )
    markup.row(
        make_btn("استعادة افتراضي هذا الزر", callback_data=f"adm_uireset_one|{ui_key}", style="danger", scope="sections"),
        make_btn("رجوع لقائمة الأزرار", callback_data="adm_ui_custom_menu", style="primary", scope="sections"),
    )
    return text, markup
